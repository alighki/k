<?php
namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function show(Request $r) { return view("account.profile", ["user" => $r->user()]); }

    public function update(Request $r)
    {
        $data = $r->validate([
            "name" => "required|string|max:100",
            "phone" => "nullable|string|max:20",
            "address" => "nullable|string|max:500",
        ]);
        $r->user()->update($data);
        return back()->with("ok", "اطلاعات حساب ذخیره شد.");
    }

    public function orders(Request $r)
    {
        $orders = $r->user()->orders()->with("items.product")->latest()->paginate(10);
        return view("account.orders", compact("orders"));
    }

    public function wishlist(Request $r)
    {
        return view("account.wishlist", ["products" => $r->user()->wishlist]);
    }

    public function toggleWishlist(Request $r, Product $product)
    {
        $r->user()->wishlist()->toggle($product->id);
        return back();
    }
}
