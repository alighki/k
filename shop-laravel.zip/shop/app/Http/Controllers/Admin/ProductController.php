<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    private function rules(): array
    {
        return ["name" => "required|string|max:150", "description" => "nullable|string",
                "price" => "required|integer|min:0", "stock" => "required|integer|min:0"];
    }

    public function index() { return view("admin.products", ["products" => Product::latest()->paginate(15)]); }

    public function store(Request $r)
    {
        Product::create($r->validate($this->rules()));
        return back()->with("ok", "محصول افزوده شد.");
    }

    public function update(Request $r, Product $product)
    {
        $product->update($r->validate($this->rules()));
        return back()->with("ok", "محصول به‌روزرسانی شد.");
    }

    public function destroy(Product $product)
    {
        $product->delete();
        return back()->with("ok", "محصول حذف شد.");
    }
}
