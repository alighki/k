<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index()
    {
        return view("admin.orders", ["orders" => Order::with("user")->latest()->paginate(15)]);
    }

    public function updateStatus(Request $r, Order $order)
    {
        $status = $r->validate(["status" => ["required", Rule::in(array_keys(Order::STATUSES))]])["status"];

        DB::transaction(function () use ($order, $status) {
            // لغو سفارش: موجودی کالاها به انبار برمی‌گردد
            if ($status === "cancelled" && $order->status !== "cancelled") {
                foreach ($order->items as $item) {
                    $item->product->increment("stock", $item->quantity);
                }
            }
            $order->update(["status" => $status]);
        });
        return back()->with("ok", "وضعیت سفارش تغییر کرد.");
    }
}
