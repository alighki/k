<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{Order, OrderItem, Product};
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $valid = Order::where("status", "!=", "cancelled");
        $stats = [
            "revenue" => (clone $valid)->sum("total"),
            "orders" => (clone $valid)->count(),
            "pending" => Order::where("status", "pending")->count(),
            "low_stock" => Product::where("stock", "<=", 5)->count(),
        ];
        $daily = (clone $valid)->where("created_at", ">=", now()->subDays(29)->startOfDay())
            ->selectRaw("DATE(created_at) d, SUM(total) s")->groupBy("d")->orderBy("d")->pluck("s", "d");
        $top = OrderItem::select("product_id", DB::raw("SUM(quantity) qty"))
            ->groupBy("product_id")->orderByDesc("qty")->with("product")->limit(5)->get();

        return view("admin.dashboard", compact("stats", "daily", "top"));
    }
}
