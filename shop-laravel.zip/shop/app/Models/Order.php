<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public const STATUSES = [
        "pending" => "در انتظار پرداخت", "processing" => "در حال پردازش",
        "shipped" => "ارسال شده", "delivered" => "تحویل شده", "cancelled" => "لغو شده",
    ];
    protected $fillable = ["user_id", "status", "total"];
    public function user() { return $this->belongsTo(User::class); }
    public function items() { return $this->hasMany(OrderItem::class); }
}
