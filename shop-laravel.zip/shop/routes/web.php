<?php
use App\Http\Controllers\AccountController;
use App\Http\Controllers\Admin\{DashboardController, OrderController, ProductController};
use App\Http\Middleware\EnsureAdmin;
use Illuminate\Support\Facades\Route;

Route::middleware("auth")->prefix("account")->name("account.")->group(function () {
    Route::get("/", [AccountController::class, "show"])->name("profile");
    Route::put("/", [AccountController::class, "update"])->name("update");
    Route::get("/orders", [AccountController::class, "orders"])->name("orders");
    Route::get("/wishlist", [AccountController::class, "wishlist"])->name("wishlist");
    Route::post("/wishlist/{product}", [AccountController::class, "toggleWishlist"])->name("wishlist.toggle");
});

Route::middleware(["auth", EnsureAdmin::class])->prefix("admin")->name("admin.")->group(function () {
    Route::get("/", [DashboardController::class, "index"])->name("dashboard");
    Route::resource("products", ProductController::class)->only(["index", "store", "update", "destroy"]);
    Route::get("/orders", [OrderController::class, "index"])->name("orders.index");
    Route::patch("/orders/{order}/status", [OrderController::class, "updateStatus"])->name("orders.status");
});
