@extends("layouts.app")
@section("title", "مدیریت محصولات")
@section("content")
<div class="card">
  <h3>محصول جدید</h3>
  <form method="post" action="{{ route("admin.products.store") }}">
    @csrf
    <input name="name" placeholder="نام" required>
    <input name="price" type="number" placeholder="قیمت" required>
    <input name="stock" type="number" placeholder="موجودی" required>
    <button>افزودن</button>
  </form>
</div>
<div class="card">
  <table>
    <tr><th>نام</th><th>قیمت</th><th>موجودی</th><th></th><th></th></tr>
    @foreach($products as $p)
    <tr>
      <form method="post" action="{{ route("admin.products.update", $p) }}">
        @csrf @method("PUT")
        <td><input name="name" value="{{ $p->name }}"></td>
        <td><input name="price" type="number" value="{{ $p->price }}"></td>
        <td><input name="stock" type="number" value="{{ $p->stock }}"></td>
        <td><button>ذخیره</button></td>
      </form>
      <td><form method="post" action="{{ route("admin.products.destroy", $p) }}" onsubmit="return confirm('حذف شود؟')">
        @csrf @method("DELETE")<button>حذف</button></form></td>
    </tr>
    @endforeach
  </table>
  {{ $products->links() }}
</div>
@endsection
