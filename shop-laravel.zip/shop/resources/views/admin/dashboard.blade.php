@extends("layouts.app")
@section("title", "داشبورد فروش")
@section("content")
<div class="grid">
  <div class="card stat"><span>درآمد کل</span><b>{{ number_format($stats["revenue"]) }}</b></div>
  <div class="card stat"><span>تعداد سفارش‌ها</span><b>{{ $stats["orders"] }}</b></div>
  <div class="card stat"><span>در انتظار پرداخت</span><b>{{ $stats["pending"] }}</b></div>
  <div class="card stat"><span>کالاهای کم‌موجودی</span><b>{{ $stats["low_stock"] }}</b></div>
</div>
<div class="card"><h3>فروش ۳۰ روز اخیر</h3><canvas id="sales" height="110"></canvas></div>
<div class="card">
  <h3>پرفروش‌ترین محصولات</h3>
  <table>@foreach($top as $t)<tr><td>{{ $t->product->name }}</td><td>{{ $t->qty }} عدد</td></tr>@endforeach</table>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById("sales"), {
  type: "line",
  data: { labels: @json($daily->keys()), datasets: [{ label: "فروش", data: @json($daily->values()), tension: .3 }] }
});
</script>
@endsection
