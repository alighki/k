@extends("layouts.app")
@section("title", "مدیریت سفارش‌ها")
@section("content")
<div class="card">
  <table>
    <tr><th>#</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th></tr>
    @foreach($orders as $o)
    <tr>
      <td>{{ $o->id }}</td><td>{{ $o->user->name }}</td><td>{{ number_format($o->total) }}</td>
      <td>
        <form method="post" action="{{ route("admin.orders.status", $o) }}">
          @csrf @method("PATCH")
          <select name="status" onchange="this.form.submit()">
            @foreach(\App\Models\Order::STATUSES as $k => $label)
              <option value="{{ $k }}" @selected($o->status === $k)>{{ $label }}</option>
            @endforeach
          </select>
        </form>
      </td>
    </tr>
    @endforeach
  </table>
  {{ $orders->links() }}
</div>
@endsection
