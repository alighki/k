<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield("title", "فروشگاه")</title>
  <style>
    body{font-family:Vazirmatn,Tahoma,sans-serif;margin:0;background:#f5f6fa;color:#222}
    nav{background:#1f2a44;padding:12px 24px;display:flex;gap:18px}
    nav a{color:#fff;text-decoration:none}
    main{max-width:1000px;margin:24px auto;padding:0 16px}
    .card{background:#fff;border-radius:10px;padding:16px;margin-bottom:16px;box-shadow:0 1px 3px #0001}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
    .stat b{display:block;font-size:1.6rem}
    table{width:100%;border-collapse:collapse} th,td{padding:8px;border-bottom:1px solid #eee;text-align:right}
    .ok{background:#e6f7ec;padding:10px;border-radius:8px;margin-bottom:12px}
    input,select,textarea,button{font:inherit;padding:6px 10px}
  </style>
</head>
<body>
<nav>
  <a href="{{ route("account.profile") }}">حساب من</a>
  <a href="{{ route("account.orders") }}">سفارش‌ها</a>
  <a href="{{ route("account.wishlist") }}">علاقه‌مندی‌ها</a>
  @if(auth()->user()?->is_admin)
    <a href="{{ route("admin.dashboard") }}">داشبورد</a>
    <a href="{{ route("admin.products.index") }}">محصولات</a>
    <a href="{{ route("admin.orders.index") }}">مدیریت سفارش‌ها</a>
  @endif
</nav>
<main>
  @if(session("ok"))<div class="ok">{{ session("ok") }}</div>@endif
  @yield("content")
</main>
</body>
</html>
