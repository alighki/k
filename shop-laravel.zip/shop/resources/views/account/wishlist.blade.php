@extends("layouts.app")
@section("title", "علاقه‌مندی‌ها")
@section("content")
<h2>علاقه‌مندی‌ها</h2>
<div class="grid">
@forelse($products as $p)
  <div class="card">
    <b>{{ $p->name }}</b>
    <p>{{ number_format($p->price) }} تومان</p>
    <form method="post" action="{{ route("account.wishlist.toggle", $p) }}">@csrf<button>حذف از لیست</button></form>
  </div>
@empty
  <p>فهرست علاقه‌مندی‌ها خالی است.</p>
@endforelse
</div>
@endsection
