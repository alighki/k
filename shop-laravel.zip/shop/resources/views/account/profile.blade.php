@extends("layouts.app")
@section("title", "اطلاعات حساب")
@section("content")
<div class="card">
  <h2>اطلاعات حساب</h2>
  <form method="post" action="{{ route("account.update") }}">
    @csrf @method("PUT")
    <p><input name="name" value="{{ old("name", $user->name) }}" placeholder="نام"></p>
    <p><input name="phone" value="{{ old("phone", $user->phone) }}" placeholder="تلفن"></p>
    <p><textarea name="address" placeholder="آدرس">{{ old("address", $user->address) }}</textarea></p>
    @error("name")<p>{{ $message }}</p>@enderror
    <button>ذخیره</button>
  </form>
</div>
@endsection
