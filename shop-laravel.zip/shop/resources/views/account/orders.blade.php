@extends("layouts.app")
@section("title", "سفارش‌های من")
@section("content")
<h2>سفارش‌های من</h2>
@forelse($orders as $order)
  <div class="card">
    <b>سفارش #{{ $order->id }}</b> — {{ \App\Models\Order::STATUSES[$order->status] }}
    — {{ number_format($order->total) }} تومان
    <ul>
      @foreach($order->items as $i)
        <li>{{ $i->product->name }} × {{ $i->quantity }}</li>
      @endforeach
    </ul>
  </div>
@empty
  <p>هنوز سفارشی ثبت نکرده‌اید.</p>
@endforelse
{{ $orders->links() }}
@endsection
