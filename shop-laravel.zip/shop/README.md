# فروشگاه اینترنتی (Laravel)

پنل مشتری (حساب، سفارش‌ها، علاقه‌مندی‌ها) + پنل مدیریت (محصولات و موجودی، وضعیت سفارش‌ها، داشبورد فروش).

## نصب
1. `composer create-project laravel/laravel shop && cd shop`
2. `composer require laravel/breeze --dev && php artisan breeze:install blade` (احراز هویت)
3. محتویات این پوشه را روی پروژه کپی کنید (`routes/web.php` و `layouts/app.blade.php` را جایگزین یا ادغام کنید).
4. محتوای `app/Models/UserRelations.txt` را به مدل `User` اضافه کنید و فایل را حذف کنید.
5. در `.env` پایگاه داده را تنظیم کنید و اجرا کنید: `php artisan migrate`
6. ادمین: در `php artisan tinker` → `User::where("email","you@x.com")->update(["is_admin"=>true]);`

## نکات
- لغو سفارش، موجودی کالاها را خودکار برمی‌گرداند.
- مسیرهای `/admin` با میدلور `EnsureAdmin` محافظت شده‌اند.
