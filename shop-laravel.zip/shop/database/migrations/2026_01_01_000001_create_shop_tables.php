<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table("users", function (Blueprint $t) {
            $t->boolean("is_admin")->default(false);
            $t->string("phone")->nullable();
            $t->text("address")->nullable();
        });
        Schema::create("products", function (Blueprint $t) {
            $t->id();
            $t->string("name");
            $t->text("description")->nullable();
            $t->unsignedBigInteger("price");
            $t->unsignedInteger("stock")->default(0);
            $t->string("image")->nullable();
            $t->timestamps();
        });
        Schema::create("orders", function (Blueprint $t) {
            $t->id();
            $t->foreignId("user_id")->constrained()->cascadeOnDelete();
            $t->enum("status", ["pending", "processing", "shipped", "delivered", "cancelled"])->default("pending");
            $t->unsignedBigInteger("total");
            $t->timestamps();
        });
        Schema::create("order_items", function (Blueprint $t) {
            $t->id();
            $t->foreignId("order_id")->constrained()->cascadeOnDelete();
            $t->foreignId("product_id")->constrained();
            $t->unsignedInteger("quantity");
            $t->unsignedBigInteger("price");
        });
        Schema::create("wishlists", function (Blueprint $t) {
            $t->id();
            $t->foreignId("user_id")->constrained()->cascadeOnDelete();
            $t->foreignId("product_id")->constrained()->cascadeOnDelete();
            $t->unique(["user_id", "product_id"]);
        });
    }
    public function down(): void
    {
        Schema::dropIfExists("wishlists");
        Schema::dropIfExists("order_items");
        Schema::dropIfExists("orders");
        Schema::dropIfExists("products");
        Schema::table("users", fn (Blueprint $t) => $t->dropColumn(["is_admin", "phone", "address"]));
    }
};
