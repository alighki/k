import React from 'react';
import BookList from './components/BookList';
import AddBookForm from './components/AddBookForm';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-center text-3xl font-bold">Book Manager</h1>
        </div>
      </header>
      <main className="py-6 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <BookList />
          <AddBookForm />
        </div>
      </main>
    </div>
  );
};

export default App;