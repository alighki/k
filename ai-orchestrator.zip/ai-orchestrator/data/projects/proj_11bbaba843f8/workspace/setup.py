from setuptools import setup, find_packages

setup(
    name='book_manager',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'Flask==2.0.1',
        'SQLAlchemy==1.4.23',
        'tailwindcss==2.2.19',
        'pytest==6.2.5',
    ],
)
