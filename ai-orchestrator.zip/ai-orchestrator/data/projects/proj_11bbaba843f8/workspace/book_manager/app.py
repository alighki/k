from flask import Flask, request, jsonify
from book_manager.database import db, Book

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'
db.init_app(app)

@app.route('/books', methods=['GET'])
def get_books():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    books = Book.query.paginate(page=page, per_page=per_page)
    return jsonify([{'id': book.id, 'title': book.title, 'author': book.author, 'read': book.read} for book in books.items])

@app.route('/books', methods=['POST'])
def add_book():
    data = request.get_json()
    new_book = Book(title=data['title'], author=data['author'], read=False)
    db.session.add(new_book)
    db.session.commit()
    return jsonify({'id': new_book.id, 'title': new_book.title, 'author': new_book.author, 'read': new_book.read}), 201

@app.route('/books/search', methods=['GET'])
def search_books():
    query = request.args.get('q')
    if not query:
        return jsonify({'error': 'Search query is required'}), 400
    books = Book.query.filter((Book.title.contains(query)) | (Book.author.contains(query))).all()
    return jsonify([{'id': book.id, 'title': book.title, 'author': book.author, 'read': book.read} for book in books])

if __name__ == '__main__':
    app.run(debug=True)