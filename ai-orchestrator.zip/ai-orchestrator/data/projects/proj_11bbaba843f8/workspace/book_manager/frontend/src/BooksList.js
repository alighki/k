import React, { useEffect, useState } from 'react';
import axios from 'axios';

const BooksList = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get('/api/books').then(response => {
      setBooks(response.data);
    });
  }, []);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Books</h1>
      <ul className="list-disc pl-5">
        {books.map(book => (
          <li key={book.id} className="mb-2">
            {book.title} by {book.author}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BooksList;