import pytest
from book_manager.app import app, db, Book

@pytest.fixture(autouse=True)
def setup_teardown():
    # Setup
    book = Book(title='Test Book', author='Test Author')
    db.session.add(book)
    db.session.commit()
    yield
    # Teardown
    session.query(Book).delete()
    db.session.commit()

def test_get_books(client):
    response = client.get('/books?page=1&per_page=10')
    assert response.status_code == 200
    data = response.json
    assert len(data) == 1
    assert data[0]['title'] == 'Test Book'
    assert data[0]['author'] == 'Test Author'

def test_add_book(client):
    response = client.post('/books', json={'title': 'New Book', 'author': 'New Author'})
    assert response.status_code == 201
    data = response.json
    assert data['title'] == 'New Book'
    assert data['author'] == 'New Author'