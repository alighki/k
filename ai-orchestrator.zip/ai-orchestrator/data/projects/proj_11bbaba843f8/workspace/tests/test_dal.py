import pytest
from dal import DAL, Book, session

@pytest.fixture(autouse=True)
def setup_teardown():
    # Setup
    book = Book(title='Test Book', author='Test Author')
    session.add(book)
    session.commit()
    yield
    # Teardown
    session.query(Book).delete()
    session.commit()

def test_add_book():
    dal = DAL()
    dal.add_book('New Book', 'New Author')
    books = session.query(Book).all()
    assert len(books) == 2
    assert books[1].title == 'New Book'
    assert books[1].author == 'New Author'

def test_get_books():
    dal = DAL()
    books = dal.get_books()
    assert len(books) == 1
    assert books[0].title == 'Test Book'
    assert books[0].author == 'Test Author'

def test_mark_as_read():
    dal = DAL()
    book_id = session.query(Book).filter_by(title='Test Book').first().id
    dal.mark_as_read(book_id)
    book = session.query(Book).get(book_id)
    assert book.is_read == True

def test_mark_as_unread():
    dal = DAL()
    book_id = session.query(Book).filter_by(title='Test Book').first().id
    dal.mark_as_unread(book_id)
    book = session.query(Book).get(book_id)
    assert book.is_read == False