from models import Book, session

class DAL:
    def add_book(self, title: str, author: str) -> None:
        new_book = Book(title=title, author=author)
        session.add(new_book)
        session.commit()

    def get_books(self) -> list[Book]:
        return session.query(Book).all()

    def mark_as_read(self, book_id: int) -> None:
        book = session.query(Book).filter_by(id=book_id).first()
        if book:
            book.is_read = True
            session.commit()

    def mark_as_unread(self, book_id: int) -> None:
        book = session.query(Book).filter_by(id=book_id).first()
        if book:
            book.is_read = False
            session.commit()
