# Book Manager

A simple book management application.

## Installation

```bash
git clone https://github.com/yourusername/book_manager.git
cd book_manager
pip install -r requirements.txt
```

## Running the Application

```bash
flask run
```

## Testing

```bash
pytest
```