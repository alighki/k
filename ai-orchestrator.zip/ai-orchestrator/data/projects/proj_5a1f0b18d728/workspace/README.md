# Personal Library Management App

## Installation

1. Clone the repository.
2. Install dependencies: `pip install -r requirements.txt`
3. Run the application: `python app.py`

## Running Tests

To run unit tests, execute: `pytest`