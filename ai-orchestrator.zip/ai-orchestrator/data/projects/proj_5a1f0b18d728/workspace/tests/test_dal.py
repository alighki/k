import pytest
from dal import DAL, Book

def test_add_book(dal):
    book = Book(id=None, title='1984', author='George Orwell')
    dal.add_book(book)
    books = dal.get_books(title='1984')
    assert len(books) == 1
    assert books[0].title == '1984'
    assert books[0].author == 'George Orwell'

def test_get_books_by_title(dal):
    book1 = Book(id=None, title='1984', author='George Orwell')
    book2 = Book(id=None, title='To Kill a Mockingbird', author='Harper Lee')
    dal.add_book(book1)
    dal.add_book(book2)
    books = dal.get_books(title='1984')
    assert len(books) == 1
    assert books[0].title == '1984'

def test_get_books_by_author(dal):
    book1 = Book(id=None, title='1984', author='George Orwell')
    book2 = Book(id=None, title='To Kill a Mockingbird', author='Harper Lee')
    dal.add_book(book1)
    dal.add_book(book2)
    books = dal.get_books(author='George Orwell')
    assert len(books) == 1
    assert books[0].author == 'George Orwell'