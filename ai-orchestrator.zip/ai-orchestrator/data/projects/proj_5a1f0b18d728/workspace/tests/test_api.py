import pytest
from app import app, dal

@pytest.fixture(autouse=True)
def setup_teardown():
    with app.app_context():
        dal._create_table()
        yield
        dal.conn.close()

def test_add_book(client):
    response = client.post('/books', json={'title': '1984', 'author': 'George Orwell'})
    assert response.status_code == 201
    assert response.json['message'] == 'Book added successfully'

def test_get_books_by_title(client):
    client.post('/books', json={'title': '1984', 'author': 'George Orwell'})
    response = client.get('/books?title=1984')
    assert response.status_code == 200
    assert len(response.json) == 1
    assert response.json[0]['title'] == '1984'

def test_get_books_by_author(client):
    client.post('/books', json={'title': '1984', 'author': 'George Orwell'})
    response = client.get('/books?author=George+Orwell')
    assert response.status_code == 200
    assert len(response.json) == 1
    assert response.json[0]['author'] == 'George Orwell'

def test_update_book(client):
    client.post('/books', json={'title': '1984', 'author': 'George Orwell'})
    response = client.put('/books/1', json={'title': 'Animal Farm', 'author': 'George Orwell'})
    assert response.status_code == 200
    assert response.json['message'] == 'Book updated successfully'

def test_delete_book(client):
    client.post('/books', json={'title': '1984', 'author': 'George Orwell'})
    response = client.delete('/books/1')
    assert response.status_code == 200
    assert response.json['message'] == 'Book deleted successfully'