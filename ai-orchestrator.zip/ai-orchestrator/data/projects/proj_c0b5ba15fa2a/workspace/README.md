# Personal Library Management App

## Installation

```bash
cp requirements.txt.example requirements.txt
pip install -r requirements.txt
```

## Running the App

```bash
python app.py
```

## Testing

```bash
pytest tests/
```