from app import app, db, Book
import pytest

@pytest.fixture(scope='module')
def client():
    with app.test_client() as c:
        yield c

def test_get_books(client):
    response = client.get('/books')
    assert response.status_code == 200
    assert len(response.json) == 0

def test_add_book(client):
    response = client.post('/books', json={'title': 'Test Book', 'author': 'Test Author'})
    assert response.status_code == 201
    assert response.json['title'] == 'Test Book'
