from models import db, Book
import pytest

@pytest.fixture(scope='module')
def client():
    with app.test_client() as c:
        yield c

@pytest.fixture(scope='module')
def book(client):
    new_book = Book(title='Test Book', author='Test Author')
    db.session.add(new_book)
    db.session.commit()
    return new_book

def test_get_books(client, book):
    response = client.get('/books')
    assert response.status_code == 200
    assert len(response.json) == 1
    assert response.json[0]['title'] == 'Test Book'

def test_add_book(client):
    response = client.post('/books', json={'title': 'New Book', 'author': 'New Author'})
    assert response.status_code == 201
    assert response.json['title'] == 'New Book'

def test_update_book(client, book):
    response = client.put(f'/books/{book.id}', json={'title': 'Updated Title', 'author': 'Updated Author'})
    assert response.status_code == 200
    assert response.json['title'] == 'Updated Title'

def test_delete_book(client, book):
    response = client.delete(f'/books/{book.id}')
    assert response.status_code == 204