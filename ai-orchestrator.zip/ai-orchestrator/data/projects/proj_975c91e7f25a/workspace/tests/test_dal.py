import unittest
from dal import DAL, Book

class TestDAL(unittest.TestCase):
    def setUp(self):
        self.dal = DAL(':memory:')

    def test_add_book(self):
        book = Book(title='Test Book', author='Test Author')
        result = self.dal.add_book(book)
        self.assertTrue(result)

    def test_get_books(self):
        book1 = Book(title='Book 1', author='Author 1')
        book2 = Book(title='Book 2', author='Author 2')
        self.dal.add_book(book1)
        self.dal.add_book(book2)
        books = self.dal.get_books()
        self.assertEqual(len(books), 2)

    def test_search_books(self):
        book1 = Book(title='Book 1', author='Author 1')
        book2 = Book(title='Book 2', author='Author 2')
        self.dal.add_book(book1)
        self.dal.add_book(book2)
        results = self.dal.search_books('Book 1')
        self.assertEqual(len(results), 1)

if __name__ == '__main__':
    unittest.main()