# Book Manager

A simple book management application.

## Installation
```bash
curl -sSL https://install.python-poetry.org | python3 -
poetry install
```

## Running the Application
```bash
poetry run flask run
```

## API Endpoints
- **GET /books**: List all books.
  - **Query Parameters**:
    - `page`: Page number (default: 1)
    - `per_page`: Number of items per page (default: 10)
- **POST /books**: Add a new book.
  - **Request Body**:
    ```json
    {"title": "string","author": "string","publication_year": number,"read_status": boolean}
    ```

## Testing
To run the tests, execute the following command:
```bash
poetry run pytest
```

## Error Handling
The application includes basic error handling for validation errors and other exceptions. All errors are returned as JSON with appropriate status codes.