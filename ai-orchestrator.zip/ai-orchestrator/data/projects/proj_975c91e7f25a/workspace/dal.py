import sqlite3
from pydantic import BaseModel, ValidationError

class Book(BaseModel):
    title: str
    author: str
    publication_year: int = None
    read_status: bool = False

class DAL:
    def __init__(self, db_path='sqlite:///books.db'):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                publication_year INTEGER,
                read_status BOOLEAN DEFAULT False
            )
        ''')
        self.conn.commit()

    def add_book(self, book: Book):
        try:
            self.cursor.execute('''
                INSERT INTO books (title, author, publication_year, read_status)
                VALUES (?, ?, ?, ?)
            ''', (book.title, book.author, book.publication_year, book.read_status))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            print(f'Error adding book: {e}')
            return False

    def get_books(self, page=1, per_page=10):
        start = (page - 1) * per_page
        end = start + per_page
        self.cursor.execute('''
            SELECT * FROM books LIMIT ? OFFSET ?
        ''', (per_page, start))
        rows = self.cursor.fetchall()
        return [Book(**row[1:]) for row in rows]

    def search_books(self, query):
        self.cursor.execute('''
            SELECT * FROM books WHERE title LIKE ? OR author LIKE ?
        ''', (f'%{query}%', f'%{query}%'))
        rows = self.cursor.fetchall()
        return [Book(**row[1:]) for row in rows]