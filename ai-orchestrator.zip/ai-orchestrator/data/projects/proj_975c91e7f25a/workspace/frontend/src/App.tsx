import React, { useEffect, useState } from 'react';
import axios from 'axios';
import BookList from './components/BookList';
import AddBook from './components/AddBook';

interface Book {
  title: string;
  author: string;
  publication_year?: number;
  read_status: boolean;
}

const App: React.FC = () => {
  const [books, setBooks] = useState<Book[]>([]);

  useEffect(() => {
    axios.get('http://localhost:5000/books').then((response) => {
      setBooks(response.data);
    });
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Book Manager</h1>
      <AddBook />
      <BookList books={books} />
    </div>
  );
};

export default App;
