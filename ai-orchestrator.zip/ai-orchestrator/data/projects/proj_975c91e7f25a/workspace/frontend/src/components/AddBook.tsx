import React, { useState } from 'react';
import axios from 'axios';

interface Book {
  title: string;
  author: string;
  publication_year?: number;
  read_status: boolean;
}

const AddBook: React.FC = () => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [publicationYear, setPublicationYear] = useState<number | null>(null);
  const [readStatus, setReadStatus] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/books', {
        title,
        author,
        publication_year: publicationYear || undefined,
        read_status: readStatus,
      });
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
      <div>
        <label>Title:</label>
        <input type='text' value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div>
        <label>Author:</label>
        <input type='text' value={author} onChange={(e) => setAuthor(e.target.value)} required />
      </div>
      <div>
        <label>Publication Year (optional):</label>
        <input type='number' value={publicationYear || ''} onChange={(e) => setPublicationYear(Number(e.target.value))} />
      </div>
      <div>
        <label>Status:</label>
        <select value={readStatus ? 'true' : 'false'} onChange={(e) => setReadStatus(e.target.value === 'true')}
          style={{ width: '100px', padding: '5px' }}
        >
          <option value='false'>Not Read</option>
          <option value='true'>Read</option>
        </select>
      </div>
      <button type='submit'>Add Book</button>
    </form>
  );
};

export default AddBook;
