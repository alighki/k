import React from 'react';

interface Book {
  title: string;
  author: string;
  publication_year?: number;
  read_status: boolean;
}

const BookList: React.FC<{ books: Book[] }> = ({ books }) => {
  return (
    <div>
      {books.map((book, index) => (
        <div key={index} style={{ marginBottom: '10px' }}>
          <h3>{book.title}</h3>
          <p>Author: {book.author}</p>
          {book.publication_year && <p>Publication Year: {book.publication_year}</p>}
          <p>Status: {book.read_status ? 'Read' : 'Not Read'}</p>
        </div>
      ))}
    </div>
  );
};

export default BookList;
