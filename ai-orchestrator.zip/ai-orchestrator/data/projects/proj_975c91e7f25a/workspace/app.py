from flask import Flask, request, jsonify
from pydantic import BaseModel, ValidationError
import os
db_path = os.getenv('DATABASE_URL', 'sqlite:///books.db')
app = Flask(__name__)
# Define the Book model using Pydantic
class Book(BaseModel):
    title: str
    author: str
    publication_year: int = None
    read_status: bool = False
# Dummy data store for now
books_db = []
@app.route('/books', methods=['GET'])
def get_books():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    start = (page - 1) * per_page
    end = start + per_page
    return jsonify(books_db[start:end])
@app.route('/books', methods=['POST'])
def add_book():
    try:
        data = request.get_json()
        book = Book(**data)
        books_db.append(book.dict())
        return jsonify(book.dict()), 201
    except ValidationError as e:
        return jsonify(e.errors()), 400
@app.route('/books/search', methods=['GET'])
def search_books():
    query = request.args.get('q')
    if not query:
        return jsonify({'error': 'Missing query parameter'}), 400
    results = [book for book in books_db if query.lower() in book['title'].lower() or query.lower() in book['author'].lower()]
    return jsonify(results)
if __name__ == '__main__':
    app.run(debug=True)