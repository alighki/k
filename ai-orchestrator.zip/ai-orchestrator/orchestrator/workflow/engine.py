"""
Workflow Engine — the actual "Manager" from the design doc. This is
the ONLY module that decides what happens next; every other module
(agents, memory, decision, quality, files) is a service it calls.

Pipeline (mirrors the design doc's final agreed order):

    Received -> Idea Expansion -> Research -> Architecture -> Planning
             -> Prompt Build -> Coding -> Review -> Testing -> Debug
             -> Output -> Done

Research and Architecture are run in parallel where possible (see
core/types.py PARALLELIZABLE_STAGES) since they don't depend on each
other's output, only on Idea Expansion's.

This module deliberately contains no "intelligence" — no prompts, no
scoring rules, no consensus math. It only sequences calls to the
modules that do.
"""

from __future__ import annotations

import re
import hashlib
import json
import threading
import difflib
import unicodedata

from orchestrator.agents.registry import get_agent
from orchestrator.ai_manager.manager import AIManager
from orchestrator.core.exceptions import DependencyCycleError, QualityGateFailure
from orchestrator.core.logging_setup import get_logger
from orchestrator.core.types import AgentRole, ProjectStage, TaskStatus, utcnow
from orchestrator.decision.confidence import ConfidenceGate, ConfidenceVerdict
from orchestrator.decision.engine import DecisionEngine
from orchestrator.decision.policy import PolicyEngine
from orchestrator.files.manager import FileManager
from orchestrator.knowledge_graph.graph import KnowledgeGraph
from orchestrator.memory.manager import MemoryManager
from orchestrator.prompt.optimizer import PromptOptimizationStats
from orchestrator.quality.scorer import QualityScorer
from orchestrator.quality.test_runner import TestRunner
from orchestrator.workflow.parallel import ParallelExecutor
from orchestrator.workflow.retry import RetryAction, RetryManager
from orchestrator.workflow.simulation import SimulationEngine, SimulationVerdict
from orchestrator.workflow.state import ProjectState, ProjectStateManager
from orchestrator.workflow.task_tree import Task, TaskTree

logger = get_logger(__name__)

# `policy.max_debug_loops` (config/orchestrator.yaml) is allowed to be
# null, meaning "no configured limit". Previously that was implemented
# as `if max_debug_loops is not None and debug_loops_used >= max_debug_loops`,
# which means a null config value skipped the check ENTIRELY rather than
# meaning "use a sane default" — a task that a Debugger can never
# actually fix (e.g. it keeps producing a different-but-still-broken
# candidate each round, so the same-fingerprint guard never trips)
# would cycle DEBUG -> TESTING -> REVIEW -> DEBUG forever, with each
# round costing minutes of local model inference. This ceiling applies
# whenever the config doesn't set an explicit (lower or higher) value,
# so "unconfigured" no longer means "unbounded".
_DEFAULT_DEBUG_LOOP_CEILING = 10  # raised from 6: with max 4 retries/task and 8 typical
                                   # tasks, 6 rounds was too low for local models that
                                   # frequently produce syntax errors needing multiple attempts
_DEFAULT_CODING_ITERATION_CEILING = 200

# How many additional attempts the Programmer gets for a single task.
#
# KEY FIX: Separate ceilings per failure mode so a confidence/parse failure
# (cheap — the model ran but produced unparseable JSON) doesn't burn all
# retries that should be available for real validation failures (stub output,
# invalid paths, zero written files). Without this, 4 confidence retries in
# a row leave zero retries for actual coding failures.
#
#   CONFIDENCE: model produced unparseable JSON / confidence=0 → retry fast,
#               separate counter so these don't eat into validation budget.
#   VALIDATION: model produced output but it's wrong (stub/bad path/empty).
_MAX_CONFIDENCE_RETRIES = 2   # confidence/parse failures only
_MAX_CODING_RETRIES = 4       # stub / invalid-path / zero-files failures


# Recognizable placeholder/stub bodies a small local model sometimes emits
# instead of the actual requested implementation (e.g. `print("hi")` as the
# entire body of main.py). These patterns are intentionally narrow: they
# must match the *substantive* content of the file after stripping imports,
# comments, and boilerplate, so real short files (a one-line __init__.py,
# a small config.py, a two-line helper function) are not falsely flagged —
# only content that is either completely empty or made up ENTIRELY of
# known placeholder lines counts as a stub. A short *correct* file is not
# a stub; a short *fake* file is. Line count alone cannot tell those apart,
# so it deliberately is not used as a signal here.
_STUB_BODY_PATTERNS = (
    re.compile(r'^\s*print\(\s*["\']hi["\']\s*\)\s*$', re.IGNORECASE),
    re.compile(r'^\s*print\(\s*["\']hello["\']?\s*\)\s*$', re.IGNORECASE),
    re.compile(r'^\s*pass\s*$'),
    re.compile(r'^\s*\.\.\.\s*$'),
    re.compile(r'^\s*(#|//)\s*TODO', re.IGNORECASE),
)
_MAIN_BOILERPLATE = (
    "def main():", "main()",
    "if __name__ == '__main__':", 'if __name__ == "__main__":',
)

# An empty function/method body (only `pass`, `...`, or a bare TODO comment)
# is suspicious regardless of how long the surrounding file is — unlike file
# brevity, an unimplemented function body is a real, independent stub signal.
# Matches "def name(...):" or "def name(...) -> Type:" followed by exactly
# one placeholder statement and nothing else before the next def/class/EOF.
# Excludes bodies immediately preceded by @abstractmethod/@abstractproperty
# (or similar) since `pass` there is the correct, intended implementation
# of an abstract interface method, not missing work.
_EMPTY_FUNCTION_BODY_RE = re.compile(
    r'^(?!.*@abstract)[ \t]*def\s+\w+\s*\([^)]*\)\s*(->\s*[\w\[\], .\'"]+\s*)?:\s*\n'
    r'([ \t]*(#.*)?\n)*'
    r'[ \t]+(pass|\.\.\.|#\s*TODO.*)\s*\n'
    r'(?=[ \t]*(def |class |@|\Z)|\Z)',
    re.MULTILINE | re.IGNORECASE,
)


def _strip_abstract_method_bodies(content: str) -> str:
    """Remove @abstractmethod-decorated def blocks before stub-body scanning,
    so a legitimate empty abstract method doesn't trigger the regex above and
    doesn't get counted (or miscounted) by the earlier line-based checks."""
    return re.sub(
        r'@abstract\w*\s*\n([ \t]*def\s+\w+\s*\([^)]*\)\s*(->\s*[\w\[\], .\'"]+\s*)?:\s*\n'
        r'(?:[ \t]*(?:#.*)?\n)*[ \t]+(?:pass|\.\.\.)\s*\n)',
        '', content,
    )


def _looks_like_stub(path: str, content: str) -> bool:
    """Best-effort detector for placeholder/non-implementation output.

    Strips blank lines, comments, imports, and `def main(): ...` boilerplate,
    then flags the file only if what remains is EMPTY, or every remaining
    line matches a known placeholder pattern (`print("hi")`, bare `pass`,
    `...`, a bare TODO comment). Deliberately does not use a minimum line
    count: a short file can be a complete, correct implementation (a tiny
    helper, a config module, an `__init__.py` re-export), so brevity alone
    is never treated as evidence of a stub — only content is.
    """
    code_exts = (".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb", ".cs", ".cpp", ".c")
    if not path.lower().endswith(code_exts):
        return False
    # __init__.py legitimately contains nothing but imports/re-exports in
    # the common case — that is its whole job, not a sign of missing work.
    if path.rsplit("/", 1)[-1] == "__init__.py":
        return False
    lines = [ln.strip() for ln in content.splitlines()]
    substantive = [
        ln for ln in lines
        if ln
        and not ln.startswith(("#", "//", "/*", "*"))
        and not ln.startswith(("import ", "from ", "package ", "using "))
        and ln not in ("{", "}")
        and ln not in _MAIN_BOILERPLATE
    ]
    if not substantive:
        return True
    if all(any(p.match(ln) for p in _STUB_BODY_PATTERNS) for ln in substantive):
        return True
    # Whole-file check above catches "the entire file is one placeholder";
    # this catches "one specific function/method body is a placeholder"
    # even inside an otherwise real, multi-function file. Abstract-method
    # bodies are stripped first since `pass` there is intentional, not a
    # sign of missing work.
    return bool(_EMPTY_FUNCTION_BODY_RE.search(_strip_abstract_method_bodies(content)))


class WorkflowEngine:
    def __init__(self) -> None:
        self.states = ProjectStateManager()
        self.memory = MemoryManager()
        self.decisions = DecisionEngine(self.memory)
        self.policy = PolicyEngine()
        self.confidence_gate = ConfidenceGate(self.policy)
        self.quality = QualityScorer()
        self.test_runner = TestRunner()
        self.retry_manager = RetryManager(max_attempts=self.policy.settings.max_review_rounds)
        self.parallel = ParallelExecutor()
        self.kg = KnowledgeGraph()
        self.ai_manager = AIManager()
        self.prompt_optimizer_stats = PromptOptimizationStats()
        # ---- manual "quick finish" switch -----------------------------
        # Feature request: "a manual exit for when I want the result now
        # and scores don't matter — becomes active right after the first
        # score, closes further scoring, and finishes the project."
        # Implemented as a background stdin listener (doesn't block the
        # async pipeline) that arms itself the moment the first review
        # score is produced. Typing "f" + Enter at any point after that
        # sets the event; every stage handler below checks it and, once
        # set, stops calling Reviewer/Debugger entirely and takes
        # whatever the project currently has straight to Output.
        self._quick_finish_event = threading.Event()
        self._quick_finish_thread: threading.Thread | None = None

    def _arm_quick_finish_listener(self) -> None:
        if self._quick_finish_thread is not None:
            return
        import sys
        if not sys.stdin.isatty():
            logger.debug("Quick Finish listener disabled: stdin is not an interactive TTY.")
            return
        print(
            "\n[Quick Finish] اولین نمره ثبت شد. هر وقت خواستید بدون نمره‌دهی/دیباگ بیشتر "
            "نتیجه‌ی فعلی نهایی شود، حرف f را تایپ کنید و Enter بزنید.\n"
        )

        def _listen() -> None:
            while not self._quick_finish_event.is_set():
                try:
                    line = input()
                except (EOFError, RuntimeError):
                    return
                if line.strip().lower() == "f":
                    self._quick_finish_event.set()
                    print("[Quick Finish] فعال شد — نتیجه‌ی فعلی نهایی می‌شود، بدون نمره‌دهی/دیباگ بیشتر.\n")
                    return

        self._quick_finish_thread = threading.Thread(target=_listen, daemon=True)
        self._quick_finish_thread.start()

    # ---- entry point -------------------------------------------------------

    async def start_project(self, name: str, idea: str) -> ProjectState:
        state = self.states.create(name=name, original_idea=idea)
        self.memory.remember(state.project_id, key="original_idea", value=idea)
        self.kg.add_node(f"project:{state.project_id}", "project", state.project_id, name)
        logger.info("Project '%s' created (%s)", name, state.project_id)
        return await self.advance(state)

    async def resume_project(self, project_id: str) -> ProjectState:
        state = self.states.load(project_id)
        logger.info("Resuming project '%s' from stage %s", project_id, state.stage.value)
        return await self.advance(state)

    # ---- the main state machine ---------------------------------------------

    async def advance(self, state: ProjectState) -> ProjectState:
        """Runs stages until the project reaches DONE, FAILED, or a
        stage that requires user input the caller must supply
        (e.g. a PENDING_USER decision) — at which point it returns
        control with the current state."""
        while state.stage not in (ProjectStage.DONE, ProjectStage.FAILED):
            handler = self._STAGE_HANDLERS[state.stage]
            try:
                state = await handler(self, state)
            except Exception as exc:  # noqa: BLE001 - final workflow boundary
                state.stage_error = f"{type(exc).__name__}: {exc}"
                self.memory.remember(
                    state.project_id,
                    key=f"stage_failure.{state.stage.value}",
                    value=state.stage_error,
                    tags=["workflow", "stage_failure"],
                )
                logger.exception("Unhandled exception in stage %s for project %s", state.stage.value, state.project_id)
                self.states.save(state)
                state = self.states.advance_stage(state, ProjectStage.FAILED)
        return state

    # ---- individual stage handlers -----------------------------------------

    async def _stage_received(self, state: ProjectState) -> ProjectState:
        return self.states.advance_stage(state, ProjectStage.IDEA_EXPANSION)

    async def _stage_idea_expansion(self, state: ProjectState) -> ProjectState:
        agent = get_agent(AgentRole.IDEA_EXPANDER, memory=self.memory)
        response = await agent.run(state.project_id, task_description=state.original_idea)
        self.memory.promote_to_long(state.project_id, key="blueprint", value=response.answer)
        for proposed in response.decisions_proposed:
            self.decisions.decide(state.project_id, proposed.topic, [proposed.value],
                                   {proposed.value: proposed.reasons})
        self.memory.compact_short_memory(state.project_id, "Idea expansion complete.")
        return self.states.advance_stage(state, ProjectStage.RESEARCH)

    async def _stage_research(self, state: ProjectState) -> ProjectState:
        researcher = get_agent(AgentRole.RESEARCHER, memory=self.memory) if self.policy.settings.use_research else None
        blueprint = self.memory.recall(state.project_id, "blueprint") or state.original_idea
        if researcher is None:
            self.memory.promote_to_long(
                state.project_id,
                key="research_findings",
                value="Research skipped in fast/local mode.",
            )
        else:
            try:
                outcome = await researcher.run(
                    state.project_id,
                    task_description=f"Research only if a current external dependency choice is genuinely uncertain:\n{blueprint}",
                )
                value = outcome.answer if hasattr(outcome, "answer") else str(outcome)
                self.memory.promote_to_long(state.project_id, key="research_findings", value=value)
            except Exception as exc:
                logger.warning("Research stage failed: %s", exc)
                self.memory.promote_to_long(
                    state.project_id,
                    key="research_findings",
                    value=f"Research unavailable: {type(exc).__name__}: {exc}",
                    tags=["research", "failure"],
                )
        return self.states.advance_stage(state, ProjectStage.ARCHITECTURE)

    async def _stage_architecture(self, state: ProjectState) -> ProjectState:
        """Architecture consumes persisted research findings deterministically."""
        architect = get_agent(AgentRole.CHIEF_ARCHITECT, memory=self.memory)
        blueprint = self.memory.recall(state.project_id, "blueprint") or state.original_idea
        research = self.memory.recall(state.project_id, "research_findings") or "No research findings were available."
        try:
            arch_result = await architect.run(
                state.project_id,
                task_description=(
                    f"Propose an architecture for a SINGLE-USER personal tool implementing:\n{blueprint}\n"
                    f"Prefer simplicity over scale.\n\nResearch findings to incorporate when relevant:\n{research}"
                ),
            )
            assessment = self.confidence_gate.assess(arch_result)
            if assessment.verdict == ConfidenceVerdict.PARSE_FAILED:
                logger.error(
                    "Architecture stage received unparseable response after all attempts (parse, repair, model retry): %s",
                    assessment.reason,
                )
                state.stage_error = f"Architecture stage failed: response unparseable (parse_failed): {assessment.reason}"
                self.states.save(state)
                return self.states.advance_stage(state, ProjectStage.FAILED)

            if assessment.verdict == ConfidenceVerdict.BLOCK:
                logger.error(
                    "Architecture proposal blocked by Confidence Gate (confidence=%d): %s",
                    assessment.confidence, assessment.reason,
                )
                return self.states.advance_stage(state, ProjectStage.FAILED)

            if assessment.verdict == ConfidenceVerdict.SEEK_SECOND_OPINION and not state.architecture_second_opinion_used:
                state.architecture_second_opinion_used = True
                self.states.save(state)
                judge = get_agent(AgentRole.JUDGE, memory=self.memory)
                second_opinion_agent = get_agent(AgentRole.RESEARCHER, memory=self.memory)
                second_opinion = await second_opinion_agent.run(
                    state.project_id,
                    task_description=(
                        f"Act as an independent architecture critic. A previous architecture proposal had low confidence "
                        f"({assessment.confidence}). Unknown parts flagged: {assessment.unknown_parts}. "
                        f"Produce an alternative, implementation-ready architecture for:\n{blueprint}\n\nResearch findings:\n{research}"
                    ),
                )
                winning_text = await judge.pick_best(
                    state.project_id,
                    topic="architecture",
                    candidates={"first_attempt": arch_result.answer, "second_attempt": second_opinion.answer},
                )
                if winning_text.strip() != arch_result.answer.strip():
                    arch_result = second_opinion
            elif assessment.verdict == ConfidenceVerdict.SEEK_SECOND_OPINION:
                logger.warning("Architecture second opinion already consumed; proceeding with current proposal.")

            self.memory.promote_to_long(state.project_id, key="architecture", value=arch_result.answer)
            for proposed in arch_result.decisions_proposed:
                self.decisions.decide(
                    state.project_id,
                    proposed.topic,
                    [proposed.value],
                    {proposed.value: proposed.reasons},
                )
        except Exception as exc:
            logger.exception("Architecture stage failed for project %s", state.project_id)
            state.stage_error = f"{type(exc).__name__}: {exc}"
            self.states.save(state)
            return self.states.advance_stage(state, ProjectStage.FAILED)

        self.memory.compact_short_memory(state.project_id, "Research + architecture complete.")
        return self.states.advance_stage(state, ProjectStage.PLANNING)

    async def _stage_planning(self, state: ProjectState) -> ProjectState:
        planner = get_agent(AgentRole.PLANNER, memory=self.memory)
        response = await planner.run(
            state.project_id,
            task_description="Break the blueprint and architecture into a Task Tree "
                              "using the `tasks_proposed` field of the required output format.",
        )

        tree = TaskTree()
        proposed_to_task: dict[int, Task] = {}

        if response.tasks_proposed:
            # Preferred path: structured field from the Output Contract.
            # Build two lookup indexes:
            #  1. key_to_id: model-assigned snake_case key -> task_id
            #     (exact, zero fuzzy matching needed)
            #  2. normalized_to_ids: normalized title -> [task_id]
            #     (fallback for models that ignore the key field or use
            #     titles in depends_on_titles instead of keys)
            # Resolution tries key_to_id first (exact, reliable), then
            # falls back to the fuzzy title resolver only if necessary.
            key_to_id: dict[str, str] = {}
            normalized_to_ids: dict[str, list[str]] = {}
            seen_task_keys: set[str] = set()
            for proposed in response.tasks_proposed:
                normalized_title = self._normalize_task_title(proposed.title)
                if not normalized_title:
                    logger.warning("Planner emitted an empty task title; skipping it.")
                    continue
                task_key = (proposed.key or "").strip()
                if task_key and task_key in seen_task_keys:
                    logger.warning("Planner emitted duplicate task key %r; skipping duplicate.", task_key)
                    continue
                if task_key:
                    seen_task_keys.add(task_key)
                task = Task(
                    project_id=state.project_id, title=proposed.title, description=proposed.title,
                    effort=proposed.effort or "M", risk=proposed.risk or "low",
                    deferred=proposed.deferred,
                )
                proposed_to_task[id(proposed)] = task
                # Register by key (exact, preferred)
                task_key = (proposed.key or "").strip()
                if task_key:
                    key_to_id[task_key] = task.task_id
                # Register by normalized title (fuzzy fallback)
                normalized_to_ids.setdefault(self._normalize_task_title(proposed.title), []).append(task.task_id)
                tree.add(task)

            try:
                for proposed in response.tasks_proposed:
                    task = proposed_to_task.get(id(proposed))
                    if task is None:
                        continue
                    resolved_dependencies: list[str] = []
                    missing: list[str] = []

                    for dependency_ref in proposed.depends_on_titles:
                        # Try exact key lookup first (model used the key field
                        # correctly -- no fuzzy matching needed at all)
                        dependency_id = key_to_id.get(dependency_ref.strip())
                        if dependency_id is None:
                            # Fall back to fuzzy title resolution for models
                            # that wrote full titles instead of keys
                            dependency_id = self._resolve_task_title_reference(
                                dependency_ref, normalized_to_ids, tree
                            )
                        if dependency_id is None:
                            missing.append(dependency_ref)
                        else:
                            resolved_dependencies.append(dependency_id)

                    if missing:
                        logger.error(
                            "Planner task '%s' references unresolved dependency/dependencies: %s. "
                            "Refusing to drop dependency edges because doing so can violate execution order.",
                            proposed.title, missing,
                        )
                        self.memory.remember(
                            state.project_id,
                            key=f"invalid_dependency.{task.task_id}",
                            value=f"Task '{proposed.title}' declared unresolved dependencies: {missing}",
                            tags=["planner", "invalid_dependency"],
                        )
                        state = self.states.sync_task_tree(state, tree)
                        return self.states.advance_stage(state, ProjectStage.FAILED)

                    task.depends_on = resolved_dependencies

                tree.validate()
            except DependencyCycleError as exc:
                logger.error("Invalid planner Task Tree for project %s: %s", state.project_id, exc)
                return self.states.advance_stage(state, ProjectStage.FAILED)
        else:
            # Fallback for a model that ignored the structured field and
            # only wrote prose: try the old pipe-delimited text format
            # before giving up. Logged loudly since it signals a prompt
            # that needs tightening for this particular model.
            logger.warning(
                "Planner for project %s returned no tasks_proposed; "
                "falling back to legacy text parsing of `answer`.", state.project_id,
            )
            tree = self._parse_legacy_task_lines(state.project_id, response.answer)

        if not tree.tasks:
            # Absolute last resort: create one catch-all task so the
            # pipeline doesn't silently skip straight to an empty
            # Coding/Review stage. This is a visible, logged failure
            # mode rather than a silent one.
            logger.error(
                "Planner produced zero tasks for project %s even after fallback parsing. "
                "Creating a single catch-all task from the blueprint.", state.project_id,
            )
            blueprint = self.memory.recall(state.project_id, "blueprint") or state.original_idea
            fallback_task = Task(
                project_id=state.project_id, title="Implement project (planner produced no tasks)",
                description=blueprint, risk="high",
            )
            tree.add(fallback_task)

        # Deterministic safety rail against Planner over-engineering.  The
        # questionnaire preferences (High/Large/Strong UI) are subordinate to
        # the actual project requirements.  A simple utility must not become a
        # GUI/database/authentication application merely because those
        # preferences were selected.  The prompt is the primary control; this
        # post-planner guard is the enforcement layer for local models that
        # ignore the instruction.
        if self._looks_like_simple_request(state.original_idea):
            normalized_idea = self._normalize_task_title(state.original_idea)
            explicit_gui = any(token in normalized_idea for token in (
                "tkinter", "gui", "graphical interface", "graphical ui",
                "desktop app", "رابط گرافیکی", "رابط کاربری گرافیکی",
            ))
            explicit_database = any(token in normalized_idea for token in (
                "sqlite", "database", "db", "پایگاه داده", "دیتابیس",
            ))
            explicit_auth = any(token in normalized_idea for token in (
                "authentication", "login", "sign in", "password", "احراز هویت",
                "ورود", "رمز عبور",
            ))
            forbidden_without_explicit = set()
            if not explicit_gui:
                forbidden_without_explicit.update({"tkinter", "gui", "graphical interface", "graphical ui"})
            if not explicit_database:
                forbidden_without_explicit.update({"sqlite", "database", "data storage", "storage layer"})
            if not explicit_auth:
                forbidden_without_explicit.update({"authentication", "login", "user profiles", "rbac", "oauth"})
            forbidden_without_explicit.update({
                "admin panel", "api server", "deployment infrastructure",
                "cloud services", "package application for distribution",
                "visual appeal", "ui customization", "user interface optimization",
            })

            suspicious = [
                t.title for t in tree.tasks.values()
                if any(term in self._normalize_task_title(t.title) for term in forbidden_without_explicit)
            ]
            if len(tree.tasks) > 7 or suspicious:
                logger.warning(
                    "Planner over-engineering guard triggered for project %s: %d tasks; "
                    "suspicious/unrequested tasks=%s. Rebuilding a minimal task tree.",
                    state.project_id, len(tree.tasks), suspicious,
                )
                tree = self._build_minimal_simple_task_tree(state.project_id, state.original_idea)
                tree.validate()
                self.memory.remember(
                    state.project_id,
                    key="planner.overengineering_repaired",
                    value=(
                        f"Replaced over-engineered {len(suspicious)} suspicious/unrequested "
                        f"planner tasks with a minimal requirements-driven task tree."
                    ),
                    tags=["planner", "overengineering", "repaired"],
                )

        state = self.states.sync_task_tree(state, tree)
        self.memory.compact_short_memory(state.project_id, f"Planning complete: {len(tree.tasks)} tasks created.")
        return self.states.advance_stage(state, ProjectStage.CODING)

    @staticmethod
    def _build_minimal_simple_task_tree(project_id: str, idea: str) -> TaskTree:
        """Build a deterministic fallback plan for genuinely small utility requests.

        This is intentionally requirement-driven: it contains only a core
        implementation task, a proportionate verification task, and optional
        documentation when the user explicitly requests run instructions/docs.
        It prevents questionnaire preferences from creating unrelated
        subsystems such as GUI, database, authentication, packaging, or admin.
        """
        tree = TaskTree()
        core = Task(
            project_id=project_id,
            title="Implement core functionality",
            description=idea,
            effort="S",
            risk="low",
        )
        tree.add(core)

        tests = Task(
            project_id=project_id,
            title="Verify core functionality",
            description="Add focused verification/tests for the explicitly requested behavior.",
            effort="S",
            risk="low",
            depends_on=[core.task_id],
        )
        tree.add(tests)

        normalized = WorkflowEngine._normalize_task_title(idea)
        asks_for_docs = any(token in normalized for token in (
            "how_to_run", "how to run", "run instructions", "readme",
            "documentation", "دستور اجرا", "راهنمای اجرا", "مستندات",
        ))
        if asks_for_docs:
            docs = Task(
                project_id=project_id,
                title="Create requested run documentation",
                description="Create only the explicitly requested run/documentation file(s).",
                effort="S",
                risk="low",
                depends_on=[core.task_id],
            )
            tree.add(docs)
        return tree

    @staticmethod
    def _looks_like_simple_request(idea: str) -> bool:
        """Conservatively identify short, utility-style requests for guardrails."""
        normalized = WorkflowEngine._normalize_task_title(idea)
        words = normalized.split()
        simple_markers = {
            "simple", "basic", "small", "greeting", "hello", "calculator",
            "utility", "tool", "script", "echo", "print", "cli", "command",
            "ساده", "ابزار", "سلام", "محاسبه",
        }
        if len(words) > 24:
            return False
        word_set = set(words)
        strong_phrases = (
            "command line utility", "simple cli", "basic calculator",
            "hello world", "echo utility", "simple script",
        )
        return any(marker in word_set for marker in simple_markers) or any(
            phrase in normalized for phrase in strong_phrases
        )

    @staticmethod
    def _normalize_task_title(title: str) -> str:
        """Normalize human-written Planner dependency references.

        Dependency references are generated by an LLM, so harmless
        punctuation/wording variants must not turn a valid graph into a
        false dangling-dependency failure. This normalizer intentionally
        stays conservative: it changes Unicode normalization, case,
        separators and punctuation, but does not invent synonyms.
        """
        value = unicodedata.normalize("NFKC", title or "").casefold()
        value = value.replace("&", " and ").replace("/", " and ").replace("\\", " and ")
        value = re.sub(r"[^\w\s]+", " ", value, flags=re.UNICODE)
        return re.sub(r"\s+", " ", value).strip()

    @classmethod
    def _resolve_task_title_reference(
        cls, dependency_title: str, normalized_to_ids: dict[str, list[str]], tree: TaskTree
    ) -> str | None:
        """Resolve a Planner dependency title to one and only one Task ID.

        Resolution order:
        1. canonical normalized title;
        2. unique token-subset match (the Planner referenced a task by a
           shortened form of its title, e.g. "Income/Expense Recording"
           for the actual task "Implement Income/Expense Recording" --
           missing only a leading verb like Implement/Design/Develop);
        3. conservative fuzzy match for small wording differences.

        A fuzzy match is accepted only when it is clearly unique, preventing
        silent miswiring when two task titles are similar.
        """
        normalized = cls._normalize_task_title(dependency_title)
        exact = normalized_to_ids.get(normalized, [])
        if len(exact) == 1:
            return exact[0]
        if len(exact) > 1:
            return None

        query_tokens = set(normalized.split())

        # Token-subset match: this covers the single most common real
        # failure seen in production -- the Planner drops a task's
        # leading verb when citing it as a dependency elsewhere (e.g.
        # citing "Implement Income/Expense Recording" as just
        # "Income/Expense Recording"). Character-ratio scoring alone
        # under-rates this: adding one whole extra word to a short
        # title can swing SequenceMatcher's ratio below the 0.88/0.93
        # acceptance bar even though which task is meant is completely
        # unambiguous. A strict token subset -- every word in the
        # dependency title also appears in the candidate's title, and
        # the candidate has at least one extra word -- is a stronger,
        # more targeted signal than the character ratio for exactly
        # this pattern, so it gets its own acceptance path, gated the
        # same way on uniqueness.
        if len(query_tokens) >= 2:
            subset_matches = [
                task.task_id
                for task in tree.tasks.values()
                if (candidate_tokens := set(cls._normalize_task_title(task.title).split()))
                > query_tokens  # proper superset: all query words present, plus more
            ]
            if len(subset_matches) == 1:
                return subset_matches[0]

        candidates: list[tuple[float, str]] = []
        for task in tree.tasks.values():
            candidate = cls._normalize_task_title(task.title)
            ratio = difflib.SequenceMatcher(None, normalized, candidate).ratio()
            candidate_tokens = set(candidate.split())
            overlap = (len(query_tokens & candidate_tokens) / len(query_tokens | candidate_tokens)) if query_tokens and candidate_tokens else 0.0
            score = max(ratio, overlap)
            if ratio >= 0.88 or (overlap >= 0.80 and len(query_tokens) >= 2):
                candidates.append((score, task.task_id))

        candidates.sort(reverse=True)
        if not candidates:
            return None
        best_score, best_id = candidates[0]
        second_score = candidates[1][0] if len(candidates) > 1 else 0.0
        if best_score >= 0.93 or (best_score >= 0.88 and best_score - second_score >= 0.05):
            return best_id
        return None

    @staticmethod
    def _parse_legacy_task_lines(project_id: str, answer_text: str) -> TaskTree:
        """Best-effort fallback parser for 'title | deps | effort | risk'
        text lines, kept only as a safety net behind the structured
        `tasks_proposed` field (see _stage_planning above)."""
        tree = TaskTree()
        title_to_ids: dict[str, list[str]] = {}
        lines = [ln.strip() for ln in answer_text.splitlines() if ln.strip() and "|" in ln]

        parsed_lines = []
        for line in lines:
            parts = [p.strip() for p in line.split("|")]
            title = parts[0] if parts and parts[0] else line
            deps_raw = parts[1] if len(parts) > 1 else "none"
            effort = parts[2] if len(parts) > 2 else "M"
            risk = parts[3] if len(parts) > 3 else "low"
            task = Task(project_id=project_id, title=title, description=title,
                        effort=effort or "M", risk=risk or "low")
            title_to_ids.setdefault(WorkflowEngine._normalize_task_title(title), []).append(task.task_id)
            parsed_lines.append((task, deps_raw))

        for task, deps_raw in parsed_lines:
            if deps_raw and deps_raw.lower() != "none":
                deps: list[str] = []
                for dep in deps_raw.split(","):
                    ids = title_to_ids.get(WorkflowEngine._normalize_task_title(dep.strip()), [])
                    if len(ids) == 1:
                        deps.append(ids[0])
                    elif dep.strip():
                        logger.error("Legacy planner dependency %r is missing or ambiguous for task %r", dep.strip(), task.title)
                task.depends_on = deps
            tree.add(task)
        return tree

    async def _stage_coding(self, state: ProjectState) -> ProjectState:
        tree = self.states.task_tree_of(state)
        file_manager = FileManager(self.states.project_root(state.project_id))
        programmer = get_agent(AgentRole.PROGRAMMER, memory=self.memory)
        prompt_engineer = get_agent(AgentRole.PROMPT_ENGINEER, memory=self.memory) if self.policy.settings.use_prompt_engineer else None
        simulation = SimulationEngine(memory=self.memory)

        # A persisted RUNNING state is only meaningful while this process is
        # actually executing. If the previous process crashed/restarted, a
        # stale RUNNING task can make the dependency graph look deadlocked
        # forever. Recover it before calculating the first ready batch.
        recovered_running = tree.recover_stale_running()
        if recovered_running:
            logger.warning(
                "Recovered %d stale RUNNING task(s) for project %s: %s",
                len(recovered_running), state.project_id,
                [t.title for t in recovered_running],
            )
            state = self.states.sync_task_tree(state, tree)

        # Tasks flagged deferred=True by the Planner are intentionally
        # out of scope for this build. Mark them DEFERRED immediately so
        # ready_tasks() / all_done() / the deadlock detector all agree on
        # what "done" means and don't include them in unfinished/ready
        # counts. Without this, a deferred task sits PENDING forever,
        # ready_tasks() skips it (because deferred=True), and the
        # deadlock detector eventually sees "unfinished tasks that are
        # not ready and not rejected" -- which is exactly the failure
        # mode that caused "Coding blocked: no runnable tasks remain".
        for task in tree.tasks.values():
            if task.deferred and task.status == TaskStatus.PENDING:
                task.status = TaskStatus.DEFERRED
        state = self.states.sync_task_tree(state, tree)

        iteration = 0
        no_progress_rounds = 0
        iteration_limit = max(
            _DEFAULT_CODING_ITERATION_CEILING,
            len(tree.tasks) * 20 + 20,
        )
        while not tree.all_done():
            iteration += 1
            if iteration > iteration_limit:
                logger.error(
                    "Coding scheduler exceeded safety ceiling (%d iterations) for project %s; failing safely.",
                    iteration_limit, state.project_id,
                )
                return self.states.advance_stage(state, ProjectStage.FAILED)
            before = tuple(sorted((t.task_id, t.status.value, t.coding_retries, t.confidence_retries, t.debug_retries) for t in tree.tasks.values()))
            ready = tree.ready_tasks()
            if not ready:
                unfinished = [
                    t for t in tree.tasks.values()
                    if t.status not in (TaskStatus.ACCEPTED, TaskStatus.DEFERRED, TaskStatus.REJECTED)
                    and not t.deferred  # deferred tasks are intentionally skipped;
                                        # they count as done for deadlock detection
                ]
                if not unfinished:
                    # Nothing left to run; every remaining task is a
                    # terminal state (ACCEPTED/DEFERRED/REJECTED).
                    break

                # A resumed project may contain a task that was RUNNING when
                # the previous process died. recover_stale_running() handles
                # the common case at stage entry, but repeat the check here
                # because task state can be loaded/updated between stages.
                recovered_running = tree.recover_stale_running()
                if recovered_running:
                    logger.warning(
                        "Recovered stale RUNNING task(s) during coding deadlock check: %s",
                        [t.title for t in recovered_running],
                    )
                    state = self.states.sync_task_tree(state, tree)
                    continue

                # A missing dependency is a correctness failure, not an edge
                # we are allowed to silently delete. The planner stage should
                # already have rejected such a graph; this guard protects
                # resumed/legacy state from executing tasks out of order.
                for task in unfinished:
                    missing_refs = [dep for dep in task.depends_on if dep not in tree.tasks]
                    if missing_refs:
                        logger.error(
                            "Task '%s' has missing dependency edge(s): %s; refusing to execute out of order.",
                            task.title, missing_refs,
                        )
                        task.status = TaskStatus.BLOCKED
                if any(t.status == TaskStatus.BLOCKED for t in unfinished):
                    state = self.states.sync_task_tree(state, tree)
                    return self.states.advance_stage(state, ProjectStage.FAILED)

                # A task permanently blocks every task that depends on
                # it once it's REJECTED (see TaskTree.ready_tasks): its
                # dependents can never see ACCEPTED/NEEDS_REVIEW on that
                # edge, so they can never become ready either. Left
                # alone this cascades into exactly the unrecoverable
                # "no runnable tasks remain" dead end seen in production
                # (a Design/UI task rejected on low confidence blocked
                # every other task in the project). Instead of failing
                # the whole project over one bad task, cascade-reject
                # anything that can only ever be blocked by a REJECTED
                # dependency, and let Review/Debug/Output handle them as
                # known issues -- same treatment a task gets if it's
                # rejected later, during Review.
                # Propagate dependency failures to descendants. This is
                # intentionally iterative: a task rejected in this pass can
                # block another task, which then becomes a blocker itself on
                # the next pass. Missing dependencies are also treated as
                # blockers so legacy/persisted malformed trees cannot sit
                # PENDING forever.
                cascaded = []
                for task, blockers in tree.blocked_tasks():
                    if task not in unfinished:
                        continue
                    task.status = TaskStatus.REJECTED
                    cascaded.append((task, blockers))
                    blocker_text = ", ".join(blockers)
                    self.memory.remember(
                        state.project_id,
                        key=f"cascaded_rejection.{task.task_id}",
                        value=(
                            f"Task '{task.title}' was never coded because dependency "
                            f"blockers were detected: {blocker_text}."
                        ),
                        tags=["coding", "cascaded_rejection"],
                    )
                    logger.warning(
                        "Task '%s' blocked by dependencies %s; marking it REJECTED "
                        "instead of leaving it permanently PENDING.",
                        task.title, blocker_text,
                    )

                if cascaded:
                    continue

                # At this point there are unfinished tasks, none is ready, and
                # none has a missing/rejected/failed dependency. That is not a
                # normal dependency cascade; it indicates a cycle or an
                # internal scheduler/state invariant violation. Never reject
                # every remaining task just to force progress. Fail loudly with
                # enough diagnostics to fix the real graph/scheduler bug.
                logger.error(
                    "Coding blocked for project %s: no runnable tasks remain while unfinished tasks exist: %s",
                    state.project_id, [t.title for t in unfinished],
                )
                state = self.states.sync_task_tree(state, tree)
                return self.states.advance_stage(state, ProjectStage.FAILED)

            async def run_task(task=None):
                task.status = TaskStatus.RUNNING

                extra_context = ""
                if self.policy.settings.use_simulation:
                    # Simulation-before-execution: reason through the
                    # task's likely risks BEFORE writing any code, per
                    # the design doc's "think first, then act" principle.
                    # A BLOCK verdict skips execution entirely (task ->
                    # REJECTED, handled by the existing Debug loop); WARN
                    # proceeds but hands the predicted risks to the
                    # Programmer as extra context.
                    sim_result = await simulation.simulate(
                        state.project_id, task.title, task.description or task.title,
                        project_context=self.memory.context_for_stage(state.project_id, max_chars=2000),
                    )
                    if sim_result.verdict == SimulationVerdict.BLOCK:
                        logger.warning(
                            "Simulation BLOCKED task '%s' before execution. Risks: %s",
                            task.title, sim_result.predicted_risks,
                        )
                        self.memory.remember(
                            state.project_id, key=f"simulation_block.{task.task_id}",
                            value=f"{sim_result.reasoning}\nRisks: {sim_result.predicted_risks}",
                            tags=["simulation", "blocked"],
                        )
                        return task, None, 0  # signals "do not attempt coding" to the caller

                    if sim_result.verdict == SimulationVerdict.WARN and sim_result.predicted_risks:
                        extra_context = (
                            "Pre-execution simulation flagged these risks — address them in "
                            f"your implementation: {sim_result.predicted_risks}"
                        )

                # Ask AIManager which MODEL will actually handle this
                # Programmer call BEFORE optimizing the prompt, so the
                # Prompt Optimizer can tailor style/length guidance to
                # that specific model instead of optimizing blind.
                # (Local-only build: provider is always "ollama_local",
                # so the model name is what actually varies.)
                ranked_programmer_routes = self.ai_manager.select_route("programmer")
                target_model = ranked_programmer_routes[0].model if ranked_programmer_routes else None

                raw_task_desc = task.description or task.title
                existing_files: list[str] = []
                for existing_path in file_manager.list_files():
                    content = file_manager.read_file(existing_path)
                    if content is None:
                        continue
                    if existing_path.endswith((".py", ".json", ".yaml", ".yml", ".toml", ".md")):
                        existing_files.append(f"--- {existing_path} ---\n{content}")
                existing_context = "\n\n".join(existing_files)[:6000]
                if existing_context:
                    raw_task_desc += (
                        "\n\nEXISTING PROJECT FILES (preserve working behavior; edit these "
                        "in place rather than creating a new file with a similar name — e.g. "
                        "if 'weather_analysis.py' already exists, update it, don't also create "
                        "'weather_analysis_tool.py' or similar):\n"
                        + existing_context
                    )
                if prompt_engineer is not None:
                    optimized_task_desc = await prompt_engineer.optimize(
                        state.project_id, AgentRole.PROGRAMMER, raw_task_desc,
                        target_model=target_model,
                    )
                else:
                    optimized_task_desc = raw_task_desc
                retry_reinforcement = ""
                if task.coding_retries > 0:
                    # Second attempt after a BLOCK/empty-output verdict.
                    # Re-stating the contract explicitly and in isolation
                    # (rather than trusting the model to infer it again
                    # from a long task description) is cheap and measurably
                    # reduces repeat JSON-contract failures on small local
                    # models.
                    retry_reinforcement = (
                        "\n\nIMPORTANT — RETRY: your previous attempt at this task could not be "
                        "used (invalid/unparseable output, no files produced, or only placeholder "
                        "stub content like `print(\"hi\")` / `pass` / empty bodies). Respond with "
                        "ONLY the required JSON output contract, no prose before or after it, "
                        "and make sure every file you propose has non-empty `path` and `content` "
                        "fields containing a REAL, COMPLETE implementation of exactly what the "
                        "task asks for — not a placeholder, not a one-line stub, not a summary of "
                        "what the code would do. You cannot run commands or describe steps for a "
                        "human to run — if this task names an action (install, run, set up, "
                        "deploy, migrate), you MUST instead write the file that action would "
                        "produce or require (e.g. for 'install dependencies', write/update "
                        "requirements.txt or pyproject.toml listing the packages). A response "
                        "with zero files, or with only stub/placeholder content, will be "
                        "rejected regardless of how correct the surrounding prose is."
                    )
                full_task_description = (
                    optimized_task_desc
                    + ("\n\n" + extra_context if extra_context else "")
                    + retry_reinforcement
                )
                response = await programmer.run(
                    state.project_id, task_description=full_task_description, task_id=task.task_id,
                )
                return task, response, len(full_task_description)

            if self.policy.settings.serial_coding:
                results = []
                for ready_task in ready:
                    try:
                        results.append((True, await run_task(ready_task)))
                    except Exception as exc:  # noqa: BLE001
                        results.append((False, exc))
            else:
                coro_fns = [(lambda t=t: run_task(t)) for t in ready]
                results = await self.parallel.run_all(coro_fns)

            for ready_task, (success, outcome) in zip(ready, results):
                if not success:
                    logger.error("Coding task '%s' raised an exception: %s", ready_task.title, outcome)
                    ready_task.status = TaskStatus.REJECTED
                    file_manager.release_task_locks(ready_task.task_id)
                    continue
                task, response, prompt_char_count = outcome

                if response is None:
                    # Simulation BLOCK path: skip straight to REJECTED so
                    # the existing Debug loop picks it up with the
                    # simulation's reasoning as context (see
                    # _stage_debug's test_failure_detail-style handoff).
                    task.status = TaskStatus.REJECTED
                    file_manager.release_task_locks(task.task_id)
                    continue

                assessment = self.confidence_gate.assess(response)
                if assessment.verdict == ConfidenceVerdict.PARSE_FAILED:
                    logger.warning(
                        "Programmer output for task '%s' had parser failure after all attempts: %s",
                        task.title, assessment.reason,
                    )
                    self.memory.remember(
                        state.project_id,
                        key=f"parse_failed_flag.{task.task_id}",
                        value=f"Task '{task.title}' parser failed after all model and repair attempts: {assessment.reason}",
                        tags=["parse_failed"],
                    )
                    # Parser failure is distinct from agent confidence; queue for retry if attempts remain
                    if task.coding_retries < _MAX_CODING_RETRIES:
                        task.coding_retries += 1
                        task.status = TaskStatus.PENDING
                        logger.warning(
                            "Task '%s' parser failed; queued for retry %d/%d before rejecting.",
                            task.title, task.coding_retries, _MAX_CODING_RETRIES,
                        )
                    else:
                        task.status = TaskStatus.REJECTED
                        logger.error(
                            "Task '%s' exhausted coding/parse retries (%d/%d); marking REJECTED.",
                            task.title, task.coding_retries, _MAX_CODING_RETRIES,
                        )
                    file_manager.release_task_locks(task.task_id)
                    continue

                if assessment.verdict != ConfidenceVerdict.PROCEED:
                    logger.warning(
                        "Programmer output for task '%s' has low confidence (%d): %s",
                        task.title, assessment.confidence, assessment.reason,
                    )
                    self.memory.remember(
                        state.project_id,
                        key=f"low_confidence_flag.{task.task_id}",
                        value=f"Programmer confidence={assessment.confidence}. "
                              f"Unknown parts: {assessment.unknown_parts}. Review carefully.",
                        tags=["confidence_flag"],
                    )
                    if assessment.verdict == ConfidenceVerdict.BLOCK:
                        # Confidence too low to trust even provisionally —
                        # do not write these files. Use a SEPARATE confidence
                        # retry counter (_MAX_CONFIDENCE_RETRIES) so these
                        # cheap retries don't burn the validation budget
                        # (_MAX_CODING_RETRIES) reserved for stub/path/empty
                        # failures. This prevents "4 confidence retries for
                        # README then Debug entered" patterns from the bug report.
                        if task.confidence_retries < _MAX_CONFIDENCE_RETRIES:
                            task.confidence_retries += 1
                            task.status = TaskStatus.PENDING
                            logger.warning(
                                "Task '%s' blocked on confidence (confidence=%d); queued for confidence "
                                "retry %d/%d before rejecting.",
                                task.title, assessment.confidence,
                                task.confidence_retries, _MAX_CONFIDENCE_RETRIES,
                            )
                        else:
                            task.status = TaskStatus.REJECTED
                            logger.warning(
                                "Task '%s' exhausted confidence retries (%d); marking REJECTED.",
                                task.title, _MAX_CONFIDENCE_RETRIES,
                            )
                        continue

                written_files = 0
                written_paths: list[str] = []
                invalid_paths: list[str] = []
                stub_paths: list[str] = []
                for f in response.files:
                    if _looks_like_stub(f.path, f.content):
                        stub_paths.append(str(f.path))
                        logger.warning(
                            "Programmer output for '%s' in task '%s' looks like a placeholder "
                            "stub, not a real implementation; rejecting this file.",
                            f.path, task.title,
                        )
                        continue
                    try:
                        file_manager.write_file(
                            f.path, f.content, task_id=task.task_id,
                            commit_message=f"Task {task.task_id}: {task.title}"
                        )
                    except (ValueError, TypeError) as exc:
                        invalid_paths.append(str(f.path))
                        logger.warning(
                            "Programmer proposed an invalid file for task '%s': %r (%s).",
                            task.title, f.path, exc,
                        )
                        continue
                    written_files += 1
                    written_paths.append(f.path)
                file_manager.release_task_locks(task.task_id)

                if stub_paths and not invalid_paths and written_files == 0:
                    self.memory.remember(
                        state.project_id, key=f"coding_stub_files.{task.task_id}",
                        value=", ".join(stub_paths), tags=["coding", "stub_output"],
                    )
                    if task.coding_retries < _MAX_CODING_RETRIES:
                        task.coding_retries += 1
                        task.status = TaskStatus.PENDING
                        logger.warning(
                            "Task '%s' produced only placeholder/stub content; queued for "
                            "retry (attempt %d) demanding a real implementation.",
                            task.title, task.coding_retries,
                        )
                        continue
                    task.status = TaskStatus.REJECTED
                    self.memory.remember(
                        state.project_id, key=f"coding_failure.{task.task_id}",
                        value=f"Only placeholder/stub content after retries: {stub_paths}",
                        tags=["coding", "failure"],
                    )
                    continue

                if invalid_paths:
                    self.memory.remember(
                        state.project_id, key=f"coding_invalid_files.{task.task_id}",
                        value=", ".join(invalid_paths), tags=["coding", "invalid_file_path"],
                    )
                    if task.coding_retries < _MAX_CODING_RETRIES:
                        task.coding_retries += 1
                        task.status = TaskStatus.PENDING
                        logger.warning(
                            "Task '%s' had invalid file paths; keeping valid writes but scheduling a retry "
                            "to repair the incomplete file set (attempt %d).",
                            task.title, task.coding_retries,
                        )
                        continue
                    task.status = TaskStatus.REJECTED
                    self.memory.remember(
                        state.project_id, key=f"coding_failure.{task.task_id}",
                        value=f"Invalid/unwritable file paths after retry: {invalid_paths}",
                        tags=["coding", "failure"],
                    )
                    continue

                if written_files == 0:
                    if task.coding_retries < _MAX_CODING_RETRIES:
                        task.coding_retries += 1
                        task.status = TaskStatus.PENDING
                        logger.warning(
                            "Programmer produced no valid files for task '%s'; queued for one "
                            "retry (attempt %d) before rejecting.",
                            task.title, task.coding_retries,
                        )
                        continue
                    logger.error(
                        "Programmer produced no valid files for task '%s' after retry; marking task REJECTED.",
                        task.title,
                    )
                    task.status = TaskStatus.REJECTED
                    self.memory.remember(
                        state.project_id, key=f"coding_failure.{task.task_id}",
                        value="Programmer returned no valid writable files.", tags=["coding", "failure"],
                    )
                    continue

                task.status = TaskStatus.NEEDS_REVIEW
                for path in written_paths:
                    self.kg.record_task_file(task.task_id, state.project_id, path, agent_run_id=task.task_id)
                self.memory.remember(
                    state.project_id, key=f"coding_provider.{task.task_id}",
                    value=f"{response.provider_used}|{response.model_used}|{prompt_char_count}",
                    tags=["routing"],
                )

            after = tuple(sorted((t.task_id, t.status.value, t.coding_retries, t.confidence_retries, t.debug_retries) for t in tree.tasks.values()))
            if after == before:
                no_progress_rounds += 1
                logger.error(
                    "Coding scheduler made no state progress for project %s at iteration %d (no-progress round %d).",
                    state.project_id, iteration, no_progress_rounds,
                )
                state = self.states.sync_task_tree(state, tree)
                return self.states.advance_stage(state, ProjectStage.FAILED)
            no_progress_rounds = 0
            state = self.states.sync_task_tree(state, tree)

        file_manager.checkpoint(label="post_coding")
        return self.states.advance_stage(state, ProjectStage.TESTING)

    async def _stage_review(self, state: ProjectState) -> ProjectState:
        """One deterministic review pass per task. A rejection does NOT
        trigger another review of identical code; it hands the review
        findings/solutions to Debug, which then creates a new candidate.
        This is the main anti-repeat guard in the workflow."""
        from orchestrator.quality.multi_reviewer import MultiReviewerConsensus

        tree = self.states.task_tree_of(state)
        file_manager = FileManager(self.states.project_root(state.project_id))
        reviewer = get_agent(AgentRole.REVIEWER, memory=self.memory)
        multi_reviewer = MultiReviewerConsensus(memory=self.memory, parallel=self.parallel)
        test_passed = self.memory.recall(state.project_id, "test_stage.overall_passed") == "True"

        for task in tree.tasks.values():
            if task.status != TaskStatus.NEEDS_REVIEW:
                continue

            if self._quick_finish_event.is_set():
                # User asked to stop scoring/debugging and take whatever
                # exists right now. Accept as-is without calling the
                # Reviewer at all — that's the whole point of "quick
                # finish": no more model calls spent on scoring.
                task.status = TaskStatus.ACCEPTED
                continue

            task_file_nodes = self.kg.neighbors(task.task_id, relation="produced")
            task_file_paths = [n.split("file:", 1)[1] for n in task_file_nodes if n.startswith("file:")]
            if not task_file_paths:
                logger.error(
                    "Reviewer has no file mapping for task '%s'; refusing to score unrelated project files.",
                    task.title,
                )
                task.status = TaskStatus.REJECTED
                self.memory.remember(
                    state.project_id,
                    key=f"review_missing_files.{task.task_id}",
                    value="Knowledge Graph contains no file mapping for this task.",
                    tags=["review", "missing_mapping"],
                )
                continue

            snapshot = file_manager.read_files_snapshot(task_file_paths)
            files_text = "\n\n".join(
                f"--- {path} ---\n{content}"
                for path in task_file_paths
                if (content := snapshot.get(path)) is not None
            )
            review_task_description = (
                f"Review the implementation of task '{task.title}'.\n"
                f"Return a strict score 0-100, concrete issues, and 1-5 actionable solutions.\n\n{files_text}"
            )

            if self.policy.settings.use_multi_reviewer:
                multi_result = await multi_reviewer.review(state.project_id, review_task_description, task.task_id)
                reviewer_numeric = (
                    sum(v.numeric_score for v in multi_result.verdicts) / len(multi_result.verdicts)
                    if multi_result.verdicts else 0.0
                )
                last_review_answer = multi_result.combined_reasoning
                review_solutions = [s for v in multi_result.verdicts if v.response for s in v.response.solutions]
            else:
                review = await reviewer.run(
                    state.project_id, task_description=review_task_description, task_id=task.task_id,
                )
                score_decisions = [d for d in review.decisions_proposed if d.topic == "review_score"]
                if score_decisions:
                    try:
                        reviewer_numeric = max(0.0, min(100.0, float(score_decisions[-1].value)))
                    except ValueError:
                        reviewer_numeric = float(review.confidence)
                else:
                    reviewer_numeric = float(review.confidence)
                last_review_answer = review.answer
                review_solutions = list(review.solutions)

            if review_solutions:
                self.memory.remember(
                    state.project_id, key=f"review_solution.{task.task_id}",
                    value="\n".join(f"- {item}" for item in review_solutions[:5]),
                    tags=["review", "solution"],
                )
            self.memory.remember(
                state.project_id, key=f"review_feedback.{task.task_id}",
                value=last_review_answer[:4000], tags=["review", "feedback"],
            )

            file_scores = [
                self.quality.score_file(
                    state.project_id, path, snapshot.get(path) or "",
                    reviewer_score=reviewer_numeric, test_passed=test_passed,
                )
                for path in task_file_paths
            ]
            score = min(file_scores, key=lambda item: item.final_score) if file_scores else self.quality.score_generic_artifact(
                state.project_id, "task", task.task_id, task.description, reviewer_score=reviewer_numeric
            )
            logger.info(score.report_line())
            self._arm_quick_finish_listener()  # no-op after the first call

            coding_provider_info = self.memory.recall(state.project_id, f"coding_provider.{task.task_id}")
            if coding_provider_info and coding_provider_info.count("|") == 2:
                used_provider, used_model, prompt_len_str = coding_provider_info.split("|", 2)
                self.ai_manager.record_outcome("programmer", used_provider, used_model, quality_score=score.final_score)
                try:
                    prompt_char_count = int(prompt_len_str)
                except ValueError:
                    prompt_char_count = 0
                if prompt_char_count > 0:
                    self.prompt_optimizer_stats.record("programmer", used_provider, prompt_char_count, score.final_score)

            syntax_ok = True
            for path in task_file_paths:
                if path.endswith(".py"):
                    try:
                        import ast as _ast
                        _ast.parse(snapshot.get(path) or "")
                    except SyntaxError:
                        syntax_ok = False
                        break

            if self.quality.passes(score) and syntax_ok:
                task.status = TaskStatus.ACCEPTED
            else:
                task.status = TaskStatus.REJECTED
                logger.warning("Task '%s' rejected by review; Debug will receive the concrete solution instead of repeating the review.", task.title)

            state.review_rounds_used += 1

        state = self.states.sync_task_tree(state, tree)
        if self._quick_finish_event.is_set():
            # Sweep any task left REJECTED from a review round that
            # happened BEFORE the user hit quick-finish — otherwise
            # they'd still trigger a Debug round we just promised to skip.
            for task in tree.tasks.values():
                if task.status == TaskStatus.REJECTED:
                    task.status = TaskStatus.ACCEPTED
            state = self.states.sync_task_tree(state, tree)
            return self.states.advance_stage(state, ProjectStage.OUTPUT)
        rejected = any(t.status == TaskStatus.REJECTED for t in tree.tasks.values())
        return self.states.advance_stage(state, ProjectStage.DEBUG if rejected else ProjectStage.OUTPUT)

    async def _stage_testing(self, state: ProjectState) -> ProjectState:
        file_manager = FileManager(self.states.project_root(state.project_id))
        project_root = self.states.project_root(state.project_id)

        syntax_result, pytest_result = self.test_runner.run(project_root)
        self.memory.remember(
            state.project_id, key="test_stage.syntax_check", value=syntax_result.summary, tags=["test"],
        )
        if pytest_result is not None:
            self.memory.remember(
                state.project_id, key="test_stage.pytest", value=pytest_result.summary, tags=["test"],
            )

        overall_passed = syntax_result.passed and (pytest_result is None or pytest_result.passed)
        self.memory.remember(
            state.project_id, key="test_stage.overall_passed", value=str(overall_passed), tags=["test"],
        )

        if not overall_passed:
            tree = self.states.task_tree_of(state)
            for task in tree.tasks.values():
                if task.status in (TaskStatus.NEEDS_REVIEW, TaskStatus.ACCEPTED):
                    task.status = TaskStatus.REJECTED
            state = self.states.sync_task_tree(state, tree)
            # KEY FIX: include precise failure_kind so the Debugger and logs
            # can distinguish SyntaxError / ModuleNotFoundError / TestFailure
            # instead of just "syntax/import check failed".
            failure_kind = syntax_result.failure_kind.value if not syntax_result.passed else (
                pytest_result.failure_kind.value if pytest_result and not pytest_result.passed else "Unknown"
            )
            self.memory.remember(
                state.project_id, key="test_stage.failure_detail",
                value=(
                    f"[{failure_kind}]\n"
                    f"syntax: {syntax_result.stderr[:1500]}\n"
                    f"pytest: {(pytest_result.stderr[:1500] if pytest_result else 'n/a')}"
                ),
                tags=["test", "failure"],
            )
            logger.warning(
                "Testing stage failed for project %s "
                "(failure_kind=%s, syntax_ok=%s, pytest=%s); sending tasks to Debug.",
                state.project_id, failure_kind, syntax_result.passed,
                pytest_result.passed if pytest_result else "no tests",
            )
            file_manager.checkpoint(label="post_testing_failed")
            return self.states.advance_stage(state, ProjectStage.DEBUG)

        file_manager.checkpoint(label="post_testing")
        return self.states.advance_stage(state, ProjectStage.REVIEW)

    async def _stage_debug(self, state: ProjectState) -> ProjectState:
        tree = self.states.task_tree_of(state)
        rejected = [t for t in tree.tasks.values() if t.status == TaskStatus.REJECTED]
        project_root = self.states.project_root(state.project_id)

        if self._quick_finish_event.is_set():
            for task in rejected:
                task.status = TaskStatus.ACCEPTED
            state = self.states.sync_task_tree(state, tree)
            return self.states.advance_stage(state, ProjectStage.OUTPUT)

        if not rejected:
            return self.states.advance_stage(state, ProjectStage.OUTPUT)
        debug_loop_limit = (
            self.policy.settings.max_debug_loops
            if self.policy.settings.max_debug_loops is not None
            else _DEFAULT_DEBUG_LOOP_CEILING
        )
        if state.debug_loops_used >= debug_loop_limit:
            logger.warning(
                "Project %s hit the debug loop ceiling (%d) with %d task(s) still rejected; "
                "moving to Output with those tasks flagged as known issues instead of looping "
                "further.", state.project_id, debug_loop_limit, len(rejected),
            )
            return self.states.advance_stage(state, ProjectStage.OUTPUT)

        # Maximum Debugger attempts per individual task. Raised from 2 to 4
        # because local/small models often need more attempts to produce
        # syntactically valid fixes, and the targeted gate now feeds precise
        # failure context (SyntaxError / ModuleNotFoundError details) back
        # into each subsequent Debugger call so retries are informed, not blind.
        max_debug_attempts_per_task = 4
        if all(t.debug_retries >= max_debug_attempts_per_task for t in rejected):
            self.memory.remember(
                state.project_id,
                key="debug.exhausted",
                value="All rejected tasks reached their per-task Debug retry limit.",
                tags=["debug", "exhausted"],
            )
            return self.states.advance_stage(state, ProjectStage.OUTPUT)

        debugger = get_agent(AgentRole.DEBUGGER, memory=self.memory)
        file_manager = FileManager(self.states.project_root(state.project_id))
        test_failure_detail = self.memory.recall(state.project_id, "test_stage.failure_detail")
        # Consume-and-clear: this detail is only valid for the immediate
        # Testing->Debug handoff. If we leave it in memory, a LATER debug
        # round triggered by an unrelated Review rejection would wrongly
        # see this stale failure text as if it were still current.
        if test_failure_detail is not None:
            self.memory.remember(
                state.project_id, key="test_stage.failure_detail", value="", tags=["test", "consumed"],
            )

        for task in rejected:
            # KEY FIX: skip tasks that have already exhausted their per-task
            # debug retry budget. Previously only the top-level all() check
            # existed, meaning exhausted tasks kept getting debug_retries+=1
            # and new Debugger calls every round indefinitely.
            if task.debug_retries >= max_debug_attempts_per_task:
                logger.warning(
                    "Task '%s' exhausted per-task debug budget (%d retries); skipping in this round.",
                    task.title, task.debug_retries,
                )
                continue

            task_file_nodes = self.kg.neighbors(task.task_id, relation="produced")
            task_file_paths = [n.split("file:", 1)[1] for n in task_file_nodes if n.startswith("file:")]
            if not task_file_paths:
                task_file_paths = []
            snapshot = file_manager.read_files_snapshot(task_file_paths)
            files_text = "\n\n".join(
                f"--- {p} ---\n{content}" for p, content in snapshot.items() if content is not None
            ) or "[No task-specific files are currently mapped in the Knowledge Graph.]"
            failure_context = (
                f"Test/build failure detail:\n{test_failure_detail}\n\n"
                if test_failure_detail else ""
            )
            # KEY FIX: surface the targeted-gate failure from the previous
            # debug attempt for this task (SyntaxError / ModuleNotFoundError
            # in the fix files). Without this, the Debugger retries with the
            # same prompt and produces the same broken fix repeatedly.
            prior_candidate_failure = self.memory.recall(
                state.project_id, f"debug_candidate_failure.{task.task_id}"
            )
            if prior_candidate_failure:
                failure_context += (
                    f"IMPORTANT — previous fix attempt was REJECTED by the validator:\n"
                    f"{prior_candidate_failure}\n\n"
                )
            # A task rejected via Simulation-before-execution (see
            # workflow/simulation.py) never reached the Programmer, so
            # it has no task-specific files and no Review feedback —
            # its ONLY diagnostic context is the simulation's predicted
            # risk. Surface that explicitly so the Debugger isn't
            # working blind.
            sim_block_detail = self.memory.recall(state.project_id, f"simulation_block.{task.task_id}")
            if sim_block_detail:
                failure_context += (
                    f"Pre-execution simulation blocked this task before any code was "
                    f"written, for this reason:\n{sim_block_detail}\n\n"
                )
            review_solution = self.memory.recall(state.project_id, f"review_solution.{task.task_id}")
            if review_solution:
                failure_context += f"Reviewer score/fix plan:\n{review_solution}\n\n"
            task.debug_retries += 1
            response = await debugger.run(
                state.project_id,
                task_description=f"Task '{task.title}' was rejected. {failure_context}"
                                  f"Diagnose the root cause and provide fixed files. Apply the reviewer solution when valid.\n\n{files_text}",
                task_id=task.task_id,
            )
            if not response.files:
                # A Debugger call that produced ZERO files (its own JSON
                # was unparseable, or the model just answered with prose)
                # previously fell through to the syntax gate below, which
                # trivially "passes" when there are no files to check —
                # so the task got marked NEEDS_REVIEW / eventually
                # accepted despite NO code ever being written for it.
                # For a task with no prior successful write (e.g. the
                # very first Programmer attempt already failed the same
                # way), that meant a project could reach Output with an
                # empty repo and nothing to show but the README. Keep it
                # REJECTED so this round is an honest no-op, not a false
                # "fixed".
                logger.warning(
                    "Debugger produced no files for task '%s' (confidence=%d); "
                    "leaving it REJECTED instead of treating an empty fix as success.",
                    task.title, response.confidence,
                )
                continue
            current_inputs = []
            for f in response.files:
                current_inputs.append((f.path, snapshot.get(f.path, "")))
            fingerprint = hashlib.sha256(
                json.dumps(
                    {
                        "task": task.task_id,
                        "attempt": task.debug_retries,
                        "inputs": current_inputs,
                        "failure": failure_context[:4000],
                        "candidate": [(f.path, f.content) for f in response.files],
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ).encode("utf-8")
            ).hexdigest()
            prior_fix = task.last_debug_fingerprint
            if prior_fix == fingerprint:
                logger.warning("Debugger produced the same fix for task '%s'; refusing to reapply it.", task.title)
                continue

            candidate_label = f"candidate/{task.task_id}"
            file_manager.checkpoint(candidate_label)
            actual_written_paths: list[Path] = []
            try:
                for f in response.files:
                    actual_path = file_manager.write_file(
                        f.path, f.content, task_id=task.task_id, commit=False,
                    )
                    actual_written_paths.append(actual_path)
                file_manager.commit_pending(f"Candidate debug fix for task {task.task_id}")
            except Exception as exc:
                # This used to re-raise, which crashed the ENTIRE CLI
                # process over one bad candidate (e.g. the Debugger
                # proposing a file path like "" or "../../x" that
                # FileManager._safe_relative_path() rejects). One task's
                # bad candidate should cost that task a debug round, not
                # take down every other task's already-completed work
                # along with it.
                logger.warning(
                    "Candidate debug fix for task '%s' could not be applied (%s); rolling back and rejecting this round.",
                    task.title, exc,
                )
                file_manager.rollback_to(candidate_label)
                file_manager.release_task_locks(task.task_id)
                task.status = TaskStatus.REJECTED
                self.memory.remember(
                    state.project_id, key=f"debug_candidate_failure.{task.task_id}",
                    value=f"Candidate fix raised {type(exc).__name__}: {exc}", tags=["debug", "failure"],
                )
                continue
            file_manager.release_task_locks(task.task_id)
            # KEY FIX: Use actual_written_paths (returned by write_file())
            # instead of [project_root / f.path for f in response.files].
            # FileManager._safe_relative_path() sanitizes f.path (strips
            # backslashes, spaces, reserved Windows names, etc.) before
            # writing. If candidate_paths is built from the RAW f.path,
            # it points to a different location than where the file was
            # actually written → f.exists() returns False → MissingFile
            # false positive for every task, even valid fixes.
            syntax_result, _ = self.test_runner.run_targeted(project_root, actual_written_paths)
            if not syntax_result.passed:
                logger.warning(
                    "Candidate fix for task '%s' failed targeted gate (%s); rolling back.",
                    task.title, syntax_result.failure_reason,
                )
                file_manager.rollback_to(candidate_label)
                task.status = TaskStatus.REJECTED
                # KEY FIX: store a detailed targeted-gate failure message so
                # the NEXT Debugger call for this task has precise context
                # about what went wrong (SyntaxError / ModuleNotFoundError),
                # rather than just retrying with the same prompt. This is
                # surfaced via the failure_context block in the next round.
                self.memory.remember(
                    state.project_id, key=f"debug_candidate_failure.{task.task_id}",
                    value=(
                        f"[{syntax_result.failure_reason}] Your previous fix attempt was rejected "
                        f"because the files it produced had a {syntax_result.failure_kind.value}. "
                        f"You MUST produce syntactically valid Python with no broken imports.\n"
                        f"Error details:\n{syntax_result.stderr[:2000]}"
                    ),
                    tags=["debug", "failure", "targeted_gate"],
                )
            else:
                task.last_debug_fingerprint = fingerprint
                self.memory.remember(
                    state.project_id,
                    key=f"debug_fix.{task.task_id}",
                    value=fingerprint,
                    tags=["debug", "fingerprint", "applied"],
                )
                for f in response.files:
                    self.kg.record_task_file(task.task_id, state.project_id, f.path, agent_run_id=task.task_id)
                task.status = TaskStatus.NEEDS_REVIEW

        state.debug_loops_used += 1
        state = self.states.sync_task_tree(state, tree)
        return self.states.advance_stage(state, ProjectStage.TESTING)

    async def _stage_output(self, state: ProjectState) -> ProjectState:
        tree = self.states.task_tree_of(state)
        try:
            tree.validate()
        except (DependencyCycleError, ValueError) as exc:
            logger.error("Project %s has an invalid Task Tree at Output: %s", state.project_id, exc)
            return self.states.advance_stage(state, ProjectStage.FAILED)

        unresolved = [
            t for t in tree.tasks.values()
            if t.status not in (TaskStatus.ACCEPTED, TaskStatus.DEFERRED)
        ]
        if unresolved:
            # A retry/debug ceiling explains why the system stopped, but it does not
            # make rejected work correct. Never publish a project as DONE while tasks
            # remain unresolved.
            titles = ", ".join(t.title for t in unresolved)
            self.memory.remember(
                state.project_id,
                key="output.unresolved_tasks",
                value=titles,
                tags=["error", "unresolved"],
            )
            logger.error(
                "Project %s has unresolved/incomplete tasks at Output; refusing DONE: %s",
                state.project_id, [(t.title, t.status.value) for t in unresolved],
            )
            return self.states.advance_stage(state, ProjectStage.FAILED)

        documenter = get_agent(AgentRole.DOCUMENTER, memory=self.memory)
        file_manager = FileManager(self.states.project_root(state.project_id))

        decisions = self.memory.store.all_decisions(state.project_id)
        decisions_text = "\n".join(d.summary_line() for d in decisions if d.superseded_by is None)

        tree = self.states.task_tree_of(state)
        unresolved = [t for t in tree.tasks.values() if t.status == TaskStatus.REJECTED]
        unresolved_note = ""
        if unresolved:
            titles = ", ".join(t.title for t in unresolved)
            unresolved_note = (
                f"\n\nKNOWN ISSUES: the following tasks could not be fixed within the "
                f"debug loop budget and are likely broken or incomplete: {titles}."
            )
            self.memory.remember(
                state.project_id, key="output.unresolved_tasks", value=titles, tags=["warning"],
            )

        readme_response = await documenter.run(
            state.project_id,
            task_description=f"Write a README.md for this project. Files present: "
                              f"{', '.join(file_manager.list_files())}.\n\nDecisions made:\n"
                              f"{decisions_text}{unresolved_note}",
        )
        for f in readme_response.files or [type("_F", (), {"path": "README.md", "content": readme_response.answer})()]:
            try:
                file_manager.write_file(f.path, f.content, task_id="documentation",
                                         commit_message="Add generated documentation")
            except ValueError as exc:
                # Same class of bug as the Programmer/Debugger write loops
                # above: don't let one bad path from the Documenter's
                # response crash the run after every task already
                # succeeded. Fall back to plain README.md so the project
                # still ends with SOME documentation.
                logger.warning("Documenter proposed an invalid file path %r (%s); writing to README.md instead.", f.path, exc)
                file_manager.write_file("README.md", f.content, task_id="documentation",
                                         commit_message="Add generated documentation")

        self.memory.archive_project(state.project_id, final_summary=decisions_text or "No decisions recorded.")
        file_manager.checkpoint(label="final")
        return self.states.advance_stage(state, ProjectStage.DONE)


    def close(self) -> None:
        """Release persistent resources held by long-lived subsystems."""
        resources = (self.kg, getattr(self.ai_manager, "capability", None), getattr(self.memory, "store", None))
        for resource in resources:
            close = getattr(resource, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:  # noqa: BLE001
                    logger.exception("Failed to close %s", type(resource).__name__)

    _STAGE_HANDLERS = {
        ProjectStage.RECEIVED: _stage_received,
        ProjectStage.IDEA_EXPANSION: _stage_idea_expansion,
        ProjectStage.RESEARCH: _stage_research,
        ProjectStage.ARCHITECTURE: _stage_architecture,
        ProjectStage.PLANNING: _stage_planning,
        ProjectStage.CODING: _stage_coding,
        ProjectStage.REVIEW: _stage_review,
        ProjectStage.TESTING: _stage_testing,
        ProjectStage.DEBUG: _stage_debug,
        ProjectStage.OUTPUT: _stage_output,
    }