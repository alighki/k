"""
BaseAgent — a thin wrapper: role + connector + prompt builder in, a
parsed AgentResponse out. This is deliberately dumb: an Agent does not
decide workflow, does not touch files directly, does not make
decisions — it just executes one call to one model with one prompt
and hands back a structured response. All orchestration logic lives
in workflow/ and decision/, per the core philosophy in docs/PHILOSOPHY.md.

Routing now goes through AIManager (ai_manager/manager.py) instead of
reading config.routes directly: AIManager blends real capability
track record with cost/latency/risk to produce a RANKED candidate
chain, and `run()` walks that whole chain on connector failure rather
than trying only one hardcoded fallback.
"""

from __future__ import annotations

import time

from orchestrator.ai_manager.manager import AIManager
from orchestrator.connectors.registry import get_connector
from orchestrator.core.config import get_config
from orchestrator.core.exceptions import (
    ConnectorTimeoutError,
    ConnectorUnavailableError,
)
from orchestrator.core.logging_setup import get_logger
from orchestrator.core.types import AgentRole
from orchestrator.memory.manager import MemoryManager
from orchestrator.prompt.builder import PromptBuilder, PromptReviewer
from orchestrator.prompt.json_pipeline import (
    build_ai_repair_prompt,
    finish_after_ai_repair,
    run_deterministic_pipeline,
)
from orchestrator.prompt.models import PromptVersion
from orchestrator.prompt.output_contract import AgentResponse

logger = get_logger(__name__)


class BaseAgent:
    role: AgentRole

    def __init__(self, memory: MemoryManager | None = None, route_key_override: str | None = None,
                 ai_manager: AIManager | None = None) -> None:
        """`route_key_override` lets a caller reuse this agent's role
        (prompt template, output-contract handling) while routing to a
        DIFFERENT entry in config.routes — used by multi-reviewer
        consensus (workflow/engine.py) to run the same Reviewer
        behaviour against reviewer/reviewer_secondary/reviewer_tertiary
        without needing three separate agent classes."""
        self.memory = memory or MemoryManager()
        self.builder = PromptBuilder(self.memory)
        self.reviewer = PromptReviewer()
        self.config = get_config()
        self.route_key_override = route_key_override
        self.ai_manager = ai_manager or AIManager()
        self._last_quality_hint: float | None = None  # set by workflow after scoring, see note in run()

    def _route_key(self) -> str:
        return self.route_key_override or self.role.value

    def _fallback_chain(self) -> list[tuple[str, str]]:
        """Full ranked candidate chain from AIManager (capability +
        cost blended), falling back to the raw config entry if
        AIManager returns nothing (e.g. role missing from routes)."""
        ranked = self.ai_manager.select_route(self._route_key())
        if ranked:
            return [(r.provider, r.model) for r in ranked]

        route = self.config.routes.get(self._route_key())
        if route is None:
            raise KeyError(f"No route configured for '{self._route_key()}'")
        chain = [(route.provider, route.model)]
        if route.fallback_provider and route.fallback_model:
            chain.append((route.fallback_provider, route.fallback_model))
        return chain

    def build_prompt(self, project_id: str, task_description: str,
                      task_id: str | None = None, extra_context: str = "") -> PromptVersion:
        prompt = self.builder.build(project_id, self.role, task_description, task_id, extra_context)
        return self.reviewer.review(prompt)

    async def _call_model(self, provider: str, model: str, prompt_text: str) -> tuple[str, float]:
        connector = get_connector(provider)
        started = time.monotonic()
        result = await connector.send(
            prompt_text,
            model=model,
            timeout_seconds=self.config.connectors.default_timeout_seconds,
        )
        elapsed = time.monotonic() - started
        return result.raw_text, elapsed

    async def _call_with_fallback_chain(self, prompt_text: str) -> tuple[str, str, str, float]:
        """Walks the AIManager-ranked candidate chain, trying each
        provider/model in order until one succeeds. Returns
        (raw_text, provider_used, model_used, latency_seconds)."""
        chain = self._fallback_chain()
        last_exc: Exception | None = None

        attempts_per_route = max(1, int(self.config.connectors.max_retries) + 1)
        # In a local-only setup a single slow model retry can multiply into
        # tens of minutes when combined with fallbacks. Prefer switching
        # routes over repeatedly waiting on the same model.
        for i, (provider, model) in enumerate(chain):
            for attempt in range(1, attempts_per_route + 1):
                try:
                    raw, latency = await self._call_model(provider, model, prompt_text)
                    return raw, provider, model, latency
                except (ConnectorTimeoutError, ConnectorUnavailableError) as exc:
                    last_exc = exc
                    # A hard connector failure (model not pulled, service
                    # down, timed out) previously left NO trace in
                    # CapabilityEngine — record_outcome() was only ever
                    # called on a successful response at the end of run().
                    # That meant a consistently-broken route (e.g. a model
                    # name that doesn't exist in the local Ollama install)
                    # was retried FIRST on every single future task forever,
                    # instead of being deprioritized in favor of a route
                    # that actually works. Score 0 here so ranking reflects
                    # reality after just a few failures.
                    self.ai_manager.record_outcome(
                        self._route_key(), provider, model, quality_score=0.0, latency_seconds=0.0,
                    )
                    if attempt < attempts_per_route:
                        logger.warning(
                            "%s: %s/%s failed on attempt %d/%d (%s); retrying once",
                            self._route_key(), provider, model, attempt, attempts_per_route, exc,
                        )
                    elif i < len(chain) - 1:
                        next_provider, next_model = chain[i + 1]
                        logger.warning(
                            "%s: %s/%s failed (%s); trying next route: %s/%s",
                            self._route_key(), provider, model, exc, next_provider, next_model,
                        )

        assert last_exc is not None
        raise last_exc

    @staticmethod
    def _fallback_response(raw: str, reason: str) -> AgentResponse:
        """Used when the model's output could not be parsed into the
        Output Contract even after a repair attempt. Confidence is
        pinned at 0 so ConfidenceGate (decision/confidence.py) always
        BLOCKs on this, forcing the workflow to treat it as a failed
        step rather than silently trusting garbage."""
        return AgentResponse(
            answer=raw[:4000],
            confidence=0,
            reasons=[],
            unknown_parts=[f"Response could not be parsed: {reason}"],
            raw_text=raw,
        )

    async def run(self, project_id: str, task_description: str,
                   task_id: str | None = None, extra_context: str = "") -> AgentResponse:
        prompt = self.build_prompt(project_id, task_description, task_id, extra_context)

        raw, provider_used, model_used, latency = await self._call_with_fallback_chain(prompt.full_text)

        # ---- JSON parsing pipeline ------------------------------------
        # Extract -> Parse -> Automatic Repair -> Parse -> Schema
        # Validation, all deterministic (no model call). Only if THIS
        # fails do we escalate to an AI-assisted repair call — and even
        # then, the model is asked ONLY to fix JSON syntax, not to
        # regenerate the answer from scratch (see json_pipeline.py
        # AI_REPAIR_INSTRUCTIONS). Final fallback is a controlled,
        # confidence=0 response — never a raw traceback bubbling up.
        result = run_deterministic_pipeline(raw)

        if not result.succeeded and result.needs_ai_repair:
            logger.warning(
                "%s: deterministic parsing pipeline failed (%s); attempting AI-assisted "
                "JSON repair as last resort.", self._route_key(), result.summary(),
            )
            # The summary() alone only tells us *which pipeline stages*
            # failed, not *what the model actually said* -- which is
            # what's needed to tell "model ignored the schema entirely"
            # apart from "model was 95% correct but had a trailing
            # comma". This goes to the rotating file log at DEBUG (not
            # the console, which stays at INFO) so it doesn't spam
            # interactive runs but is there to grep when a route keeps
            # failing.
            logger.debug(
                "%s: raw response that failed deterministic parsing (task=%s, model=%s):\n%s",
                self._route_key(), task_id, model_used, raw,
            )
            try:
                repair_prompt = build_ai_repair_prompt(result.final_raw_text)
                ai_repaired_text, _ = await self._call_model(provider_used, model_used, repair_prompt)
                result = finish_after_ai_repair(raw, ai_repaired_text, result.attempts)
            except (ConnectorTimeoutError, ConnectorUnavailableError) as exc:
                logger.error("%s: AI-assisted repair call itself failed: %s", self._route_key(), exc)

        if result.succeeded:
            assert result.response is not None
            response = result.response
        else:
            # Controlled failure: every pipeline stage was tried and
            # exhausted (summary() shows exactly which stages ran and
            # failed, logged here for diagnosis) — hand back a
            # confidence=0 placeholder instead of raising, so a single
            # unparseable response never crashes the whole workflow.
            logger.error(
                "%s: response still unparseable after full pipeline (%s).",
                self._route_key(), result.summary(),
            )
            logger.debug(
                "%s: raw response still unparseable after AI repair (task=%s, model=%s):\n%s\n"
                "--- AI repair attempt output (if any) ---\n%s",
                self._route_key(), task_id, model_used, raw, result.final_raw_text,
            )
            response = self._fallback_response(raw, result.summary())

        # Self-reported confidence is useful telemetry but is NOT actual
        # quality evidence. Keep it in its own CapabilityEngine stream so
        # routing cannot mistake a model saying "95% confident" for a
        # verified 95/100 implementation. Real quality is recorded later
        # by WorkflowEngine after QualityScorer runs.
        self.ai_manager.capability.record_confidence(
            self._route_key(), provider_used, model_used,
            confidence_score=float(response.confidence),
        )
        response.provider_used = provider_used
        response.model_used = model_used

        memory_key_role = self._route_key()
        self.memory.remember(
            project_id,
            key=f"agent_run.{memory_key_role}.{task_id or 'adhoc'}",
            value=response.answer[:2000],
            tags=[memory_key_role],
        )
        return response
