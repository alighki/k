"""
CLI — the entire user-facing surface, per the design doc's "user just
types an idea and hits go" principle.

Usage:
    orchestrator start "a restaurant expense tracker app"
    orchestrator resume <project_id>
    orchestrator status <project_id>
    orchestrator list
    orchestrator identity
    orchestrator decisions <project_id>
"""

from __future__ import annotations

import asyncio
import re

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from orchestrator.core.logging_setup import setup_logging
from orchestrator.identity.store import IdentityStore
from orchestrator.memory.manager import MemoryManager
from orchestrator.workflow.engine import WorkflowEngine
from orchestrator.workflow.state import ProjectStateManager

app = typer.Typer(help="AI Orchestrator — a personal multi-AI development coordinator.")
console = Console()

# These 3 answers MUST come from the user, not be guessed by a model —
# that's the whole point of asking them here instead of leaving it to
# the Idea Expander to infer from free text. Every `start` run collects
# them (interactively, or via --quality/--size/--design for scripted
# use) and they're prepended to the idea as an explicit, unambiguous
# requirements block every downstream agent reads.
_QUALITY_CHOICES = {"1": "بالا (High)", "2": "متوسط (Medium)", "3": "کم (Low)"}
_SIZE_CHOICES = {"1": "کم (Small)", "2": "متوسط (Medium)", "3": "زیاد (Large)"}
_DESIGN_CHOICES = {"1": "بله، قوی (Yes, strong)", "2": "بله، متوسط (Yes, medium)", "3": "خیر (No)"}


def _ask_choice(question: str, choices: dict[str, str], preset: str | None) -> str:
    if preset:
        # Allow either the number ("2") or a free-text match to short-circuit
        # the prompt for scripted/non-interactive use.
        if preset in choices:
            return choices[preset]
        for label in choices.values():
            if preset.strip().lower() in label.lower():
                return label
        console.print(f"[yellow]Value '{preset}' didn't match any option for '{question}'; asking interactively instead.[/]")
    console.print(f"\n[bold]{question}[/]")
    for key, label in choices.items():
        console.print(f"  {key}) {label}")
    pick = Prompt.ask("انتخاب شما", choices=list(choices.keys()), default="2")
    return choices[pick]


@app.command()
def start(idea: str = typer.Argument(None, help="Your project idea, one sentence is enough. Omit this if using --file."),
          file: str = typer.Option(None, "--file", "-f", help="Read the (possibly long/multi-line) idea from a text file instead of typing it on the command line."),
          name: str = typer.Option(None, help="Optional short project name."),
          quality: str = typer.Option(None, "--quality", help="Skip the quality-level prompt: 1=High, 2=Medium, 3=Low."),
          size: str = typer.Option(None, "--size", help="Skip the project-size prompt: 1=Small, 2=Medium, 3=Large."),
          design: str = typer.Option(None, "--design", help="Skip the graphic-design prompt: 1=Yes strong, 2=Yes medium, 3=No."),
          ) -> None:
    """Start a brand-new project from an idea."""
    setup_logging()

    if file:
        from pathlib import Path
        file_path = Path(file)
        if not file_path.exists():
            console.print(f"[red]File not found:[/] {file}")
            raise typer.Exit(code=1)
        idea = file_path.read_text(encoding="utf-8").strip()
        if not idea:
            console.print(f"[red]File is empty:[/] {file}")
            raise typer.Exit(code=1)
    elif not idea or not idea.strip():
        console.print("[red]Provide an idea as an argument, or use --file/-f to read it from a text file.[/]")
        raise typer.Exit(code=1)

    quality_answer = _ask_choice("سطح کیفیت مورد نظر چقدر است؟", _QUALITY_CHOICES, quality)
    size_answer = _ask_choice("حجم پروژه و تعداد فایل‌ها در چه بازه‌ای باشد؟", _SIZE_CHOICES, size)
    design_answer = _ask_choice("آیا صفحات نیاز به طراحی گرافیکی دارند؟", _DESIGN_CHOICES, design)

    idea = (
        f"{idea}\n\n"
        f"--- User-specified requirements (mandatory, do not ignore or reinterpret) ---\n"
        f"Desired quality level: {quality_answer}\n"
        f"Desired project size / file count: {size_answer}\n"
        f"Graphic design requirement for pages/UI: {design_answer}\n"
    )

    identity = IdentityStore().bootstrap()
    console.print(f"\n[bold cyan]{identity.name}[/]: starting a new project...")

    engine = WorkflowEngine()
    project_name = name or (re.sub(r"[^a-zA-Z0-9_-]+", "-", idea.strip())[:40].strip("-_") or "project")

    async def _run():
        state = await engine.start_project(project_name, idea)
        IdentityStore().add_project(state.project_id)
        return state

    from orchestrator.core.exceptions import ConnectorError

    try:
        state = asyncio.run(_run())
    except ConnectorError as exc:
        # Known, expected failure mode (Ollama unreachable/timed out) —
        # show a clean one-line message instead of a full traceback,
        # since this is almost always a setup issue, not a code bug.
        console.print(f"[red]Connector error:[/] {exc}")
        console.print("[yellow]Check that `ollama serve` is running and the "
                       "model names in config/orchestrator.yaml match models "
                       "you've actually pulled (`ollama list`).[/]")
        raise typer.Exit(code=1)

    console.print(f"[green]Project '{state.project_id}' reached stage: {state.stage.value}[/]")


@app.command()
def resume(project_id: str) -> None:
    """Resume a project from its last saved checkpoint/stage."""
    setup_logging()
    engine = WorkflowEngine()

    from orchestrator.core.exceptions import ConnectorError

    try:
        state = asyncio.run(engine.resume_project(project_id))
    except ConnectorError as exc:
        console.print(f"[red]Connector error:[/] {exc}")
        console.print("[yellow]Check that `ollama serve` is running and the "
                       "model names in config/orchestrator.yaml match models "
                       "you've actually pulled (`ollama list`).[/]")
        raise typer.Exit(code=1)

    console.print(f"[green]Project '{state.project_id}' now at stage: {state.stage.value}[/]")


@app.command()
def status(project_id: str) -> None:
    """Show a project's current stage and task summary."""
    setup_logging()
    states = ProjectStateManager()
    state = states.load(project_id)

    table = Table(title=f"Project {project_id} — {state.name}")
    table.add_column("Field")
    table.add_column("Value")
    table.add_row("Stage", state.stage.value)
    table.add_row("Tasks total", str(len(state.tasks)))
    table.add_row("Review rounds used", str(state.review_rounds_used))
    table.add_row("Debug loops used", str(state.debug_loops_used))
    # Show every possible TaskStatus, not just the common ones — a task
    # stuck in e.g. RUNNING after a crashed process should be visible
    # here instead of silently missing from the breakdown.
    from orchestrator.core.types import TaskStatus
    for status_value in TaskStatus:
        count = sum(1 for t in state.tasks if t.status == status_value)
        if count > 0:
            table.add_row(f"  {status_value.value}", str(count))
    console.print(table)


@app.command(name="list")
def list_projects() -> None:
    """List all known projects."""
    setup_logging()
    states = ProjectStateManager()
    for pid in states.list_projects():
        console.print(pid)


@app.command()
def identity() -> None:
    """Show the orchestrator's own identity."""
    setup_logging()
    ident = IdentityStore().bootstrap()
    console.print(f"Name: {ident.name}")
    console.print(f"Instance ID: {ident.instance_id}")
    console.print(f"Projects completed: {len(ident.project_history)}")
    for suggestion in IdentityStore().suggest_identity_updates():
        console.print(f"[yellow]Suggestion:[/] {suggestion}")


@app.command()
def decisions(project_id: str) -> None:
    """Show every decision made for a project, with reasons."""
    setup_logging()
    memory = MemoryManager()
    for d in memory.store.all_decisions(project_id):
        status_marker = "[dim](superseded)[/]" if d.superseded_by else ""
        console.print(f"- {d.summary_line()} {status_marker}")


if __name__ == "__main__":
    app()