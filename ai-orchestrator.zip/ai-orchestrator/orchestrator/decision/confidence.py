"""
Confidence Engine — the design doc's own words: "each AI must not just
answer; it must state confidence + reasons + unknown parts. If
confidence is below 80%, the system must not proceed."

This is intentionally a small, standalone module (not folded into
QualityScorer) because it runs at a DIFFERENT point in the pipeline:
QualityScorer judges a finished artifact after the fact; ConfidenceGate
judges a single agent response BEFORE the workflow decides what to do
with it — i.e. "should we even trust this enough to act on it, or
should we get a second opinion first?"
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from orchestrator.core.logging_setup import get_logger
from orchestrator.decision.policy import PolicyEngine
from orchestrator.prompt.output_contract import AgentResponse

logger = get_logger(__name__)


class ConfidenceVerdict(str, Enum):
    PROCEED = "proceed"                    # confidence is high enough, act on it directly
    SEEK_SECOND_OPINION = "seek_second_opinion"  # too low to act on alone, but not catastrophic
    BLOCK = "block"                         # confidence so low the workflow must not proceed


@dataclass
class ConfidenceAssessment:
    verdict: ConfidenceVerdict
    confidence: int
    reason: str
    unknown_parts: list[str]


class ConfidenceGate:
    """Every agent response passes through here before the workflow
    acts on it. See workflow/engine.py usages for how each stage
    reacts to SEEK_SECOND_OPINION vs BLOCK."""

    def __init__(self, policy: PolicyEngine | None = None, hard_floor: int = 40) -> None:
        self.policy = policy or PolicyEngine()
        # Below this floor, no amount of a second opinion should paper
        # over how unreliable the answer likely is — treat as a hard block.
        self.hard_floor = hard_floor

    def assess(self, response: AgentResponse) -> ConfidenceAssessment:
        min_required = int(self.policy.settings.min_confidence_to_proceed * 100)

        if response.confidence < self.hard_floor:
            return ConfidenceAssessment(
                verdict=ConfidenceVerdict.BLOCK,
                confidence=response.confidence,
                reason=f"Confidence {response.confidence} is below the hard floor "
                       f"({self.hard_floor}); this response cannot be used as-is.",
                unknown_parts=response.unknown_parts,
            )

        if response.confidence < min_required:
            return ConfidenceAssessment(
                verdict=ConfidenceVerdict.SEEK_SECOND_OPINION,
                confidence=response.confidence,
                reason=f"Confidence {response.confidence} is below the required "
                       f"{min_required}; a second opinion (Judge/alternate agent) is needed.",
                unknown_parts=response.unknown_parts,
            )

        return ConfidenceAssessment(
            verdict=ConfidenceVerdict.PROCEED,
            confidence=response.confidence,
            reason="Confidence meets the required threshold.",
            unknown_parts=response.unknown_parts,
        )
