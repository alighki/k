"""
JSON Parsing Pipeline

Pipeline:

    raw model output
          |
          v
    extract JSON object
          |
          v
    json.loads()
          |
          v
    deterministic repair
          |
          v
    json.loads()
          |
          v
    Pydantic validation
          |
          v
    optional AI repair
          |
          v
    parse + validation
          |
          v
    controlled failure
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from pydantic import ValidationError

from orchestrator.prompt.output_contract import (
    AgentResponse,
    agent_response_json_schema,
)


@dataclass
class ParseAttempt:
    stage: str
    succeeded: bool
    error: str = ""


@dataclass
class PipelineResult:
    response: AgentResponse | None
    attempts: list[ParseAttempt]
    needs_ai_repair: bool
    final_raw_text: str = ""

    @property
    def succeeded(self) -> bool:
        return self.response is not None

    def summary(self) -> str:
        return " -> ".join(
            f"{a.stage}:{'OK' if a.succeeded else 'FAIL'}"
            for a in self.attempts
        )


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------

def _find_balanced_json_object(text: str) -> str | None:
    """
    Find the first complete top-level JSON object.

    Unlike find('{') / rfind('}'), this understands JSON strings and escaped
    quotes, so braces inside files[].content do not confuse extraction.
    """

    start = -1
    depth = 0
    in_string = False
    escape_next = False

    for index, char in enumerate(text):
        if start == -1:
            if char == "{":
                start = index
                depth = 1
            continue

        if escape_next:
            escape_next = False
            continue

        if in_string:
            if char == "\\":
                escape_next = True
            elif char == '"':
                in_string = False
            continue

        if char == '"':
            in_string = True
            continue

        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1

            if depth == 0:
                return text[start:index + 1]

    return None


def extract_json_candidate(raw_text: str) -> str:
    """
    Remove common Markdown fences/prose and isolate the first balanced JSON
    object.
    """

    text = raw_text.strip()

    if not text:
        return ""

    lines = text.splitlines()

    if lines and lines[0].strip().startswith("```"):
        lines = lines[1:]

    if lines and lines[-1].strip().startswith("```"):
        lines = lines[:-1]

    text = "\n".join(lines).strip()

    candidate = _find_balanced_json_object(text)

    if candidate is not None:
        return candidate.strip()

    # No balanced object. Return from first { onward so the repair pipeline
    # can attempt to recover a truncated response.
    first = text.find("{")

    if first >= 0:
        return text[first:].strip()

    return text


# ---------------------------------------------------------------------------
# Parse
# ---------------------------------------------------------------------------

def try_parse_json(text: str) -> tuple[dict | None, str]:
    try:
        value = json.loads(text)

        if not isinstance(value, dict):
            return None, "top-level JSON value must be an object"

        return value, ""

    except json.JSONDecodeError as exc:
        return None, (
            f"{exc.msg} at line {exc.lineno}, "
            f"column {exc.colno}, character {exc.pos}"
        )


# ---------------------------------------------------------------------------
# Deterministic repair
# ---------------------------------------------------------------------------

def _normalize_smart_quotes(text: str) -> str:
    """
    Normalize typographic quotes outside JSON strings only.
    """

    replacements = {
        "\u201c": '"',
        "\u201d": '"',
        "\u2018": "'",
        "\u2019": "'",
    }

    result: list[str] = []

    for char in text:
        result.append(replacements.get(char, char))

    return "".join(result)


def _repair_string_literals(text: str) -> str:
    """
    A single accurate pass over the whole document that fixes three
    related, and easily-conflated, ways a local model's JSON string
    values commonly come out broken. All three have to be handled
    together in one pass, tracking the SAME state, because handling
    them with separate naive in_string toggles causes each fix to
    desync the others (see history below).

    1. Raw control characters (real newline/tab/CR bytes) sitting
       inside a string instead of the two-char \\n/\\t/\\r escape --
       the most common failure, whenever a model forgets to escape
       multi-line source code it's embedding as a files[].content
       value.

    2. Stray, unescaped double-quotes inside a string value that
       aren't actually the closing quote -- e.g. embedded Python code
       like `f'Total: {summary["income"]:.2f}'`. A naive in_string
       toggle treats the first of those quotes as closing the JSON
       string, shearing the rest of the file's source code off into
       raw text ("Expecting ',' delimiter" a few dozen characters
       later). A pure lookahead ("is the next real char one of
       , : } ]?") isn't reliable on its own either:
       `summary["income"]` has TWO stray quotes, and the second is
       immediately followed by `]`, which looks exactly like a
       legitimate end of a string array (`"item"]`). Telling those
       apart requires knowing the REAL container we're in (object vs
       array) at this point, ignoring anything that only looks like
       brackets because it's sitting inside a string -- hence the
       bracket/brace stack below, plus whether the current string is
       a key or a value (keys are followed by `:`, values by
       `,`/`}`/`]` matching the enclosing container).

    3. Invalid JSON escape sequences -- most commonly Python-style
       `\\'` (escaped single quote), which is valid in a Python string
       literal but NOT a legal JSON escape (JSON only allows
       \\" \\\\ \\/ \\b \\f \\n \\r \\t and \\uXXXX); json.loads
       rejects the entire document with "Invalid \\escape" the
       instant it hits one. Single quotes don't need escaping in JSON
       at all, so the fix is to drop the backslash and keep the quote
       literally.

    These three USED to be three separate functions run back-to-back.
    That's exactly why control-char escaping (a plain "does \\ mean
    skip the next char" toggle) silently broke on a real production
    response: the model wrote a stray Python line-continuation
    backslash directly followed by a real newline (`sql = ''' ... ( \\
    <newline>    id integer ...`), and the naive escaper saw the `\\`,
    assumed "next char is already escaped, don't touch it", and passed
    the raw newline straight through -- which is invalid JSON and
    fails with "Invalid control character" a few fields later. Fixing
    each mistake needs the others' context to do it correctly, so all
    three now share one pass and one accurate state machine instead of
    silently invalidating each other's assumptions.
    """

    valid_escape_chars = set('"\\/bfnrt')

    result: list[str] = []

    stack: list[str] = []   # "obj" for {, "arr" for [
    expect_key = True       # only meaningful while stack[-1] == "obj"
    in_string = False
    current_kind: str | None = None   # "key" | "value" while in_string
    n = len(text)
    i = 0

    while i < n:
        char = text[i]

        if in_string and char == "\\" and i + 1 < n:
            nxt = text[i + 1]
            if nxt == "u" and i + 6 <= n and all(c in "0123456789abcdefABCDEF" for c in text[i + 2:i + 6]):
                result.append(text[i:i + 6])
                i += 6
                continue
            if nxt in valid_escape_chars:
                result.append(char)
                result.append(nxt)
                i += 2
                continue
            # Invalid JSON escape (e.g. Python-style \\', or a stray
            # line-continuation backslash) -- drop the backslash; the
            # following character isn't actually escaped, so treat it
            # like ordinary string content, including converting it if
            # it's itself a raw control character.
            if nxt == "\n":
                result.append("\\n")
            elif nxt == "\r":
                result.append("\\r")
            elif nxt == "\t":
                result.append("\\t")
            else:
                result.append(nxt)
            i += 2
            continue

        if in_string and char in ("\n", "\r", "\t"):
            result.append({"\n": "\\n", "\r": "\\r", "\t": "\\t"}[char])
            i += 1
            continue

        if char == '"':
            if not in_string:
                in_string = True
                current_kind = "key" if (stack and stack[-1] == "obj" and expect_key) else "value"
                result.append(char)
                i += 1
                continue

            j = i + 1
            while j < n and text[j] in " \t\r\n":
                j += 1
            next_char = text[j] if j < n else ""

            if current_kind == "key":
                valid = next_char == ":"
            else:
                if next_char == ",":
                    valid = True
                elif next_char == "}":
                    valid = bool(stack) and stack[-1] == "obj"
                elif next_char == "]":
                    valid = bool(stack) and stack[-1] == "arr"
                elif next_char == "":
                    valid = True  # end of (possibly truncated) text
                else:
                    valid = False

            if valid:
                in_string = False
                current_kind = None
                result.append(char)
            else:
                # Stray quote inside the string value -- escape it and
                # stay in_string.
                result.append('\\"')
            i += 1
            continue

        if not in_string:
            if char == "{":
                stack.append("obj")
                expect_key = True
            elif char == "[":
                stack.append("arr")
            elif char in ("}", "]"):
                if stack:
                    stack.pop()
                # Closing a nested value (array/object) means the
                # enclosing object, if any, is ready for its next key --
                # whether or not a comma actually separates them (this
                # repair pipeline exists precisely because that comma
                # is sometimes missing).
                if stack and stack[-1] == "obj":
                    expect_key = True
            elif char == ":":
                expect_key = False
            elif char == ",":
                if stack and stack[-1] == "obj":
                    expect_key = True

        result.append(char)
        i += 1

    return "".join(result)


def _remove_trailing_commas(text: str) -> str:
    """
    Remove commas directly before ] or }.

    This is safe because the pattern is structural and does not attempt
    to rewrite arbitrary strings.
    """

    result: list[str] = []

    in_string = False
    escape_next = False

    index = 0

    while index < len(text):
        char = text[index]

        if escape_next:
            result.append(char)
            escape_next = False
            index += 1
            continue

        if in_string:
            result.append(char)

            if char == "\\":
                escape_next = True
            elif char == '"':
                in_string = False

            index += 1
            continue

        if char == '"':
            in_string = True
            result.append(char)
            index += 1
            continue

        if char == ",":
            lookahead = index + 1

            while (
                lookahead < len(text)
                and text[lookahead].isspace()
            ):
                lookahead += 1

            if (
                lookahead < len(text)
                and text[lookahead] in "}]"
            ):
                index += 1
                continue

        result.append(char)
        index += 1

    return "".join(result)


def _insert_missing_commas(text: str) -> str:
    """
    Insert commas only at structural level.

    Supported common patterns:

        "value"
        "next": ...

        }
        "next": ...

        ]
        "next": ...

    It intentionally does NOT modify text inside JSON strings.
    """

    result: list[str] = []

    in_string = False
    escape_next = False

    index = 0

    while index < len(text):
        char = text[index]

        if escape_next:
            result.append(char)
            escape_next = False
            index += 1
            continue

        if in_string:
            result.append(char)

            if char == "\\":
                escape_next = True
            elif char == '"':
                in_string = False

            index += 1
            continue

        if char == '"':
            in_string = True
            result.append(char)
            index += 1
            continue

        result.append(char)

        if char in '"}]0123456789':
            next_index = index + 1

            while (
                next_index < len(text)
                and text[next_index].isspace()
            ):
                next_index += 1

            # If next token starts a JSON key, a comma may be missing.
            if (
                next_index < len(text)
                and text[next_index] == '"'
            ):
                quote_end = next_index + 1
                escaped = False

                while quote_end < len(text):
                    current = text[quote_end]

                    if escaped:
                        escaped = False
                    elif current == "\\":
                        escaped = True
                    elif current == '"':
                        break

                    quote_end += 1

                if quote_end < len(text):
                    after_key = quote_end + 1

                    while (
                        after_key < len(text)
                        and text[after_key].isspace()
                    ):
                        after_key += 1

                    if (
                        after_key < len(text)
                        and text[after_key] == ":"
                    ):
                        if result and result[-1] != ",":
                            result.append(",")

        index += 1

    return "".join(result)


def _close_truncated_json(text: str) -> str:
    """
    Best-effort closure of an incomplete JSON document.

    This is deliberately conservative: it only closes structural containers
    that are clearly open. It does not invent missing fields.
    """

    stripped = text.rstrip()

    if not stripped:
        return stripped

    in_string = False
    escape_next = False
    stack: list[str] = []

    for char in stripped:
        if escape_next:
            escape_next = False
            continue

        if in_string:
            if char == "\\":
                escape_next = True
            elif char == '"':
                in_string = False
            continue

        if char == '"':
            in_string = True
            continue

        if char in "{[":
            stack.append(char)

        elif char in "}]":
            if stack:
                expected = "{" if char == "}" else "["
                if stack[-1] == expected:
                    stack.pop()

    result = stripped

    if in_string:
        result += '"'

    for opener in reversed(stack):
        result += "}" if opener == "{" else "]"

    return result


def _normalize_python_triple_quoted_strings(text: str) -> str:
    """
    Convert Python-style triple-quoted string values (a run of three
    double-quote characters used as a delimiter, as opposed to a
    normal JSON string) into a single valid JSON string with
    newlines/quotes properly escaped. This pattern shows up from local
    models that slip into Python syntax when asked to embed multi-line
    source code as a JSON string value.

    Only touches spans of three double-quotes that appear where a
    JSON string value is expected (immediately after `:`, possibly
    with whitespace) so we don't rewrite anything inside content that
    is already a normal, correctly escaped JSON string.

    This has to run BEFORE _repair_string_literals, which tracks "are
    we inside a string" by toggling on every unescaped double-quote
    character -- three consecutive quote characters flips that flag
    three times and desyncs it for the rest of the document, which is
    exactly why documents with this pattern were unparseable even
    after the rest of the repair pipeline ran.
    """

    result: list[str] = []
    i = 0
    n = len(text)

    while i < n:
        if text[i] == '"' and text[i:i + 3] == '"""':
            # Confirm this is a value position: walk back over
            # whitespace to see if the previous non-space char is ':'.
            j = len(result) - 1
            while j >= 0 and result[j] in (" ", "\t", "\n", "\r"):
                j -= 1
            is_value_position = j >= 0 and result[j] == ":"

            if is_value_position:
                close = text.find('"""', i + 3)
                if close != -1:
                    inner = text[i + 3:close]
                    escaped = (
                        inner.replace("\\", "\\\\")
                        .replace('"', '\\"')
                        .replace("\r\n", "\\n")
                        .replace("\n", "\\n")
                        .replace("\r", "\\n")
                        .replace("\t", "\\t")
                    )
                    result.append('"')
                    result.append(escaped)
                    result.append('"')
                    i = close + 3
                    continue

        result.append(text[i])
        i += 1

    return "".join(result)


def automatic_repair(text: str) -> str:
    """
    Deterministic repair pipeline.

    Order matters.
    """

    repaired = _normalize_smart_quotes(text)

    repaired = _normalize_python_triple_quoted_strings(repaired)

    repaired = _repair_string_literals(
        repaired
    )

    repaired = _remove_trailing_commas(
        repaired
    )

    repaired = _insert_missing_commas(
        repaired
    )

    repaired = _close_truncated_json(
        repaired
    )

    return repaired


# ---------------------------------------------------------------------------
# Schema validation
# ---------------------------------------------------------------------------

def validate_schema(
    data: dict,
) -> tuple[AgentResponse | None, str]:

    try:
        return AgentResponse.model_validate(data), ""

    except ValidationError as exc:
        return None, str(exc)


# ---------------------------------------------------------------------------
# Deterministic pipeline
# ---------------------------------------------------------------------------

def run_deterministic_pipeline(
    raw_text: str,
) -> PipelineResult:

    attempts: list[ParseAttempt] = []

    extracted = extract_json_candidate(raw_text)

    attempts.append(
        ParseAttempt(
            stage="extract",
            succeeded=bool(extracted),
            error="" if extracted else "no JSON object found",
        )
    )

    if not extracted:
        return PipelineResult(
            response=None,
            attempts=attempts,
            needs_ai_repair=True,
            final_raw_text=raw_text,
        )

    data, err = try_parse_json(extracted)

    attempts.append(
        ParseAttempt(
            stage="parse_raw",
            succeeded=data is not None,
            error=err,
        )
    )

    working_text = extracted

    if data is None:
        repaired = automatic_repair(extracted)

        data, err = try_parse_json(repaired)

        attempts.append(
            ParseAttempt(
                stage="automatic_repair+parse",
                succeeded=data is not None,
                error=err,
            )
        )

        working_text = repaired

    if data is None:
        return PipelineResult(
            response=None,
            attempts=attempts,
            needs_ai_repair=True,
            final_raw_text=working_text,
        )

    response, err = validate_schema(data)

    attempts.append(
        ParseAttempt(
            stage="schema_validation",
            succeeded=response is not None,
            error=err,
        )
    )

    if response is None:
        return PipelineResult(
            response=None,
            attempts=attempts,
            needs_ai_repair=True,
            final_raw_text=working_text,
        )

    response.raw_text = raw_text

    return PipelineResult(
        response=response,
        attempts=attempts,
        needs_ai_repair=False,
        final_raw_text=working_text,
    )


# ---------------------------------------------------------------------------
# AI repair
# ---------------------------------------------------------------------------

AI_REPAIR_INSTRUCTIONS = """
You are a JSON repair engine.

The following text is supposed to be exactly one JSON object matching
the AI Orchestrator AgentResponse contract.

Your ONLY task is to repair JSON syntax.

DO NOT:
- explain anything
- add commentary
- regenerate the answer
- summarize
- remove information
- invent information
- change string values unless required to make JSON syntactically valid
- add markdown
- add code fences

Return ONLY one valid JSON object.

Required top-level keys:

{
  "answer": "string",
  "confidence": 0,
  "reasons": [],
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": []
}

Required file shape:

{
  "path": "string",
  "content": "string"
}

Required decision shape:

{
  "topic": "string",
  "value": "string",
  "reasons": []
}

Required task shape:

{
  "title": "string",
  "depends_on_titles": [],
  "effort": "S",
  "risk": "low",
  "deferred": false
}

Broken JSON:
__BROKEN_JSON__
"""


def build_ai_repair_prompt(
    broken_text: str,
) -> str:
    # NOTE: this was previously AI_REPAIR_INSTRUCTIONS.format(broken_json=...).
    # The template above is full of literal JSON example blocks like
    # {"answer": "string", ...} — str.format() treats every one of those
    # braces as a placeholder too, not just {broken_json}, so it raised
    # KeyError on the first literal key it hit (e.g. KeyError: '\n  "answer"').
    # That exception was uncaught here, so any call site invoking AI-assisted
    # repair (BaseAgent.run(), architecture stage, etc.) crashed outright
    # instead of falling back gracefully — this is the exact failure behind
    # the "Architecture stage failed: '\n  \"answer\"'" log line. A plain
    # string replace has no brace-escaping problem since it doesn't parse
    # the rest of the template at all.
    return AI_REPAIR_INSTRUCTIONS.replace("__BROKEN_JSON__", broken_text)


def finish_after_ai_repair(
    original_raw_text: str,
    ai_repaired_text: str,
    prior_attempts: list[ParseAttempt],
) -> PipelineResult:

    attempts = list(prior_attempts)

    extracted = extract_json_candidate(
        ai_repaired_text
    )

    data, err = try_parse_json(extracted)

    attempts.append(
        ParseAttempt(
            stage="ai_repair_parse",
            succeeded=data is not None,
            error=err,
        )
    )

    working_text = extracted

    if data is None:
        repaired = automatic_repair(extracted)

        data, err = try_parse_json(repaired)

        attempts.append(
            ParseAttempt(
                stage="ai_repair_automatic_repair+parse",
                succeeded=data is not None,
                error=err,
            )
        )

        working_text = repaired

    if data is None:
        return PipelineResult(
            response=None,
            attempts=attempts,
            needs_ai_repair=False,
            final_raw_text=working_text,
        )

    response, err = validate_schema(data)

    attempts.append(
        ParseAttempt(
            stage="ai_repair_schema_validation",
            succeeded=response is not None,
            error=err,
        )
    )

    if response is None:
        return PipelineResult(
            response=None,
            attempts=attempts,
            needs_ai_repair=False,
            final_raw_text=working_text,
        )

    response.raw_text = original_raw_text

    return PipelineResult(
        response=response,
        attempts=attempts,
        needs_ai_repair=False,
        final_raw_text=working_text,
    )