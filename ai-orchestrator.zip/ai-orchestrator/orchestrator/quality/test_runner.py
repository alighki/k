"""
test_runner.py — Quality gate: syntax/import check + pytest runner.

FIX (راه‌حل ۱): Before running any import/syntax check, this module now
installs the workspace's own packages so that `from book_manager.app import …`
or any other local package import resolves correctly.

FIX (راه‌حل ۲): conftest.py is auto-created in workspace root so pytest
adds project root to sys.path — flat imports like `from models import X` work.

Public API (matches what engine.py and __init__.py expect):
  - TestRunResult  : dataclass with .syntax_ok, .failure_kind, .pytest
  - TestRunner     : class with .run() and .run_for_task(task_files)
  - run_full_test  : convenience function → TestRunResult
  - run_targeted_test : convenience function → TestRunResult
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result dataclass  (engine.py uses: .syntax_ok, .failure_kind, .pytest)
# ---------------------------------------------------------------------------

@dataclass
class TestRunResult:
    """
    Result of a test-runner quality gate.

    Attributes
    ----------
    syntax_ok    : bool       — did all files pass the syntax/import check?
    failure_kind : str        — "", "SyntaxError", "ModuleNotFoundError", "TestFailure"
    pytest       : bool|None  — True=passed, False=failed, None=not run / no tests
    details      : str        — human-readable output for logging / debug prompts
    """
    syntax_ok: bool = True
    failure_kind: str = ""
    pytest: bool | None = None
    details: str = ""

    # Convenience aliases used by some callers
    @property
    def syntax_error(self) -> bool:
        return not self.syntax_ok

    @property
    def passed(self) -> bool:
        """True only when syntax is clean AND (no tests OR tests passed)."""
        return self.syntax_ok and self.pytest is not False

    def __str__(self) -> str:
        return (
            f"TestRunResult(syntax_ok={self.syntax_ok}, "
            f"failure_kind={self.failure_kind!r}, "
            f"pytest={self.pytest})"
        )


# ---------------------------------------------------------------------------
# Main class — engine.py does: runner = TestRunner(workspace); result = runner.run()
# ---------------------------------------------------------------------------

class TestRunner:
    """
    Quality gate that installs deps, ensures conftest.py, checks imports,
    and runs pytest — all in the given workspace directory.

    Usage patterns both supported:
      # engine.py pattern — workspace provided later at call time
      runner = TestRunner()
      result = runner.run(workspace)

      # legacy pattern — workspace provided at construction time
      runner = TestRunner(workspace)
      result = runner.run()
    """

    def __init__(self, workspace: str | Path | None = None) -> None:
        self.workspace = Path(workspace) if workspace is not None else None

    def _resolve(self, workspace: str | Path | None) -> Path:
        """Return a resolved Path, preferring the call-time arg over self.workspace."""
        ws = workspace if workspace is not None else self.workspace
        if ws is None:
            raise ValueError(
                "TestRunner: workspace must be supplied either at construction "
                "or as an argument to run() / run_for_task()."
            )
        return Path(ws)

    # ── public methods ────────────────────────────────────────────────────

    def run(self, workspace: str | Path | None = None) -> TestRunResult:
        """Full gate: install deps → conftest → syntax/import → pytest."""
        return run_full_test(self._resolve(workspace))

    def run_for_task(
        self,
        task_files: list[str | Path],
        workspace: str | Path | None = None,
    ) -> TestRunResult:
        """Targeted gate for a single task's changed files only."""
        paths = [Path(f) for f in task_files]
        return run_targeted_test(self._resolve(workspace), paths)

    # kept for any legacy callers
    def run_targeted(
        self,
        task_files: list[str | Path],
        workspace: str | Path | None = None,
    ) -> TestRunResult:
        return self.run_for_task(task_files, workspace)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _pip_install_workspace(workspace: Path) -> None:
    """
    FIX راه‌حل ۱ — Install workspace packages before the import check so that
    `from book_manager.app import app` and similar local-package imports resolve.

    Priority:
      1. pyproject.toml or setup.py present → `pip install -e .`
      2. requirements.txt present           → `pip install -r <filtered>`
      3. Nothing to install                 → skip silently
    """
    pip = [sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check"]

    has_editable = (
        (workspace / "pyproject.toml").exists()
        or (workspace / "setup.py").exists()
    )
    has_req = (workspace / "requirements.txt").exists()

    if has_editable:
        logger.debug("pip install -e . in %s", workspace)
        result = subprocess.run(
            pip + ["-e", "."],
            cwd=workspace,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            logger.warning("pip install -e . failed (non-fatal): %s", result.stderr[:400])

    elif has_req:
        req_path = workspace / "requirements.txt"
        safe_lines = _filter_pip_requirements(req_path)
        if safe_lines:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".txt", delete=False, dir=workspace
            ) as tmp:
                tmp.write("\n".join(safe_lines))
                tmp_name = tmp.name
            try:
                logger.debug("pip install -r (filtered) in %s", workspace)
                result = subprocess.run(
                    pip + ["-r", tmp_name],
                    cwd=workspace,
                    capture_output=True,
                    text=True,
                )
                if result.returncode != 0:
                    logger.warning(
                        "pip install -r failed (non-fatal): %s", result.stderr[:400]
                    )
            finally:
                os.unlink(tmp_name)


def _filter_pip_requirements(req_path: Path) -> list[str]:
    """
    FIX — strip stdlib module names and npm packages from requirements.txt
    so `pip install` does not fail on them.
    """
    _STDLIB = {
        "os", "sys", "json", "re", "math", "time", "datetime", "pathlib",
        "typing", "collections", "itertools", "functools", "io", "copy",
        "hashlib", "uuid", "logging", "threading", "multiprocessing",
        "subprocess", "shutil", "tempfile", "glob", "fnmatch", "struct",
        "socket", "http", "urllib", "email", "html", "xml", "csv",
        "sqlite3", "pickle", "shelve", "gzip", "zipfile", "tarfile",
        "base64", "binascii", "hmac", "secrets", "random", "statistics",
        "decimal", "fractions", "enum", "dataclasses", "abc", "contextlib",
        "warnings", "traceback", "inspect", "ast", "dis", "gc",
        "platform", "signal", "errno", "ctypes",
    }
    _NON_PIP = {
        "tailwindcss", "nodejs", "node", "npm", "yarn", "webpack",
        "babel", "eslint", "prettier", "jest", "mocha",
    }

    safe: list[str] = []
    try:
        for raw_line in req_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                safe.append(raw_line)
                continue
            pkg_name = (
                line.split("[")[0].split("=")[0].split(">")[0]
                    .split("<")[0].split("!")[0].strip().lower()
            )
            if pkg_name in _STDLIB or pkg_name in _NON_PIP:
                logger.warning(
                    "Skipping invalid requirements.txt entry '%s' (not a pip package)", line
                )
                continue
            safe.append(raw_line)
    except Exception as exc:
        logger.warning("Could not read requirements.txt: %s", exc)
    return safe


def _ensure_conftest(workspace: Path) -> None:
    """
    FIX راه‌حل ۲ — Auto-create conftest.py at workspace root so pytest adds
    the project root to sys.path. Only written if the file does not exist.
    """
    conftest = workspace / "conftest.py"
    if conftest.exists():
        return
    conftest_code = (
        '"""conftest.py — auto-generated by orchestrator test_runner.\n'
        'Adds the project root to sys.path so both flat-module imports\n'
        '(from models import …) and package imports resolve during pytest.\n'
        '"""\n'
        "import sys, os\n"
        "sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\n"
    )
    try:
        conftest.write_text(conftest_code, encoding="utf-8")
        logger.debug("Created conftest.py in %s", workspace)
    except Exception as exc:
        logger.warning("Could not write conftest.py: %s", exc)


def _collect_python_files(
    workspace: Path, task_files: list[Path] | None = None
) -> list[Path]:
    if task_files:
        return [f for f in task_files if f.suffix == ".py" and f.exists()]
    return [
        p for p in workspace.rglob("*.py")
        if ".git" not in p.parts and "__pycache__" not in p.parts
    ]


def _syntax_and_import_check(
    py_files: list[Path], workspace: Path
) -> tuple[bool, str, str]:
    """Returns (ok, failure_kind, details)."""
    env = os.environ.copy()
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(workspace) + (os.pathsep + existing_pp if existing_pp else "")

    for py_file in py_files:
        # 1. Compile check — catches SyntaxError
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", str(py_file)],
            capture_output=True, text=True, env=env,
        )
        if result.returncode != 0:
            err = (result.stderr or result.stdout)[:600]
            logger.debug("SyntaxError in %s: %s", py_file, err)
            return False, "SyntaxError", f"{py_file.name}: {err}"

        # 2. Import check — catches ModuleNotFoundError
        rel = py_file.relative_to(workspace)
        module_str = str(rel).replace(os.sep, ".").removesuffix(".py")
        result2 = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0, '.'); import {module_str}"],
            capture_output=True, text=True, cwd=workspace, env=env,
        )
        if result2.returncode != 0:
            err2 = (result2.stderr or result2.stdout)[:600]
            if "ModuleNotFoundError" in err2 or "ImportError" in err2:
                logger.debug("Import error in %s: %s", py_file, err2)
                return False, "ModuleNotFoundError", f"{py_file.name}: {err2}"
            return False, "ImportError", f"{py_file.name}: {err2}"

    return True, "", ""


def _run_pytest(workspace: Path) -> tuple[bool | None, str]:
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "--tb=short", "-q", str(workspace)],
        capture_output=True, text=True, cwd=workspace,
    )
    output = (result.stdout + result.stderr)[:2000]
    if "no tests ran" in output or "collected 0 items" in output:
        return None, "no tests"
    return result.returncode == 0, output


# ---------------------------------------------------------------------------
# Convenience functions (used by older call-sites that bypass TestRunner)
# ---------------------------------------------------------------------------

def run_full_test(workspace: str | Path) -> TestRunResult:
    """
    Full quality gate for a workspace directory.
      1. pip-install workspace deps
      2. ensure conftest.py
      3. syntax/import check on all .py files
      4. pytest run
    """
    workspace = Path(workspace)
    _pip_install_workspace(workspace)
    _ensure_conftest(workspace)

    py_files = _collect_python_files(workspace)
    if not py_files:
        logger.debug("No Python files found in %s", workspace)
        return TestRunResult(syntax_ok=True, pytest=None, details="no python files")

    syntax_ok, failure_kind, details = _syntax_and_import_check(py_files, workspace)
    if not syntax_ok:
        logger.warning(
            "Skipping pytest run: syntax/import check failed (%s).", failure_kind
        )
        return TestRunResult(
            syntax_ok=False, failure_kind=failure_kind,
            pytest=None, details=details,
        )

    pytest_passed, pytest_details = _run_pytest(workspace)
    if pytest_passed is None:
        return TestRunResult(syntax_ok=True, pytest=None, details="no tests")
    if not pytest_passed:
        return TestRunResult(
            syntax_ok=True, failure_kind="TestFailure",
            pytest=False, details=pytest_details,
        )
    return TestRunResult(syntax_ok=True, pytest=True, details=pytest_details)


def run_targeted_test(
    workspace: str | Path, task_files: list[Path]
) -> TestRunResult:
    """Targeted gate — only checks the files changed by one task."""
    workspace = Path(workspace)
    _pip_install_workspace(workspace)
    _ensure_conftest(workspace)

    py_files = _collect_python_files(workspace, task_files)
    if not py_files:
        return TestRunResult(syntax_ok=True, pytest=None, details="no python files for task")

    syntax_ok, failure_kind, details = _syntax_and_import_check(py_files, workspace)
    if not syntax_ok:
        logger.warning(
            "Targeted candidate gate: syntax/import failed (%s) for task's Python files.",
            failure_kind,
        )
        return TestRunResult(
            syntax_ok=False, failure_kind=failure_kind,
            pytest=None, details=details,
        )

    pytest_passed, pytest_details = _run_pytest(workspace)
    if pytest_passed is None:
        return TestRunResult(syntax_ok=True, pytest=None, details="no tests")
    if not pytest_passed:
        return TestRunResult(
            syntax_ok=True, failure_kind="TestFailure",
            pytest=False, details=pytest_details,
        )
    return TestRunResult(syntax_ok=True, pytest=True, details=pytest_details)
