"""
Test Runner — executes the generated project's code. Runs two checks per project:

  1. Import/syntax check: does every generated .py file at least
     compile and import without raising?
  2. pytest: if the project (or the Programmer agent) produced test
     files (test_*.py / *_test.py), run them for real.

KEY FIX (v0.3): Validation is now TARGET-AWARE.
  - Python files (.py) → syntax + import graph + dynamic import check
  - Markdown files (.md) → structure check only (NOT Python-gated)
  - requirements.txt → dependency declaration check (NOT Python-gated)
  - HTML/CSS/JS → file-exists check only (NOT Python-gated)

  During DEBUG, the Candidate Gate uses TARGETED validation scoped to the
  task's changed files — so a README fix is not rejected because of a
  pre-existing import error in database.py.
"""

from __future__ import annotations

import ast
import re
import subprocess
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from orchestrator.core.logging_setup import get_logger

logger = get_logger(__name__)


class ValidationFailureKind(str, Enum):
    SYNTAX_ERROR = "SyntaxError"
    MODULE_NOT_FOUND = "ModuleNotFoundError"
    MISSING_DEPENDENCY = "MissingDependency"
    MISSING_FILE = "MissingFile"
    TEST_FAILURE = "TestFailure"
    UNKNOWN = "Unknown"


@dataclass
class TestRunResult:
    passed: bool
    summary: str
    stdout: str = ""
    stderr: str = ""
    files_checked: list[str] = field(default_factory=list)
    failure_kind: ValidationFailureKind = ValidationFailureKind.UNKNOWN

    @property
    def failure_reason(self) -> str:
        """Human-readable termination reason for debug loop."""
        if self.passed:
            return "PASS"
        return self.failure_kind.value


def _classify_failure(stderr: str) -> ValidationFailureKind:
    """Parse subprocess stderr to return a precise failure kind."""
    if not stderr:
        return ValidationFailureKind.UNKNOWN
    if "SyntaxError" in stderr or "IndentationError" in stderr:
        return ValidationFailureKind.SYNTAX_ERROR
    if "ModuleNotFoundError" in stderr or "ImportError" in stderr:
        return ValidationFailureKind.MODULE_NOT_FOUND
    if "No module named" in stderr:
        return ValidationFailureKind.MODULE_NOT_FOUND
    return ValidationFailureKind.UNKNOWN


def _file_type(path: Path) -> str:
    """Return a broad type category for validation routing."""
    suffix = path.suffix.lower()
    name = path.name.lower()
    if name == "requirements.txt":
        return "requirements"
    if suffix == ".md":
        return "markdown"
    if suffix == ".py":
        return "python"
    if suffix in (".html", ".htm", ".css", ".js", ".ts", ".jsx", ".tsx"):
        return "web"
    if suffix in (".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".env"):
        return "config"
    return "other"


class TestRunner:
    def __init__(self, timeout_seconds: int = 1200) -> None:
        self.timeout_seconds = timeout_seconds

    @staticmethod
    def _declared_import_roots(project_root: Path) -> set[str]:
        """Return normalized import roots declared by project requirements."""
        requirements = project_root / "requirements.txt"
        if not requirements.is_file():
            return set()
        roots: set[str] = set()
        for raw in requirements.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith(("#", "-r", "--")):
                continue
            match = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)", line)
            if match:
                roots.add(match.group(1).lower().replace("-", "_").replace(".", "_"))
        return roots

    @staticmethod
    def _project_module_roots(project_root: Path) -> set[str]:
        roots: set[str] = {
            p.stem for p in project_root.glob("*.py") if p.name != "__init__.py"
        }
        roots.update(
            p.name for p in project_root.iterdir()
            if p.is_dir() and (p / "__init__.py").is_file()
        )
        return roots

    def _local_import_graph_check(self, project_root: Path, py_files: list[Path]) -> list[str]:
        """Reject unresolved project imports before dynamic imports can mask them."""
        project_roots = self._project_module_roots(project_root)
        declared_external = self._declared_import_roots(project_root)
        stdlib = set(getattr(sys, "stdlib_module_names", ()))
        failures: list[str] = []

        for file_path in py_files:
            relative = file_path.relative_to(project_root)
            try:
                tree = ast.parse(file_path.read_text(encoding="utf-8"), filename=str(relative))
            except (OSError, UnicodeDecodeError, SyntaxError):
                continue

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports = [(alias.name.split(".", 1)[0], 0, alias.name) for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ""
                    imports = [(module.split(".", 1)[0] if module else "", node.level, module)]
                else:
                    continue

                for top, level, full_module in imports:
                    if not top:
                        if level and not self._resolve_relative_import(project_root, file_path, "", level):
                            failures.append(
                                f"{relative} [local import]: unresolved relative import {'.' * level}."
                            )
                        continue

                    if level:
                        if not self._resolve_relative_import(project_root, file_path, full_module, level):
                            failures.append(
                                f"{relative} [local import]: cannot resolve relative import "
                                f"{'.' * level}{full_module} inside project."
                            )
                        continue

                    if top in project_roots:
                        continue
                    normalized = top.lower().replace("-", "_").replace(".", "_")
                    if top in stdlib or normalized in {s.lower() for s in stdlib}:
                        continue
                    if normalized in declared_external:
                        continue

                    failures.append(
                        f"{relative} [import]: '{top}' is neither a project module, a standard-library "
                        f"module, nor a declared dependency in requirements.txt."
                    )
        return failures

    @staticmethod
    def _resolve_relative_import(project_root: Path, importer: Path, module: str, level: int) -> Path | None:
        base = importer.parent
        for _ in range(max(level - 1, 0)):
            base = base.parent
        candidate = base.joinpath(*module.split(".")) if module else base
        file_candidate = candidate.with_suffix(".py")
        if file_candidate.is_file():
            return file_candidate
        init_candidate = candidate / "__init__.py"
        if init_candidate.is_file():
            return init_candidate
        return None

    def _validate_markdown(self, path: Path) -> Optional[str]:
        """Validate a Markdown file. Returns error string or None if OK.

        Deliberately lenient: any non-empty content passes. A completely
        empty file (zero bytes or only whitespace) is the only rejection —
        it means the model produced no output at all for this file.
        """
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            if not content.strip():
                return f"{path.name}: file was written with no content (model produced empty output)"
            return None
        except OSError as exc:
            return f"{path.name}: cannot read ({exc})"

    def _validate_requirements(self, path: Path) -> Optional[str]:
        """Validate requirements.txt format (not Python-gated).

        Deliberately lenient: we only reject lines that are clearly not
        package specifiers (e.g. raw Python code, empty JSON blobs). A line
        that looks like a package name — even with an unusual version spec —
        passes. This avoids false rejections for valid but unusual syntax like:
          flask-restful>=0.3.9
          requests[security]>=2.28
          Pillow>=9.0.0  # image processing
          git+https://github.com/org/pkg.git
        """
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            if not content.strip():
                # Empty requirements.txt is valid (project may add deps later)
                return None
            bad_lines = []
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                # Skip blank lines, comments, flags (-r, --index-url, etc.)
                if not stripped or stripped.startswith(("#", "-", ".")):
                    continue
                # Strip inline comment before format check
                line_no_comment = stripped.split("#")[0].strip()
                if not line_no_comment:
                    continue
                # Accept git+https:// and similar VCS URLs
                if line_no_comment.startswith(("git+", "hg+", "svn+", "bzr+", "http://", "https://")):
                    continue
                # Accept anything that starts with a valid package name char
                # (letter or digit). Reject lines starting with { [ ( etc.
                # which are clearly not package specifiers.
                if not re.match(r"^[A-Za-z0-9_]", line_no_comment):
                    bad_lines.append(f"  line {i}: {stripped!r}")
            if bad_lines:
                return "requirements.txt has malformed lines:\n" + "\n".join(bad_lines)
            return None
        except OSError as exc:
            return f"requirements.txt: cannot read ({exc})"

    def _syntax_and_import_check(
        self,
        project_root: Path,
        target_py_files: Optional[list[Path]] = None,
    ) -> TestRunResult:
        """
        Full project validation.

        If `target_py_files` is given (Candidate Gate in debug mode), only
        those files are dynamic-import-checked; the import graph check still
        covers all py_files so we don't miss cross-file breakage introduced
        by the candidate fix.

        Non-Python files (Markdown, requirements.txt, HTML/CSS/JS) are
        validated by file-type-specific checks — never by the Python
        import/syntax gate.
        """
        # Collect all Python files (excluding .git / .orchestrator)
        py_files = [
            p for p in project_root.rglob("*.py")
            if ".git" not in p.parts and ".orchestrator" not in p.parts
        ]
        if not py_files:
            return TestRunResult(
                passed=True,
                summary="No Python files to check.",
                files_checked=[],
                failure_kind=ValidationFailureKind.UNKNOWN,
            )

        failures = []
        checked = [str(f.relative_to(project_root)) for f in py_files]

        # --- Phase 1: syntax compilation (py_compile) ---
        # KEY FIX: in targeted mode (Candidate Gate), only compile the
        # CHANGED files. Pre-existing syntax errors in other project files
        # are the full project gate's concern — checking them here would
        # reject a valid candidate fix for task B just because task A's
        # broken file (already present before the candidate) has a syntax
        # error. In full mode (Testing stage), compile ALL files.
        files_to_syntax_check = target_py_files if target_py_files is not None else py_files
        for f in files_to_syntax_check:
            result = subprocess.run(
                [sys.executable, "-m", "py_compile", str(f)],
                capture_output=True, text=True, timeout=self.timeout_seconds,
            )
            if result.returncode != 0:
                failures.append(f"{f.relative_to(project_root)} [SyntaxError]: {result.stderr.strip()}")

        if failures:
            combined = "\n".join(failures)
            return TestRunResult(
                passed=False,
                summary=f"{len(failures)}/{len(files_to_syntax_check)} file(s) failed syntax compilation.",
                stderr=combined,
                files_checked=checked,
                failure_kind=ValidationFailureKind.SYNTAX_ERROR,
            )

        # --- Phase 2: local import graph check (static AST) ---
        local_import_failures = self._local_import_graph_check(project_root, py_files)
        if local_import_failures:
            combined = "\n".join(local_import_failures)
            return TestRunResult(
                passed=False,
                summary=f"{len(local_import_failures)} import reference(s) are invalid or undeclared.",
                stderr=combined,
                files_checked=checked,
                failure_kind=ValidationFailureKind.MODULE_NOT_FOUND,
            )

        # --- Phase 3: dynamic import (subprocess per file) ---
        # Only meaningful for project-internal modules — files that only import
        # declared external dependencies (flask, sqlalchemy, etc.) will fail
        # dynamic import if those packages aren't installed in the orchestrator's
        # own venv, even though the GENERATED code is perfectly correct.
        #
        # Strategy: skip a file in Phase 3 if ALL of its top-level imports are
        # either stdlib or declared in requirements.txt. Only dynamic-check files
        # that import project-local modules, because those are the only imports
        # Phase 2 (static AST) cannot fully verify at runtime.
        #
        # Cache these once here so _file_has_local_imports doesn't re-read
        # disk on every single file call (previously: N files × 2 reads each).
        declared_external = self._declared_import_roots(project_root)
        project_roots = self._project_module_roots(project_root)
        stdlib = set(getattr(sys, "stdlib_module_names", ()))

        def _file_has_local_imports(f: Path) -> bool:
            """Return True only if this file imports a project-local module.
            Uses pre-computed sets (declared_external, project_roots, stdlib)
            to avoid redundant disk reads per file."""
            try:
                tree_ast = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
            except (OSError, SyntaxError):
                return True  # can't tell → include in check (safe default)
            for node in ast.walk(tree_ast):
                if isinstance(node, ast.Import):
                    tops = [alias.name.split(".", 1)[0] for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    if node.level:
                        return True  # relative import → local
                    tops = [node.module.split(".", 1)[0]] if node.module else []
                else:
                    continue
                for top in tops:
                    norm = top.lower().replace("-", "_").replace(".", "_")
                    if top in project_roots:
                        return True
                    if top in stdlib or norm in {s.lower() for s in stdlib}:
                        continue
                    if norm in declared_external:
                        continue
                    return True  # unknown import → include
            return False

        files_to_dynamic_check = target_py_files if target_py_files is not None else py_files
        for f in files_to_dynamic_check:
            relative = f.relative_to(project_root)
            module_name = ".".join(relative.with_suffix("").parts)
            if module_name.startswith("tests.") or relative.name.startswith("test_") or relative.name.endswith("_test.py"):
                continue
            # Skip files that only import external/stdlib — dynamic import of
            # those tests the orchestrator's own installed packages, not the
            # generated project's correctness.
            if not _file_has_local_imports(f):
                logger.debug(
                    "Phase 3: skipping %s (only stdlib/external imports; "
                    "would test orchestrator venv, not generated code).", relative,
                )
                continue
            result = subprocess.run(
                [sys.executable, "-c",
                 "import importlib; importlib.import_module(%r)" % module_name],
                capture_output=True, text=True, timeout=self.timeout_seconds, cwd=str(project_root),
            )
            if result.returncode != 0:
                stderr_text = result.stderr.strip()
                # If the ONLY reason for failure is a missing external dep
                # (ModuleNotFoundError on something in requirements.txt),
                # don't count it — it's an environment issue, not a code bug.
                if "ModuleNotFoundError" in stderr_text or "ImportError" in stderr_text:
                    # Extract the missing module name from the error
                    import re as _re
                    m = _re.search(r"No module named ['\"]([^'\"]+)['\"]", stderr_text)
                    if m:
                        missing = m.group(1).split(".")[0].lower().replace("-", "_")
                        if missing in declared_external:
                            logger.debug(
                                "Phase 3: %s failed import because external dep '%s' is not installed "
                                "in the orchestrator env; skipping (code is correct).", relative, missing,
                            )
                            continue
                failures.append(f"{relative} [import]: {stderr_text}")

        if failures:
            combined = "\n".join(failures)
            kind = _classify_failure(combined)
            return TestRunResult(
                passed=False,
                summary=f"{len(failures)} Python file(s) failed syntax/import validation.",
                stderr=combined,
                files_checked=checked,
                failure_kind=kind,
            )

        return TestRunResult(
            passed=True,
            summary=f"All {len(py_files)} Python file(s) passed syntax and import validation.",
            files_checked=checked,
            failure_kind=ValidationFailureKind.UNKNOWN,
        )

    def _run_pytest(self, project_root: Path) -> TestRunResult | None:
        has_tests = any(project_root.rglob("test_*.py")) or any(project_root.rglob("*_test.py"))
        if not has_tests:
            return None

        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", "-q", "--tb=short", str(project_root)],
                capture_output=True, text=True, timeout=self.timeout_seconds, cwd=str(project_root),
            )
        except subprocess.TimeoutExpired:
            return TestRunResult(
                passed=False,
                summary=f"pytest did not finish within {self.timeout_seconds}s (possible infinite loop).",
                failure_kind=ValidationFailureKind.TEST_FAILURE,
            )
        except FileNotFoundError:
            return TestRunResult(
                passed=False,
                summary="pytest is not installed in this environment; cannot run generated tests.",
                failure_kind=ValidationFailureKind.MISSING_DEPENDENCY,
            )

        kind = ValidationFailureKind.TEST_FAILURE if result.returncode != 0 else ValidationFailureKind.UNKNOWN
        return TestRunResult(
            passed=result.returncode == 0,
            summary="pytest passed." if result.returncode == 0 else "pytest reported failures.",
            stdout=result.stdout[-4000:],
            stderr=result.stderr[-2000:],
            failure_kind=kind,
        )

    def run(self, project_root: Path) -> tuple[TestRunResult, TestRunResult | None]:
        """Full project validation. Returns (syntax_check_result, pytest_result_or_None)."""
        syntax_result = self._syntax_and_import_check(project_root)
        pytest_result = None
        if syntax_result.passed:
            pytest_result = self._run_pytest(project_root)
        else:
            logger.warning(
                "Skipping pytest run: syntax/import check failed (%s).",
                syntax_result.failure_kind.value,
            )
        return syntax_result, pytest_result

    def run_targeted(
        self,
        project_root: Path,
        changed_files: list[Path],
    ) -> tuple[TestRunResult, TestRunResult | None]:
        """
        TARGETED (Candidate Gate) validation for debug mode.

        For non-Python changed files (Markdown, requirements.txt, HTML/CSS/JS),
        the Python import/syntax gate is SKIPPED entirely — only file-specific
        checks are run. This prevents a pre-existing import error in database.py
        from rejecting a valid README or requirements.txt fix.

        For Python changed files, both the full project syntax check AND a
        targeted dynamic import check (only the candidate's .py files) are run.
        """
        python_changes = [f for f in changed_files if _file_type(f) == "python"]
        non_python_changes = [f for f in changed_files if _file_type(f) != "python"]

        # KEY FIX: Only validate files that were actually written to disk.
        # candidate_paths = [project_root / f.path for f in response.files],
        # so some paths may not exist if FileManager rejected them earlier.
        # Trying to validate a non-existent file always produces a false failure.
        python_changes = [f for f in python_changes if f.exists()]
        non_python_changes = [f for f in non_python_changes if f.exists()]

        non_py_errors: list[str] = []
        for f in non_python_changes:
            ftype = _file_type(f)
            if ftype == "markdown":
                err = self._validate_markdown(f)
                if err:
                    non_py_errors.append(err)
            elif ftype == "requirements":
                err = self._validate_requirements(f)
                if err:
                    non_py_errors.append(err)
            # HTML/CSS/JS: existence check already done above (f.exists() filter)
            # config/other: no-op validation

        if non_py_errors and not python_changes:
            # Only non-Python files changed, and they have content errors
            # (e.g. empty Markdown, malformed requirements.txt).
            # Use UNKNOWN kind — not MISSING_FILE, which is misleading
            # (the files exist on disk, they just have bad content).
            combined = "\n".join(non_py_errors)
            return (
                TestRunResult(
                    passed=False,
                    summary=f"{len(non_py_errors)} non-Python file(s) failed content validation.",
                    stderr=combined,
                    failure_kind=ValidationFailureKind.UNKNOWN,
                ),
                None,
            )

        if not python_changes and not non_python_changes:
            # Debugger proposed files but none were actually written to disk.
            # This is handled upstream (no-files case) — treat as pass here
            # so we don't double-reject with a confusing MissingFile error.
            return (
                TestRunResult(
                    passed=True,
                    summary="Targeted validation: no files on disk to validate (write may have been skipped upstream).",
                    failure_kind=ValidationFailureKind.UNKNOWN,
                ),
                None,
            )

        if not python_changes:
            # Only non-Python files changed and they passed
            return (
                TestRunResult(
                    passed=True,
                    summary=f"Targeted validation passed ({len(non_python_changes)} non-Python file(s) OK).",
                    failure_kind=ValidationFailureKind.UNKNOWN,
                ),
                None,
            )

        # Python files changed → full syntax + targeted dynamic import check
        syntax_result = self._syntax_and_import_check(project_root, target_py_files=python_changes)
        pytest_result = None
        if syntax_result.passed:
            pytest_result = self._run_pytest(project_root)
        else:
            logger.warning(
                "Targeted candidate gate: syntax/import failed (%s) for task's Python files.",
                syntax_result.failure_kind.value,
            )
        return syntax_result, pytest_result