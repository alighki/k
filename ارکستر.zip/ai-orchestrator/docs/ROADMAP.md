# Roadmap

## v0.2.1 (اولین اجرای واقعی end-to-end)
برای اولین بار، پروژه واقعاً نصب شد (`pip install -e .`) و
`pytest`/`orchestrator start` روی یک سرور Ollama جعلی (شبیه‌ساز محلی
با پایتون خام، بدون نیاز به مدل واقعی) اجرا شدند. این کشف کرد و رفع
کرد:

- **باگ import دایره‌ای واقعی** بین `workflow.engine` و
  `quality.multi_reviewer` — چیزی که `py_compile` هرگز نمی‌توانست
  تشخیص دهد چون فقط syntax تک‌فایل را چک می‌کند، نه گراف import واقعی.
- **باگ `pyproject.toml`**: فرمت version نامعتبر (`0.2.0-local` خلاف
  PEP 440) و ابهام package discovery در setuptools — هر دو مانع نصب
  واقعی پروژه بودند.
- **باگ معماری جدی (Task Dependency Deadlock)**: `ready_tasks()` فقط
  وابستگی‌های `ACCEPTED` را "آماده" می‌دانست، اما task ها فقط در مرحله‌ی
  Review (که بعد از **کل** مرحله‌ی Coding اجرا می‌شود) به `ACCEPTED`
  می‌رسند. یعنی هر task ای که به task دیگری در همان پروژه وابسته بود،
  برای همیشه در `PENDING` گیر می‌کرد و هرگز کد نمی‌شد — این با یک
  اجرای واقعی end-to-end (نه فقط تئوری) تأیید و رفع شد:
  `ready_tasks()` حالا `NEEDS_REVIEW` را هم کافی می‌داند.
- پیام خطای CLI برای `ConnectorError` تمیز شد (قبلاً traceback کامل
  httpx/httpcore نمایش داده می‌شد).

## v0.2.0 (build کاملاً محلی)
تبدیل کامل به build کاملاً محلی: `web_connector.py` و وابستگی
`playwright` به‌طور کامل حذف شدند؛ `connectors/registry.py` فقط
`ollama_local` را می‌شناسد. تمام ۱۸ نقش (`idea_expander` تا
`content_writer`، شامل `programmer_secondary/tertiary` و
`debugger_secondary` که تازه اضافه شدند) به مدل‌های محلی مشخص وصل
شدند (`gemma3:12b`, `qwen2.5-coder`, `deepseek-r1:8b`,
`deepseek-coder-v2`, `deepcoder`, `deepseek-coder`, `codegemma`).
`CapabilityEngine` priors و `CostOptimizer` از منطق provider-محور
(محلی در مقابل وب) به منطق model-محور (اندازه‌ی مدل از اسم آن استخراج
می‌شود) تغییر کردند. `PromptOptimizer` style hints هم اکنون per-model
هستند، نه per-provider.

## v0.1 (نسخه قبلی، شامل web connectors)
- تمام ماژول‌های اصلی: Workflow Engine, AI Manager (routing), Decision
  Engine (consensus + policy + confidence gate), Memory (short/long/
  archive + decisions), Knowledge Graph (اکنون واقعاً در Review برای
  یافتن فایل‌های هر task استفاده می‌شود)، Prompt System (builder +
  reviewer + output contract با فیلد ساختاریافته tasks_proposed)،
  Quality Scorer، File Manager (git-backed) + File Lock، Identity
  System، CLI.
- Connectors: Ollama (کاملاً کاربردی، فقط نیاز به `ollama serve` دارد).
- Testing stage: **اجرای واقعی** — py_compile روی هر فایل + pytest
  واقعی روی فایل‌های test_*.py، با ارسال جزئیات شکست به Debug.
- Confidence Gate: واقعاً در مرحله Architecture (با second-opinion از
  Judge) و Coding (با block/flag) استفاده می‌شود.
- دور بازبینی باگ (۲۴+ باگ شناسایی و رفع شده): پارسینگ قابل‌اعتماد
  Planner (فیلد ساختاریافته به‌جای متن آزاد)، مدیریت پاسخ غیرقابل‌پارس
  مدل با repair-retry، رفع race در commit/checkpoint، جلوگیری از گیر
  کردن task در وضعیت RUNNING بعد از exception، هماهنگ‌سازی
  RetryManager با تنظیمات policy، Review اکنون واقعاً AST syntax check
  را روی فایل‌های هر task (نه کل پروژه به‌صورت متن) اجرا می‌کند.
- دور دوم بازبینی (باگ ۲۵-۳۵): نوشتن اتمیک برای state/identity/lock
  file (مقاوم در برابر crash وسط نوشتن)، بازیابی خودکار از فایل قفل
  خراب، رفع خطر خرابی داده در ذخیره تصمیم‌ها (JSON به‌جای جداکننده
  رشته‌ای شکننده برای reasons/alternatives که می‌توانند از مدل بیایند)،
  Judge tie-break از پارس متن آزاد به فیلد ساختاریافته منتقل شد،
  `review_rounds_used` که مرده بود اکنون واقعاً ثبت و در CLI نمایش
  داده می‌شود، دستور status همه‌ی وضعیت‌های ممکن task را نشان می‌دهد.
- **Multi-Reviewer Consensus** (`quality/multi_reviewer.py`): طبق سند
  "به‌جای یک Reviewer، سه‌تا داشته باش؛ اگر دو نفر موافق بودند قبول
  شود." سه route مستقل (`reviewer`, `reviewer_secondary`,
  `reviewer_tertiary`) به‌صورت موازی اجرا می‌شوند و رأی‌گیری واقعی روی
  verdict ساختاریافته هرکدام انجام می‌شود. با `use_multi_reviewer:
  false` در config قابل غیرفعال‌سازی برای سرعت بیشتر.
- **Simulation-before-execution** (`workflow/simulation.py`): طبق سند
  "قبل از تغییر حتی یک فایل، کل عملیات را ذهنی شبیه‌سازی کن." قبل از
  هر Programmer call، یک ارزیابی ریسک اجرا می‌شود که می‌تواند task را
  کاملاً مسدود کند (BLOCK) یا با هشدار ادامه دهد (WARN). با
  `use_simulation: false` قابل غیرفعال‌سازی.
- **AI Manager واقعی** (`ai_manager/`): `CapabilityEngine` امتیاز
  واقعی per-(role, provider, model) را از نتایج واقعی Quality Score
  یاد می‌گیرد (نه یک جدول ثابت)؛ `CostOptimizer` هزینه/تأخیر/ریسک را
  وارد تصمیم می‌کند؛ `AIManager.select_route()` یک زنجیره کامل
  رتبه‌بندی‌شده برمی‌گرداند که `BaseAgent` آن را کامل امتحان می‌کند
  (نه فقط primary+یک fallback ثابت مثل قبل).
- **Prompt Optimizer پیشرفته** (`prompt/optimizer.py`): راهنمای
  مخصوص هر مدل (style hint + بودجه‌ی طول)، و یادگیری از تاریخچه‌ی
  امتیازها per (role, provider, طول prompt) که واقعاً در حلقه‌ی
  Coding→Review بازخورد می‌گیرد.

## v0.5
- Sandbox امن‌تر برای TestRunner (subprocess فعلی isolation کامل
  ندارد — برای کد تولیدشده توسط خودت کافی است، نه در برابر کد
  adversarial).
- حل مسئله‌ی شناخته‌شده: اگر یک task به‌خاطر confidence پایین یا
  exception مستقیماً REJECTED شود، task های وابسته به آن برای همیشه
  PENDING می‌مانند تا Debug مشکل والد را حل کند — قابل قبول برای این
  نسخه ولی باید صریح‌تر گزارش شود.

## v1.0
- Idea Expansion Engine کامل‌تر (سوالات ساختاریافته‌تر قبل از generation).
- رابط ساده‌ی وب/TUI (با Textual) به‌جای فقط CLI.

## v2.0+
- Plugin architecture رسمی برای Agentهای شخص ثالث.
- اجرای توزیع‌شده (چند Agent روی چند ماشین).
- یادگیری ترجیحات کاربر به‌مرور (`IdentityStore.learn_preference` از
  قبل آماده است، فقط نیاز به منبع سیگنال واقعی دارد).
