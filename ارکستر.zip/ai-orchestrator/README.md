# AI Orchestrator (نسخه کاملاً محلی)

سیستمی شخصی که چند مدل هوش مصنوعی **محلی** (از طریق Ollama) را برای
برنامه‌ریزی، طراحی، کدنویسی، بازبینی و تحویل پروژه‌های نرم‌افزاری
هماهنگ می‌کند.

**این build هیچ اتصال وب یا کلید API ندارد.** هر فراخوانی مدل مستقیماً
به یک نمونه‌ی Ollama که روی سیستم خودت اجرا می‌شود می‌رود.

**این پروژه خودش هوش مصنوعی نیست.** فقط مدیریت، مسیریابی، ثبت تصمیم و
کنترل کیفیت انجام می‌دهد. برای فلسفه‌ی کامل طراحی، `docs/PHILOSOPHY.md`
را بخوان.

## نصب

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

[Ollama](https://ollama.com) را نصب کن، مدل‌های لازم را بکش (طبق
`config/orchestrator.yaml`)، و سرویس را روشن بگذار:

```bash
ollama pull gemma3:12b
ollama pull qwen2.5-coder
ollama pull deepseek-r1:8b
ollama pull deepseek-coder-v2
ollama pull deepcoder
ollama pull deepseek-coder
ollama pull codegemma

ollama serve
```

اگر سخت‌افزارت برای همه‌ی این مدل‌ها کافی نیست، `config/orchestrator.yaml`
را باز کن و مدل‌های سنگین‌تر را با نسخه‌های سبک‌تری که خودت داری جایگزین
کن — هیچ کد پایتونی نیاز به تغییر ندارد.

## استفاده

```bash
orchestrator start "یک اپلیکیشن مدیریت هزینه رستوران بساز"
orchestrator status <project_id>
orchestrator resume <project_id>
orchestrator decisions <project_id>
orchestrator identity
```

## ساختار پروژه

```
orchestrator/
  core/          types, config, exceptions, logging
  identity/      هویت پایدار Orchestrator
  memory/        حافظه کوتاه/بلندمدت/آرشیو + تصمیم‌ها
  knowledge_graph/  وابستگی بین تصمیم/فایل/تسک
  prompt/        Prompt Builder + Reviewer + Output Contract + Optimizer
  decision/      Consensus + Policy + Decision Engine + Confidence Gate
  quality/       Quality Scorer + Test Runner + Multi-Reviewer Consensus
  files/         File Manager (git-backed) + File Lock
  connectors/    Ollama connector (تنها provider این build)
  ai_manager/    Capability Engine + Cost Optimizer + مسیریابی هوشمند
  agents/        Planner, Architect, Researcher, Programmer, Reviewer, ...
  workflow/      Workflow Engine (مغز پروژه) + Task Tree + Simulation
  cli/           رابط خط فرمان
```

## نکات این build

- تمام ۱۸ نقش (`idea_expander`, `planner`, `programmer`,
  `programmer_secondary`, `reviewer_tertiary` و ...) در
  `config/orchestrator.yaml` به یک مدل محلی مشخص وصل‌اند — جدول کامل
  را همان‌جا ببین.
- **Multi-Reviewer Consensus** به‌صورت پیش‌فرض روشن است و از سه مدل
  محلی متفاوت (`deepseek-r1:8b`, `codegemma`, `gemma3:12b`) رأی
  می‌گیرد تا واقعاً یک مدل با خودش موافقت نکند.
- اگر فقط چند مدل از این لیست را نصب کرده‌ای، یا `use_multi_reviewer:
  false` را در config تنظیم کن، یا route‌های نقش‌های کم‌اهمیت‌تر
  (`content_writer`, `researcher`) را به یکی از مدل‌های نصب‌شده‌ات
  اشاره بده.

نقشه‌ی راه توسعه در `docs/ROADMAP.md`.
