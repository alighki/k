"""
Concrete agents. Each is mostly `role = AgentRole.X` — the real
behaviour difference comes from the prompt template (prompt/templates.py)
and the model it's routed to (core/config.py routes table). A few
agents get small extra helper methods where the design doc calls for
role-specific post-processing (Judge, Evaluator).
"""

from __future__ import annotations

from orchestrator.agents.base import BaseAgent
from orchestrator.core.types import AgentRole
from orchestrator.prompt.output_contract import AgentResponse


class IdeaExpanderAgent(BaseAgent):
    role = AgentRole.IDEA_EXPANDER


class PlannerAgent(BaseAgent):
    role = AgentRole.PLANNER


class ChiefArchitectAgent(BaseAgent):
    role = AgentRole.CHIEF_ARCHITECT


class ResearcherAgent(BaseAgent):
    role = AgentRole.RESEARCHER


class PromptEngineerAgent(BaseAgent):
    role = AgentRole.PROMPT_ENGINEER

    def __init__(self, *args, prompt_optimizer=None, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        from orchestrator.prompt.optimizer import PromptOptimizer
        self.prompt_optimizer = prompt_optimizer or PromptOptimizer()

    async def optimize(self, project_id: str, target_role: AgentRole, raw_task: str,
                        target_model: str | None = None, target_provider: str = "ollama_local") -> str:
        """Builds a MODEL-AWARE optimization instruction (style hints,
        length budget, historical prompt-length performance for this
        exact role/model pair — see prompt/optimizer.py) instead of a
        bare "optimize this" call. `target_model`, if known, sharpens
        the guidance; if omitted, the optimizer falls back to
        model-agnostic advice. `target_provider` is always
        "ollama_local" in this local-only build."""
        if target_model:
            instruction = self.prompt_optimizer.build_optimization_instruction(
                target_role, target_model, raw_task, target_provider=target_provider,
            )
        else:
            instruction = f"Target role/model: {target_role.value}\n\nRaw task to optimize:\n{raw_task}"

        response = await self.run(project_id, task_description=instruction)
        return response.answer


class ProgrammerAgent(BaseAgent):
    role = AgentRole.PROGRAMMER


class ReviewerAgent(BaseAgent):
    role = AgentRole.REVIEWER


class DebuggerAgent(BaseAgent):
    role = AgentRole.DEBUGGER


class JudgeAgent(BaseAgent):
    role = AgentRole.JUDGE

    async def pick_best(self, project_id: str, topic: str, candidates: dict[str, str]) -> str:
        """`candidates` maps a label (e.g. "first_attempt") to its
        proposed answer/value. Returns the winning label's value as
        plain text — callers (DecisionEngine, workflow/engine.py)
        treat this as the tie-break result.

        Reads the choice from the structured `decisions_proposed`
        field (topic="chosen_candidate", value=<label>) rather than
        parsing free text — much more reliable than prefix-matching
        the model's prose, which could easily misfire on phrasing like
        "the second one is better" vs a literal "second_attempt" token."""
        labels = list(candidates.keys())
        listing = "\n\n".join(f"### Candidate labeled '{label}'\n{text}" for label, text in candidates.items())
        response = await self.run(
            project_id,
            task_description=f"Topic: {topic}\n\nCompare these candidates and pick the best "
                              f"one (or synthesize a better answer using the strongest parts of "
                              f"each). Candidate labels are: {labels}. You MUST report your "
                              f"choice via `decisions_proposed` with topic='chosen_candidate' "
                              f"and value=<the exact label you chose>.\n\n{listing}",
        )

        for proposed in response.decisions_proposed:
            if proposed.topic == "chosen_candidate" and proposed.value in candidates:
                return candidates[proposed.value]

        # Fallback: model ignored the structured field. Try to find a
        # label literally mentioned in the answer text; if that also
        # fails, default to the first candidate rather than guessing
        # from prefix heuristics.
        answer_lower = response.answer.lower()
        for label in labels:
            if label.lower() in answer_lower:
                return candidates[label]
        return candidates[labels[0]]


class EvaluatorAgent(BaseAgent):
    role = AgentRole.EVALUATOR

    async def score(self, project_id: str, artifact_description: str, artifact_content: str) -> AgentResponse:
        return await self.run(
            project_id,
            task_description=f"{artifact_description}\n\n---\n{artifact_content}",
        )


class DocumenterAgent(BaseAgent):
    role = AgentRole.DOCUMENTER


class ContentWriterAgent(BaseAgent):
    role = AgentRole.CONTENT_WRITER
