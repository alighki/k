"""
BaseAgent — a thin wrapper: role + connector + prompt builder in, a
parsed AgentResponse out. This is deliberately dumb: an Agent does not
decide workflow, does not touch files directly, does not make
decisions — it just executes one call to one model with one prompt
and hands back a structured response. All orchestration logic lives
in workflow/ and decision/, per the core philosophy in docs/PHILOSOPHY.md.

Routing now goes through AIManager (ai_manager/manager.py) instead of
reading config.routes directly: AIManager blends real capability
track record with cost/latency/risk to produce a RANKED candidate
chain, and `run()` walks that whole chain on connector failure rather
than trying only one hardcoded fallback.
"""

from __future__ import annotations

import time

from orchestrator.ai_manager.manager import AIManager
from orchestrator.connectors.registry import get_connector
from orchestrator.core.config import get_config
from orchestrator.core.exceptions import (
    ConnectorTimeoutError,
    ConnectorUnavailableError,
)
from orchestrator.core.logging_setup import get_logger
from orchestrator.core.types import AgentRole
from orchestrator.memory.manager import MemoryManager
from orchestrator.prompt.builder import PromptBuilder, PromptReviewer
from orchestrator.prompt.json_pipeline import (
    build_ai_repair_prompt,
    finish_after_ai_repair,
    run_deterministic_pipeline,
)
from orchestrator.prompt.models import PromptVersion
from orchestrator.prompt.output_contract import AgentResponse

logger = get_logger(__name__)


class BaseAgent:
    role: AgentRole

    def __init__(self, memory: MemoryManager | None = None, route_key_override: str | None = None,
                 ai_manager: AIManager | None = None) -> None:
        """`route_key_override` lets a caller reuse this agent's role
        (prompt template, output-contract handling) while routing to a
        DIFFERENT entry in config.routes — used by multi-reviewer
        consensus (workflow/engine.py) to run the same Reviewer
        behaviour against reviewer/reviewer_secondary/reviewer_tertiary
        without needing three separate agent classes."""
        self.memory = memory or MemoryManager()
        self.builder = PromptBuilder(self.memory)
        self.reviewer = PromptReviewer()
        self.config = get_config()
        self.route_key_override = route_key_override
        self.ai_manager = ai_manager or AIManager()
        self._last_quality_hint: float | None = None  # set by workflow after scoring, see note in run()

    def _route_key(self) -> str:
        return self.route_key_override or self.role.value

    def _fallback_chain(self) -> list[tuple[str, str]]:
        """Full ranked candidate chain from AIManager (capability +
        cost blended), falling back to the raw config entry if
        AIManager returns nothing (e.g. role missing from routes)."""
        ranked = self.ai_manager.select_route(self._route_key())
        if ranked:
            return [(r.provider, r.model) for r in ranked]

        route = self.config.routes.get(self._route_key())
        if route is None:
            raise KeyError(f"No route configured for '{self._route_key()}'")
        chain = [(route.provider, route.model)]
        if route.fallback_provider and route.fallback_model:
            chain.append((route.fallback_provider, route.fallback_model))
        return chain

    def build_prompt(self, project_id: str, task_description: str,
                      task_id: str | None = None, extra_context: str = "") -> PromptVersion:
        prompt = self.builder.build(project_id, self.role, task_description, task_id, extra_context)
        return self.reviewer.review(prompt)

    async def _call_model(self, provider: str, model: str, prompt_text: str) -> tuple[str, float]:
        connector = get_connector(provider)
        started = time.monotonic()
        result = await connector.send(
            prompt_text,
            model=model,
            timeout_seconds=self.config.connectors.default_timeout_seconds,
        )
        elapsed = time.monotonic() - started
        return result.raw_text, elapsed

    async def _call_with_fallback_chain(self, prompt_text: str) -> tuple[str, str, str, float]:
        """Walks the AIManager-ranked candidate chain, trying each
        provider/model in order until one succeeds. Returns
        (raw_text, provider_used, model_used, latency_seconds)."""
        chain = self._fallback_chain()
        last_exc: Exception | None = None

        attempts_per_route = max(1, int(self.config.connectors.max_retries) + 1)
        # In a local-only setup a single slow model retry can multiply into
        # tens of minutes when combined with fallbacks. Prefer switching
        # routes over repeatedly waiting on the same model.
        for i, (provider, model) in enumerate(chain):
            for attempt in range(1, attempts_per_route + 1):
                try:
                    raw, latency = await self._call_model(provider, model, prompt_text)
                    return raw, provider, model, latency
                except (ConnectorTimeoutError, ConnectorUnavailableError) as exc:
                    last_exc = exc
                    # A hard connector failure (model not pulled, service
                    # down, timed out) previously left NO trace in
                    # CapabilityEngine — record_outcome() was only ever
                    # called on a successful response at the end of run().
                    # That meant a consistently-broken route (e.g. a model
                    # name that doesn't exist in the local Ollama install)
                    # was retried FIRST on every single future task forever,
                    # instead of being deprioritized in favor of a route
                    # that actually works. Score 0 here so ranking reflects
                    # reality after just a few failures.
                    self.ai_manager.record_outcome(
                        self._route_key(), provider, model, quality_score=0.0, latency_seconds=0.0,
                    )
                    if attempt < attempts_per_route:
                        logger.warning(
                            "%s: %s/%s failed on attempt %d/%d (%s); retrying once",
                            self._route_key(), provider, model, attempt, attempts_per_route, exc,
                        )
                    elif i < len(chain) - 1:
                        next_provider, next_model = chain[i + 1]
                        logger.warning(
                            "%s: %s/%s failed (%s); trying next route: %s/%s",
                            self._route_key(), provider, model, exc, next_provider, next_model,
                        )

        assert last_exc is not None
        raise last_exc

    @staticmethod
    def _fallback_response(raw: str, reason: str) -> AgentResponse:
        """Used when the model's output could not be parsed into the
        Output Contract even after all deterministic repair, AI repair,
        and model retry attempts.
        Explicitly marked with parse_status='parse_failed' so
        ConfidenceGate issues ConfidenceVerdict.PARSE_FAILED.
        This decouples structural parser failure from the agent's
        reasoning confidence or quality score."""
        return AgentResponse(
            answer=raw[:4000] if raw else "",
            confidence=0,
            reasons=[],
            unknown_parts=[f"Response could not be parsed: {reason}"],
            raw_text=raw,
            parse_status="parse_failed",
        )

    async def run(self, project_id: str, task_description: str,
                   task_id: str | None = None, extra_context: str = "",
                   max_model_retries: int = 2) -> AgentResponse:
        prompt = self.build_prompt(project_id, task_description, task_id, extra_context)

        last_raw = ""
        last_provider = ""
        last_model = ""
        last_summary = ""

        # Multi-attempt execution:
        # Attempt 1: Initial call -> Extract -> Parse -> Schema Validate
        # Attempt 2: Deterministic Repair -> Parse Again -> Schema Validate Again
        # (Optional: AI Repair)
        # Attempt 3: Model Retry -> Extract -> Parse -> Schema Validate
        # Attempt 4: Deterministic Repair on retried response -> Parse Again -> Schema Validate Again
        # Fail ONLY after all attempts have been exhausted!
        for model_attempt in range(1, max_model_retries + 1):
            if model_attempt == 1:
                call_text = prompt.full_text
            else:
                logger.warning(
                    "%s: Model attempt %d/%d after parser failure; prompting with strict JSON contract.",
                    self._route_key(), model_attempt, max_model_retries,
                )
                call_text = (
                    f"{prompt.full_text}\n\n"
                    f"--- STRICT FORMATTING REQUIREMENT (RETRY ATTEMPT {model_attempt}) ---\n"
                    f"Your previous response could not be parsed into valid JSON. "
                    f"You MUST return ONLY a single valid JSON object adhering strictly to the contract. "
                    f"Do NOT include markdown fences (```json or ```text), do NOT add any introductory or trailing text, "
                    f"and properly escape all quotes and newlines in strings."
                )

            raw, provider_used, model_used, latency = await self._call_with_fallback_chain(call_text)
            last_raw = raw
            last_provider = provider_used
            last_model = model_used

            # ---- JSON parsing pipeline ------------------------------------
            # Strict sequence: Extract -> Parse -> Schema Validate -> Repair -> Parse Again -> Schema Validate Again
            result = run_deterministic_pipeline(raw)
            last_summary = result.summary()

            if result.succeeded:
                assert result.response is not None
                response = result.response
                response.provider_used = provider_used
                response.model_used = model_used
                if response.parse_status != "parse_failed":
                    self.ai_manager.capability.record_confidence(
                        self._route_key(), provider_used, model_used,
                        confidence_score=float(response.confidence),
                    )
                self.memory.remember(
                    project_id,
                    key=f"agent_run.{self._route_key()}.{task_id or 'adhoc'}",
                    value=response.answer[:2000],
                    tags=[self._route_key()],
                )
                return response

            # If deterministic pipeline failed, attempt AI repair before model retry
            if result.needs_ai_repair:
                logger.warning(
                    "%s: deterministic parsing pipeline failed (%s); attempting AI-assisted "
                    "JSON repair.", self._route_key(), result.summary(),
                )
                try:
                    repair_prompt = build_ai_repair_prompt(result.final_raw_text)
                    ai_repaired_text, _ = await self._call_model(provider_used, model_used, repair_prompt)
                    ai_result = finish_after_ai_repair(raw, ai_repaired_text, result.attempts)
                    last_summary = ai_result.summary()
                    if ai_result.succeeded:
                        assert ai_result.response is not None
                        response = ai_result.response
                        response.provider_used = provider_used
                        response.model_used = model_used
                        if response.parse_status != "parse_failed":
                            self.ai_manager.capability.record_confidence(
                                self._route_key(), provider_used, model_used,
                                confidence_score=float(response.confidence),
                            )
                        self.memory.remember(
                            project_id,
                            key=f"agent_run.{self._route_key()}.{task_id or 'adhoc'}",
                            value=response.answer[:2000],
                            tags=[self._route_key()],
                        )
                        return response
                except (ConnectorTimeoutError, ConnectorUnavailableError) as exc:
                    logger.error("%s: AI-assisted repair call failed: %s", self._route_key(), exc)

        # Only after ALL model retries and repair passes are exhausted do we fail:
        logger.error(
            "%s: response still unparseable after all %d attempts and repairs (%s). Emitting parse_failed response.",
            self._route_key(), max_model_retries, last_summary,
        )
        response = self._fallback_response(last_raw, last_summary)
        response.provider_used = last_provider
        response.model_used = last_model
        # Notice: we do NOT record confidence into capability engine when parsing fails,
        # because parser format errors do not reflect the agent's work quality!

        self.memory.remember(
            project_id,
            key=f"agent_run.{self._route_key()}.{task_id or 'adhoc'}",
            value=response.answer[:2000],
            tags=[self._route_key()],
        )
        return response
