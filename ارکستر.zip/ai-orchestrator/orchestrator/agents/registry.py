"""
Agent Registry — maps AgentRole -> Agent class. New agents plug in
here without touching the Workflow Engine (satisfies design doc rule:
"adding a new Agent should not require changing the Core").
"""

from __future__ import annotations

from orchestrator.agents.base import BaseAgent
from orchestrator.agents.specialists import (
    IdeaExpanderAgent, PlannerAgent, ChiefArchitectAgent, ResearcherAgent,
    PromptEngineerAgent, ProgrammerAgent, ReviewerAgent, DebuggerAgent,
    JudgeAgent, EvaluatorAgent, DocumenterAgent, ContentWriterAgent,
)
from orchestrator.core.types import AgentRole

_REGISTRY: dict[AgentRole, type[BaseAgent]] = {
    AgentRole.IDEA_EXPANDER: IdeaExpanderAgent,
    AgentRole.PLANNER: PlannerAgent,
    AgentRole.CHIEF_ARCHITECT: ChiefArchitectAgent,
    AgentRole.RESEARCHER: ResearcherAgent,
    AgentRole.PROMPT_ENGINEER: PromptEngineerAgent,
    AgentRole.PROGRAMMER: ProgrammerAgent,
    AgentRole.REVIEWER: ReviewerAgent,
    AgentRole.DEBUGGER: DebuggerAgent,
    AgentRole.JUDGE: JudgeAgent,
    AgentRole.EVALUATOR: EvaluatorAgent,
    AgentRole.DOCUMENTER: DocumenterAgent,
    AgentRole.CONTENT_WRITER: ContentWriterAgent,
}


def get_agent(role: AgentRole, **kwargs) -> BaseAgent:
    cls = _REGISTRY.get(role)
    if cls is None:
        raise ValueError(f"No agent registered for role '{role}'")
    return cls(**kwargs)


def register_agent(role: AgentRole, agent_cls: type[BaseAgent]) -> None:
    """Extension point: plugging in a new/custom agent at runtime."""
    _REGISTRY[role] = agent_cls
