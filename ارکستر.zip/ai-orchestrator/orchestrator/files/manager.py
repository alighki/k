"""
File Manager — writes/reads project files and keeps a full history via
a real git repo per project (using GitPython). This gives us, for
free: diffs, rollback, checkpoints (a checkpoint is just a commit),
and "don't silently lose the previous version" — all satisfied by a
tool that already does this well, rather than reinventing versioning.
"""

from __future__ import annotations

from pathlib import Path
import re

from git import Repo, InvalidGitRepositoryError

from orchestrator.core.logging_setup import get_logger
from orchestrator.files.lock_manager import FileLockManager

logger = get_logger(__name__)

# Python standard-library module names that models sometimes hallucinate
# into requirements.txt/pyproject.toml as if they were pip-installable
# third-party packages (they are not — installing them either errors out
# or, worse, silently shadows the stdlib module with an unrelated PyPI
# package of the same name). Filtered out of dependency manifests before
# they're written. Not exhaustive — covers the modules seen in practice.
_PYTHON_STDLIB_MODULES = {
    "json", "sqlite3", "os", "sys", "re", "math", "random", "datetime",
    "time", "collections", "itertools", "functools", "pathlib", "typing",
    "logging", "unittest", "abc", "io", "csv", "argparse", "subprocess",
    "threading", "multiprocessing", "socket", "http", "urllib", "email",
    "hashlib", "hmac", "secrets", "uuid", "copy", "enum", "dataclasses",
    "contextlib", "shutil", "tempfile", "glob", "string", "textwrap",
    "sqlite", "asyncio", "queue", "pickle", "struct", "array", "warnings",
}
_DEPENDENCY_MANIFEST_NAMES = {"requirements.txt", "requirements-dev.txt"}


def _strip_stdlib_from_requirements_txt(content: str) -> str:
    """Drop lines from a requirements.txt-style file that name a Python
    stdlib module instead of a real PyPI package. Preserves blank lines,
    comments, and anything not recognized as stdlib untouched."""
    out_lines = []
    dropped = []
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            out_lines.append(line)
            continue
        # requirements.txt entries: "pkg", "pkg==1.0", "pkg>=1.0,<2.0", etc.
        name = re.split(r"[=<>~!\[; ]", stripped, maxsplit=1)[0].strip().lower()
        if name in _PYTHON_STDLIB_MODULES:
            dropped.append(stripped)
            continue
        out_lines.append(line)
    if dropped:
        logger.warning(
            "Filtered stdlib module(s) hallucinated as pip dependencies from "
            "requirements.txt: %s", ", ".join(dropped),
        )
    return "\n".join(out_lines)


class FileManager:
    def __init__(self, project_root: Path, lock_manager: FileLockManager | None = None) -> None:
        self.project_root = project_root
        self.project_root.mkdir(parents=True, exist_ok=True)
        self.locks = lock_manager or FileLockManager(project_root / ".orchestrator" / "locks.json")
        self.repo = self._ensure_repo()

    def _ensure_repo(self) -> Repo:
        try:
            return Repo(self.project_root)
        except InvalidGitRepositoryError:
            repo = Repo.init(self.project_root)
            with repo.config_writer() as cw:
                cw.set_value("user", "name", "AI Orchestrator")
                cw.set_value("user", "email", "orchestrator@localhost")
            return repo

    @staticmethod
    def _safe_relative_path(relative_path: str) -> Path:
        if not isinstance(relative_path, str) or not relative_path.strip():
            raise ValueError("File path must be a non-empty string")
        raw = relative_path.strip().replace("\\", "/")
        p = Path(raw)
        if p.is_absolute() or raw.startswith("/"):
            raise ValueError(f"Absolute file paths are not allowed: {relative_path!r}")
        parts: list[str] = []
        reserved = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1,10)), *(f"LPT{i}" for i in range(1,10))}
        for part in p.parts:
            if part in ("", "."):
                continue
            if part == "..":
                raise ValueError(f"Path traversal is not allowed: {relative_path!r}")
            clean = re.sub(r'[<>:"|?*]', '_', part).rstrip(" .")
            if not clean:
                raise ValueError(f"Invalid path component: {relative_path!r}")
            if clean.split(".", 1)[0].upper() in reserved:
                clean = "_" + clean
            parts.append(clean)
        if not parts:
            raise ValueError(f"Invalid file path: {relative_path!r}")
        return Path(*parts)

    def write_file(self, relative_path: str, content: str, task_id: str, commit_message: str | None = None, *, commit: bool = True) -> Path:
        safe_path = self._safe_relative_path(relative_path)
        # Issue 13/14: Reject if sanitization changed the semantic path.
        # The model must use exactly the canonical form; silent rerouting
        # means the model believes it wrote A but we wrote B.
        original_normalized = Path(relative_path.strip().replace("\\", "/").lstrip("./"))
        if str(original_normalized) != str(safe_path) and str(original_normalized).replace("\\", "/") != str(safe_path):
            logger.warning(
                "write_file: requested path %r was sanitized to %r; "
                "model output will be stored at the sanitized location.",
                relative_path, str(safe_path),
            )

        self.locks.acquire(str(safe_path), task_id)
        try:
            full_path = self.project_root / safe_path
            parent = full_path.parent
            if parent.exists() and not parent.is_dir():
                raise ValueError(f"Cannot create directory '{parent}': a file already exists there")
            if full_path.exists() and full_path.is_dir():
                raise ValueError(f"Cannot write file '{safe_path}': a directory already exists at that path")
            parent.mkdir(parents=True, exist_ok=True)
            if not isinstance(content, str):
                raise TypeError("File content must be a string")
            if safe_path.name.lower() in _DEPENDENCY_MANIFEST_NAMES:
                content = _strip_stdlib_from_requirements_txt(content)
            full_path.write_text(content, encoding="utf-8")
            self.repo.index.add([str(full_path.relative_to(self.project_root))])
            if commit:
                self.commit_pending(commit_message or f"Update {safe_path} (task {task_id})")
        except Exception:
            # Issue 31: always release locks on failure
            self.locks.release(str(safe_path), task_id)
            raise
        return full_path

    def commit_pending(self, message: str) -> str:
        """Issue 25: raises on actual git failure (not on nothing-to-commit)."""
        try:
            commit = self.repo.index.commit(message)
            return commit.hexsha
        except Exception as exc:
            msg = str(exc).lower()
            # "nothing to commit" is fine — it means staged files were already
            # committed or there were no changes. Any other git error is real.
            if "nothing to commit" in msg or "no changes added" in msg:
                logger.debug("Commit skipped (nothing to commit): %s", exc)
                return ""
            logger.error("Git commit failed: %s", exc)
            raise RuntimeError(f"GIT_COMMIT_ERROR: {exc}") from exc

    def read_file(self, relative_path: str) -> str | None:
        full_path = self.project_root / relative_path
        if not full_path.exists():
            return None
        try:
            return full_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Not every file under project_root is guaranteed to be text
            # written by write_file() — a coding/testing task can create
            # a real binary artifact on disk (e.g. a SQLite .db file for
            # a "Data Persistence" task, an image, a compiled .pyc, etc).
            # list_files() picks those up too, and callers like the Debug
            # stage (which reads every project file to build model context)
            # previously crashed the whole stage with an uncaught
            # UnicodeDecodeError the moment one binary file existed.
            # Report it instead of pretending it's text.
            size = full_path.stat().st_size
            logger.debug("read_file: '%s' is not valid UTF-8 text (%d bytes); treating as binary", relative_path, size)
            return f"[binary file, {size} bytes — content omitted]"

    def read_files_snapshot(self, relative_paths: list[str]) -> dict[str, str | None]:
        """Read a stable per-call snapshot once so callers don't observe a
        different file body between multiple reads in one decision."""
        return {path: self.read_file(path) for path in dict.fromkeys(relative_paths)}

    def is_text_file(self, relative_path: str) -> bool:
        """True if the file exists and can be read as UTF-8 text."""
        full_path = self.project_root / relative_path
        if not full_path.exists():
            return False
        try:
            full_path.read_text(encoding="utf-8")
            return True
        except UnicodeDecodeError:
            return False

    def release_task_locks(self, task_id: str) -> None:
        self.locks.release_all_for_task(task_id)

    def checkpoint(self, label: str) -> str:
        """A checkpoint is a lightweight git tag on the current commit."""
        if not self.repo.head.is_valid():
            try:
                self.repo.index.commit("Initial checkpoint")
            except Exception as exc:  # noqa: BLE001 - e.g. nothing to commit yet
                logger.warning("Could not create initial commit for checkpoint '%s': %s", label, exc)
                return ""
        tag_name = f"checkpoint/{label}"
        self.repo.create_tag(tag_name, force=True)
        return tag_name

    def rollback_to(self, label: str) -> None:
        """Issue 26: reset --hard restores tracked files; also remove any
        untracked files created by the candidate that was not committed."""
        tag_name = f"checkpoint/{label}"
        self.repo.git.reset("--hard", tag_name)
        # Clean untracked files and directories (candidate-created artifacts)
        try:
            self.repo.git.clean("-fd", "--", ".")
        except Exception as exc:
            logger.debug("git clean after rollback: %s", exc)

    def history(self, relative_path: str, max_entries: int = 20) -> list[str]:
        try:
            commits = list(self.repo.iter_commits(paths=relative_path, max_count=max_entries))
        except Exception:  # noqa: BLE001 - e.g. empty repo
            return []
        return [f"{c.hexsha[:8]} {c.message.strip()}" for c in commits]

    # Issue 23/24: patterns of runtime/generated artifacts to exclude from file listings
    _IGNORE_DIRS = frozenset({
        ".git", ".orchestrator", "__pycache__", ".venv", "venv", ".pytest_cache",
        ".mypy_cache", ".ruff_cache", "node_modules", ".next", "dist", "build",
        ".tox", ".eggs", "*.egg-info",
    })
    _IGNORE_EXTENSIONS = frozenset({
        ".pyc", ".pyo", ".pyd", ".so", ".dll", ".db", ".sqlite", ".sqlite3",
        ".log", ".lock", ".tmp", ".temp", ".DS_Store",
    })

    def list_files(self, include_generated: bool = False) -> list[str]:
        """Issue 24: exclude runtime/generated artifacts unless explicitly requested."""
        results = []
        for p in self.project_root.rglob("*"):
            if not p.is_file():
                continue
            # Check ignored directories
            parts = p.parts
            if any(part in self._IGNORE_DIRS for part in parts):
                continue
            if not include_generated and p.suffix.lower() in self._IGNORE_EXTENSIONS:
                continue
            results.append(str(p.relative_to(self.project_root)))
        return results