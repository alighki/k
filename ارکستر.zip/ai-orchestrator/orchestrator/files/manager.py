"""
File Manager — writes/reads project files and keeps a full history via
a real git repo per project (using GitPython). This gives us, for
free: diffs, rollback, checkpoints (a checkpoint is just a commit),
and "don't silently lose the previous version" — all satisfied by a
tool that already does this well, rather than reinventing versioning.
"""

from __future__ import annotations

from pathlib import Path
import re

from git import Repo, InvalidGitRepositoryError

from orchestrator.core.logging_setup import get_logger
from orchestrator.files.lock_manager import FileLockManager

logger = get_logger(__name__)

# Python standard-library module names that models sometimes hallucinate
# into requirements.txt/pyproject.toml as if they were pip-installable
# third-party packages (they are not — installing them either errors out
# or, worse, silently shadows the stdlib module with an unrelated PyPI
# package of the same name). Filtered out of dependency manifests before
# they're written. Not exhaustive — covers the modules seen in practice.
_PYTHON_STDLIB_MODULES = {
    "json", "sqlite3", "os", "sys", "re", "math", "random", "datetime",
    "time", "collections", "itertools", "functools", "pathlib", "typing",
    "logging", "unittest", "abc", "io", "csv", "argparse", "subprocess",
    "threading", "multiprocessing", "socket", "http", "urllib", "email",
    "hashlib", "hmac", "secrets", "uuid", "copy", "enum", "dataclasses",
    "contextlib", "shutil", "tempfile", "glob", "string", "textwrap",
    "sqlite", "asyncio", "queue", "pickle", "struct", "array", "warnings",
}
_DEPENDENCY_MANIFEST_NAMES = {"requirements.txt", "requirements-dev.txt"}


def _strip_stdlib_from_requirements_txt(content: str) -> str:
    """Drop lines from a requirements.txt-style file that name a Python
    stdlib module instead of a real PyPI package. Preserves blank lines,
    comments, and anything not recognized as stdlib untouched."""
    out_lines = []
    dropped = []
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            out_lines.append(line)
            continue
        # requirements.txt entries: "pkg", "pkg==1.0", "pkg>=1.0,<2.0", etc.
        name = re.split(r"[=<>~!\[; ]", stripped, maxsplit=1)[0].strip().lower()
        if name in _PYTHON_STDLIB_MODULES:
            dropped.append(stripped)
            continue
        out_lines.append(line)
    if dropped:
        logger.warning(
            "Filtered stdlib module(s) hallucinated as pip dependencies from "
            "requirements.txt: %s", ", ".join(dropped),
        )
    return "\n".join(out_lines)


class FileManager:
    def __init__(self, project_root: Path, lock_manager: FileLockManager | None = None) -> None:
        self.project_root = project_root
        self.project_root.mkdir(parents=True, exist_ok=True)
        self.locks = lock_manager or FileLockManager(project_root / ".orchestrator" / "locks.json")
        self.repo = self._ensure_repo()

    def _ensure_repo(self) -> Repo:
        try:
            return Repo(self.project_root)
        except InvalidGitRepositoryError:
            repo = Repo.init(self.project_root)
            with repo.config_writer() as cw:
                cw.set_value("user", "name", "AI Orchestrator")
                cw.set_value("user", "email", "orchestrator@localhost")
            return repo

    @staticmethod
    def _safe_relative_path(relative_path: str) -> Path:
        if not isinstance(relative_path, str) or not relative_path.strip():
            raise ValueError("File path must be a non-empty string")
        raw = relative_path.strip().replace("\\", "/")
        p = Path(raw)
        if p.is_absolute() or raw.startswith("/"):
            raise ValueError(f"Absolute file paths are not allowed: {relative_path!r}")
        parts: list[str] = []
        reserved = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1,10)), *(f"LPT{i}" for i in range(1,10))}
        for part in p.parts:
            if part in ("", "."):
                continue
            if part == "..":
                raise ValueError(f"Path traversal is not allowed: {relative_path!r}")
            clean = re.sub(r'[<>:"|?*]', '_', part).rstrip(" .")
            if not clean:
                raise ValueError(f"Invalid path component: {relative_path!r}")
            if clean.split(".", 1)[0].upper() in reserved:
                clean = "_" + clean
            parts.append(clean)
        if not parts:
            raise ValueError(f"Invalid file path: {relative_path!r}")
        return Path(*parts)

    def write_file(self, relative_path: str, content: str, task_id: str, commit_message: str | None = None, *, commit: bool = True) -> Path:
        safe_path = self._safe_relative_path(relative_path)
        self.locks.acquire(str(safe_path), task_id)
        full_path = self.project_root / safe_path
        # Guard against file/directory collisions before mkdir().
        parent = full_path.parent
        if parent.exists() and not parent.is_dir():
            raise ValueError(f"Cannot create directory '{parent}': a file already exists there")
        if full_path.exists() and full_path.is_dir():
            raise ValueError(f"Cannot write file '{safe_path}': a directory already exists at that path")
        parent.mkdir(parents=True, exist_ok=True)
        if not isinstance(content, str):
            raise TypeError("File content must be a string")
        if safe_path.name.lower() in _DEPENDENCY_MANIFEST_NAMES:
            content = _strip_stdlib_from_requirements_txt(content)
        full_path.write_text(content, encoding="utf-8")

        self.repo.index.add([str(full_path.relative_to(self.project_root))])
        if commit:
            self.commit_pending(commit_message or f"Update {safe_path} (task {task_id})")
        return full_path

    def commit_pending(self, message: str) -> str:
        try:
            commit = self.repo.index.commit(message)
            return commit.hexsha
        except Exception as exc:  # noqa: BLE001
            logger.debug("Commit skipped: %s", exc)
            return ""

    def read_file(self, relative_path: str) -> str | None:
        full_path = self.project_root / relative_path
        if not full_path.exists():
            return None
        try:
            return full_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Not every file under project_root is guaranteed to be text
            # written by write_file() — a coding/testing task can create
            # a real binary artifact on disk (e.g. a SQLite .db file for
            # a "Data Persistence" task, an image, a compiled .pyc, etc).
            # list_files() picks those up too, and callers like the Debug
            # stage (which reads every project file to build model context)
            # previously crashed the whole stage with an uncaught
            # UnicodeDecodeError the moment one binary file existed.
            # Report it instead of pretending it's text.
            size = full_path.stat().st_size
            logger.debug("read_file: '%s' is not valid UTF-8 text (%d bytes); treating as binary", relative_path, size)
            return f"[binary file, {size} bytes — content omitted]"

    def read_files_snapshot(self, relative_paths: list[str]) -> dict[str, str | None]:
        """Read a stable per-call snapshot once so callers don't observe a
        different file body between multiple reads in one decision."""
        return {path: self.read_file(path) for path in dict.fromkeys(relative_paths)}

    def is_text_file(self, relative_path: str) -> bool:
        """True if the file exists and can be read as UTF-8 text."""
        full_path = self.project_root / relative_path
        if not full_path.exists():
            return False
        try:
            full_path.read_text(encoding="utf-8")
            return True
        except UnicodeDecodeError:
            return False

    def release_task_locks(self, task_id: str) -> None:
        self.locks.release_all_for_task(task_id)

    def checkpoint(self, label: str) -> str:
        """A checkpoint is a lightweight git tag on the current commit."""
        if not self.repo.head.is_valid():
            try:
                self.repo.index.commit("Initial checkpoint")
            except Exception as exc:  # noqa: BLE001 - e.g. nothing to commit yet
                logger.warning("Could not create initial commit for checkpoint '%s': %s", label, exc)
                return ""
        tag_name = f"checkpoint/{label}"
        self.repo.create_tag(tag_name, force=True)
        return tag_name

    def rollback_to(self, label: str) -> None:
        tag_name = f"checkpoint/{label}"
        self.repo.git.reset("--hard", tag_name)

    def history(self, relative_path: str, max_entries: int = 20) -> list[str]:
        try:
            commits = list(self.repo.iter_commits(paths=relative_path, max_count=max_entries))
        except Exception:  # noqa: BLE001 - e.g. empty repo
            return []
        return [f"{c.hexsha[:8]} {c.message.strip()}" for c in commits]

    def list_files(self) -> list[str]:
        return [
            str(p.relative_to(self.project_root))
            for p in self.project_root.rglob("*")
            if p.is_file() and ".git" not in p.parts and ".orchestrator" not in p.parts
        ]