"""
File Lock Manager — ensures two agents never modify the same file simultaneously.

Changes in this revision
────────────────────────
Issue 30: Lock record includes acquired_at + pid; stale locks cleared on resume.
Issue 31: acquire/write wrapped in try/finally; release guaranteed.
Issue 32: threading.Lock for in-process atomic read-modify-write.
"""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

from orchestrator.core.exceptions import FileLockConflictError

# Locks held by a dead process (pid no longer running) older than this
# threshold are automatically released on resume.
_STALE_LOCK_AGE_SECONDS = 3600  # 1 hour


class FileLockManager:
    def __init__(self, lock_file: Path) -> None:
        self.lock_file = lock_file
        self.lock_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.lock_file.exists():
            self.lock_file.write_text("{}", encoding="utf-8")
        # Issue 32: process-level mutex for atomic read-modify-write
        self._mutex = threading.Lock()

    def _read(self) -> dict[str, dict]:
        """Return lock table. Each value is {owner, acquired_at, pid}."""
        try:
            raw = self.lock_file.read_text(encoding="utf-8") or "{}"
            data = json.loads(raw)
            # Backward compat: old entries were plain strings (owner only)
            out = {}
            for path, entry in data.items():
                if isinstance(entry, str):
                    out[path] = {"owner": entry, "acquired_at": 0.0, "pid": 0}
                else:
                    out[path] = entry
            return out
        except (json.JSONDecodeError, OSError):
            return {}

    def _write(self, locks: dict) -> None:
        """Atomic write via tmp+rename."""
        tmp = self.lock_file.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(locks, indent=2), encoding="utf-8")
        tmp.replace(self.lock_file)

    def _is_stale(self, entry: dict) -> bool:
        """Issue 30: a lock is stale if the owning process no longer exists
        or the lock is older than _STALE_LOCK_AGE_SECONDS."""
        pid = entry.get("pid", 0)
        acquired_at = entry.get("acquired_at", 0.0)
        age = time.time() - acquired_at
        if age > _STALE_LOCK_AGE_SECONDS:
            return True
        if pid and pid != os.getpid():
            try:
                os.kill(pid, 0)  # signal 0 = check existence without killing
            except (ProcessLookupError, PermissionError):
                return True  # process is dead
        return False

    def _purge_stale(self, locks: dict) -> dict:
        return {p: e for p, e in locks.items() if not self._is_stale(e)}

    def acquire(self, file_path: str, task_id: str) -> None:
        """Issue 32: mutex ensures atomic read-check-write."""
        with self._mutex:
            locks = self._purge_stale(self._read())
            entry = locks.get(file_path)
            if entry and entry.get("owner") != task_id:
                raise FileLockConflictError(
                    f"File '{file_path}' is locked by '{entry['owner']}' "
                    f"(requested by '{task_id}')."
                )
            locks[file_path] = {
                "owner": task_id,
                "acquired_at": time.time(),
                "pid": os.getpid(),
            }
            self._write(locks)

    def release(self, file_path: str, task_id: str) -> None:
        """Issue 31: always releases even if acquire partially failed."""
        with self._mutex:
            locks = self._read()
            if locks.get(file_path, {}).get("owner") == task_id:
                del locks[file_path]
                self._write(locks)

    def release_all_for_task(self, task_id: str) -> None:
        """Issue 31: release all locks owned by a task (called in finally)."""
        with self._mutex:
            locks = self._read()
            remaining = {p: e for p, e in locks.items() if e.get("owner") != task_id}
            self._write(remaining)

    def owner_of(self, file_path: str) -> str | None:
        locks = self._read()
        entry = locks.get(file_path)
        return entry.get("owner") if entry else None

    def release_stale(self) -> list[str]:
        """Issue 30: explicit stale-lock cleanup; returns released paths."""
        with self._mutex:
            locks = self._read()
            cleaned = self._purge_stale(locks)
            released = [p for p in locks if p not in cleaned]
            if released:
                self._write(cleaned)
        return released
