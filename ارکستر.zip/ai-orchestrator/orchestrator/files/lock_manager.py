"""
File Lock Manager — "two AIs must never modify the same file at the
same time" (design doc). Simple in-memory + on-disk lock table: one
owner (a task_id) per file path, released when the task completes.
"""

from __future__ import annotations

import json
from pathlib import Path

from orchestrator.core.exceptions import FileLockConflictError


class FileLockManager:
    def __init__(self, lock_file: Path) -> None:
        self.lock_file = lock_file
        self.lock_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.lock_file.exists():
            self.lock_file.write_text("{}", encoding="utf-8")

    def _read(self) -> dict[str, str]:
        try:
            return json.loads(self.lock_file.read_text(encoding="utf-8") or "{}")
        except json.JSONDecodeError:
            # A corrupt lock file (e.g. from a crash mid-write, before
            # the atomic-write fix below was in place, or from manual
            # editing) should not permanently wedge the workflow — reset
            # to an empty lock table rather than raising.
            return {}

    def _write(self, locks: dict[str, str]) -> None:
        tmp_path = self.lock_file.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(locks, indent=2), encoding="utf-8")
        tmp_path.replace(self.lock_file)

    def acquire(self, file_path: str, task_id: str) -> None:
        locks = self._read()
        owner = locks.get(file_path)
        if owner and owner != task_id:
            raise FileLockConflictError(
                f"File '{file_path}' is already locked by task '{owner}' "
                f"(requested by task '{task_id}')."
            )
        locks[file_path] = task_id
        self._write(locks)

    def release(self, file_path: str, task_id: str) -> None:
        locks = self._read()
        if locks.get(file_path) == task_id:
            del locks[file_path]
            self._write(locks)

    def release_all_for_task(self, task_id: str) -> None:
        locks = self._read()
        remaining = {p: owner for p, owner in locks.items() if owner != task_id}
        self._write(remaining)

    def owner_of(self, file_path: str) -> str | None:
        return self._read().get(file_path)
