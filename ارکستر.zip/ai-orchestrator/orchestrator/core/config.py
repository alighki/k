"""
Central configuration. Single-user system, so this is a single YAML
file (config/orchestrator.yaml) plus environment variable overrides —
no multi-tenant config store, no per-user settings tables.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

REPO_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.environ.get("ORCHESTRATOR_DATA_DIR", REPO_ROOT / "data"))
CONFIG_PATH = Path(os.environ.get("ORCHESTRATOR_CONFIG", REPO_ROOT / "config" / "orchestrator.yaml"))


class ModelRoute(BaseModel):
    """Which provider+model handles a given AgentRole, plus fallbacks."""

    provider: str
    model: str
    fallback_provider: str | None = None
    fallback_model: str | None = None


class QualityThresholds(BaseModel):
    excellent: float = 90.0
    good: float = 75.0
    weak_pass: float = 60.0


# Quality profiles — selected via CLI --quality flag.
# Each profile sets concrete runtime thresholds that actually change
# what the engine accepts, not just what the prompt says.
QUALITY_PROFILES: dict[str, QualityThresholds] = {
    "high": QualityThresholds(excellent=92.0, good=82.0, weak_pass=80.0),
    "medium": QualityThresholds(excellent=90.0, good=75.0, weak_pass=65.0),
    "low": QualityThresholds(excellent=85.0, good=68.0, weak_pass=55.0),
}


def get_quality_thresholds_for_profile(profile: str) -> QualityThresholds:
    """Return thresholds for a named quality profile, falling back to 'medium'."""
    return QUALITY_PROFILES.get(profile.lower(), QUALITY_PROFILES["medium"])


class PolicySettings(BaseModel):
    """Autonomous Decision Policy — see decision/policy.py.
    Everything NOT listed here as "requires_user" is decided
    autonomously by the system."""

    requires_user_confirmation: list[str] = Field(default_factory=lambda: [
        "delete_data",
        "spend_money",
        "access_credentials",
        "security_sensitive_change",
        "purely_aesthetic_choice",  # e.g. brand color — genuinely a taste call
        "irreversible_external_action",
    ])
    max_review_rounds: int | None = 3
    max_debug_loops: int | None = 6
    min_confidence_to_proceed: float = 0.80
    min_consensus_to_auto_decide: float = 0.60
    # Design doc: "instead of one Reviewer, have three; if two agree,
    # accept." use_multi_reviewer toggles this behaviour on/off.
    use_multi_reviewer: bool = False
    # Multi-reviewer consensus: requires at least this many accepts.
    # Using absolute counts (not fractions) prevents the 1/2 = 0.5 loophole
    # where only two reviewers remain but the threshold is still met.
    reviewer_required_accepts: int = 2      # minimum "accept" votes to pass
    reviewer_minimum_panel: int = 3         # refuse consensus if panel < this
    # Legacy fraction field kept for YAML backward compat; ignored when
    # reviewer_required_accepts / reviewer_minimum_panel are set.
    reviewer_agreement_threshold: float = 0.5
    # Design doc: "before even one file changes, simulate the whole
    # operation mentally, like chess — think first, then act."
    use_simulation: bool = False
    use_research: bool = False
    use_prompt_engineer: bool = False
    serial_coding: bool = True


class ConnectorSettings(BaseModel):
    ollama_base_url: str = "http://localhost:11434"
    default_timeout_seconds: int = 1200
    max_retries: int = 0
    max_output_tokens: int = 4096


class OrchestratorConfig(BaseModel):
    identity_name: str | None = None  # set on first run by Identity System
    data_dir: Path = DATA_DIR
    quality_thresholds: QualityThresholds = Field(default_factory=QualityThresholds)
    policy: PolicySettings = Field(default_factory=PolicySettings)
    connectors: ConnectorSettings = Field(default_factory=ConnectorSettings)

    # Capability Table: which AgentRole prefers which LOCAL model.
    # Fully local-only configuration — every route points at Ollama,
    # no web/browser connectors anywhere. Pull these before first use:
    #   ollama pull gemma3:12b
    #   ollama pull qwen2.5-coder
    #   ollama pull deepseek-r1:8b
    #   ollama pull deepseek-coder-v2
    #   ollama pull deepcoder
    #   ollama pull deepseek-coder
    #   ollama pull codegemma
    routes: dict[str, ModelRoute] = Field(default_factory=lambda: {
        "idea_expander": ModelRoute(provider="ollama_local", model="gemma3:12b"),
        "planner": ModelRoute(provider="ollama_local", model="qwen2.5-coder:7b"),
        "chief_architect": ModelRoute(provider="ollama_local", model="deepseek-r1:14b"),
        "researcher": ModelRoute(provider="ollama_local", model="qwen3:14b"),
        "prompt_engineer": ModelRoute(provider="ollama_local", model="qwen2.5-coder:7b"),
        "programmer": ModelRoute(provider="ollama_local", model="deepseek-coder:6.7b",
                                  fallback_provider="ollama_local", fallback_model="qwen2.5-coder:7b"),
        # Second and third opinions for the Programmer role — used when
        # a caller wants multiple independent code proposals (e.g. a
        # future N-way code consensus), mirroring the reviewer_* pattern.
        "programmer_secondary": ModelRoute(provider="ollama_local", model="qwen2.5-coder:7b"),
        "programmer_tertiary": ModelRoute(provider="ollama_local", model="deepseek-coder:6.7b"),
        "reviewer": ModelRoute(provider="ollama_local", model="deepseek-r1:8b"),
        # Second and third opinions for multi-reviewer consensus (see
        # PolicySettings.use_multi_reviewer). Deliberately different
        # local models than the primary reviewer so three independent
        # votes aren't just one model agreeing with itself three times.
        "reviewer_secondary": ModelRoute(provider="ollama_local", model="codegemma"),
        "reviewer_tertiary": ModelRoute(provider="ollama_local", model="qwen3:14b"),
        "debugger": ModelRoute(provider="ollama_local", model="deepseek-coder:6.7b",
                                fallback_provider="ollama_local", fallback_model="qwen2.5-coder:7b"),
        "debugger_secondary": ModelRoute(provider="ollama_local", model="deepseek-r1:14b"),
        "judge": ModelRoute(provider="ollama_local", model="deepseek-r1:14b"),
        "evaluator": ModelRoute(provider="ollama_local", model="qwen2.5-coder:7b"),
        "documenter": ModelRoute(provider="ollama_local", model="qwen3:14b"),
        "content_writer": ModelRoute(provider="ollama_local", model="gemma3:12b"),
    })

    @classmethod
    def load(cls) -> "OrchestratorConfig":
        if CONFIG_PATH.exists():
            raw: dict[str, Any] = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
            return cls.model_validate(raw)
        return cls()

    def save(self) -> None:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(
            yaml.safe_dump(self.model_dump(mode="json"), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )


_config: OrchestratorConfig | None = None


def get_config() -> OrchestratorConfig:
    global _config
    if _config is None:
        _config = OrchestratorConfig.load()
    return _config
