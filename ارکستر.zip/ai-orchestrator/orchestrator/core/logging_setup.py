"""
One place that configures logging for the whole system.

Every module gets its logger via `get_logger(__name__)`. Logs go to
both a rotating file (data/logs/orchestrator.log) and, when running
interactively, Rich-formatted console output.

This is deliberately boring: no structured-logging framework, no
external log shipping — this is a single-user tool, not a fleet.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

from rich.logging import RichHandler

from orchestrator.core.config import get_config

_configured = False


def setup_logging(console: bool = True) -> None:
    global _configured
    if _configured:
        return
    cfg = get_config()
    log_dir = Path(cfg.data_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    handlers: list[logging.Handler] = []

    file_handler = logging.handlers.RotatingFileHandler(
        log_dir / "orchestrator.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    ))
    # DEBUG on the file handler specifically (console stays at INFO,
    # set below) so raw-model-output diagnostics -- e.g. the failed
    # JSON that base.py logs on a parsing-pipeline failure -- land in
    # orchestrator.log for later grep without flooding interactive runs.
    file_handler.setLevel(logging.DEBUG)
    handlers.append(file_handler)

    if console:
        console_handler = RichHandler(rich_tracebacks=True, show_path=False)
        console_handler.setLevel(logging.INFO)
        handlers.append(console_handler)

    logging.basicConfig(level=logging.DEBUG, handlers=handlers, force=True)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    setup_logging()
    return logging.getLogger(name)
