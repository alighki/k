"""
Shared enums and value objects used across the whole system.

Keeping these in one place (instead of scattering literal strings like
"pending" / "coding" through the codebase) is what makes the System
"rule-based, not intelligent": every state transition is a value in a
closed enum, so an invalid state is a bug the type checker catches,
not a runtime surprise.
"""

from __future__ import annotations

import uuid
from enum import Enum
from datetime import datetime, timezone


def new_id(prefix: str = "") -> str:
    """Generate a short, sortable, collision-safe id."""
    suffix = uuid.uuid4().hex[:12]
    return f"{prefix}_{suffix}" if prefix else suffix


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ProjectStage(str, Enum):
    """The canonical lifecycle of a project. See workflow/engine.py."""

    RECEIVED = "received"
    IDEA_EXPANSION = "idea_expansion"
    RESEARCH = "research"
    ARCHITECTURE = "architecture"
    PLANNING = "planning"           # Task Tree construction
    PROMPT_BUILD = "prompt_build"
    CODING = "coding"
    REVIEW = "review"
    TESTING = "testing"
    DEBUG = "debug"
    OUTPUT = "output"
    DONE = "done"
    FAILED = "failed"


# Stages that are allowed to run in parallel with each other because they
# have no data dependency (see workflow/engine.py PARALLEL_GROUPS).
PARALLELIZABLE_STAGES = {
    ProjectStage.RESEARCH,
    ProjectStage.ARCHITECTURE,
}


class AgentRole(str, Enum):
    """Every specialist the system can call. New roles can be added
    without touching the Core (see agents/registry.py)."""

    IDEA_EXPANDER = "idea_expander"
    PLANNER = "planner"
    CHIEF_ARCHITECT = "chief_architect"
    RESEARCHER = "researcher"
    PROMPT_ENGINEER = "prompt_engineer"
    PROGRAMMER = "programmer"
    REVIEWER = "reviewer"
    DEBUGGER = "debugger"
    JUDGE = "judge"
    EVALUATOR = "evaluator"
    DOCUMENTER = "documenter"
    CONTENT_WRITER = "content_writer"


class ModelProvider(str, Enum):
    """Which backend a connector talks to. Local-only build: Ollama is
    the only supported provider — see connectors/registry.py."""

    OLLAMA_LOCAL = "ollama_local"    # Any local Ollama model


class TaskStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    BLOCKED = "blocked"          # waiting on a dependency
    NEEDS_REVIEW = "needs_review"
    ACCEPTED = "accepted"
    FORCED_ACCEPTED = "forced_accepted"  # accepted by Quick Finish, not full review (PROBLEM 12)
    REJECTED = "rejected"
    FAILED = "failed"
    DEFERRED = "deferred"        # explicitly pushed to a later version


class DecisionStatus(str, Enum):
    AUTO_APPROVED = "auto_approved"
    USER_APPROVED = "user_approved"
    PENDING_USER = "pending_user"      # only for irreversible/sensitive calls
    SUPERSEDED = "superseded"          # replaced by a later decision


class QualityBand(str, Enum):
    EXCELLENT = "excellent"   # >= 90
    GOOD = "good"             # 75-89
    WEAK_PASS = "weak_pass"   # 60-74
    REJECTED = "rejected"     # < 60

    @classmethod
    def from_score(cls, score: float) -> "QualityBand":
        if score >= 90:
            return cls.EXCELLENT
        if score >= 75:
            return cls.GOOD
        if score >= 60:
            return cls.WEAK_PASS
        return cls.REJECTED


class MemoryLayer(str, Enum):
    SHORT = "short"     # current task/stage working context
    LONG = "long"       # whole-project facts and decisions
    ARCHIVE = "archive"  # completed projects, compressed
