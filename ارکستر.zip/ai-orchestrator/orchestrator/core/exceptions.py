"""
Every failure mode the design doc worried about gets its own exception
class. This makes Retry/Fallback logic explicit: the Retry Manager
catches specific exception types and knows exactly what policy applies
to each (see workflow/retry.py).
"""


class OrchestratorError(Exception):
    """Base class for all orchestrator-specific errors."""


class ConnectorError(OrchestratorError):
    """Base class for AI connector failures."""


class ConnectorTimeoutError(ConnectorError):
    """The model did not respond within the configured time budget."""


class ConnectorAuthError(ConnectorError):
    """Login/session for a web model expired or was rejected."""


class ConnectorUnavailableError(ConnectorError):
    """The connector's backend (browser/Ollama) could not be reached."""


class MalformedResponseError(OrchestratorError):
    """The model's response could not be parsed into the expected
    output contract (see prompt/output_contract.py)."""


class LowConfidenceError(OrchestratorError):
    """A response's self-reported confidence is below the configured
    floor and the system is not permitted to proceed on it."""


class FileLockConflictError(OrchestratorError):
    """Two tasks tried to claim ownership of the same file."""


class QualityGateFailure(OrchestratorError):
    """A stage's quality score fell below the rejection threshold too
    many times in a row."""


class DependencyCycleError(OrchestratorError):
    """The Task Tree contains a circular dependency."""


class CheckpointCorruptError(OrchestratorError):
    """A saved checkpoint could not be restored."""


class PolicyViolationError(OrchestratorError):
    """An agent or workflow step attempted an action the Policy Engine
    forbids (e.g. deleting data, spending money, touching credentials)
    without the required user approval."""
