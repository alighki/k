"""
Output Contract — every agent prompt demands the SAME structured
envelope back, regardless of which model answers. This is what makes
Output Parser (agents/base.py) reliable instead of regex-guessing at
free text, and it's what powers the Confidence Engine described in
the design doc.

Contract (the model is instructed to answer ONLY with this JSON):

{
  "answer": "...",              # the actual content/deliverable
  "confidence": 0-100,
  "reasons": ["..."],
  "unknown_parts": ["..."],
  "files": [{"path": "...", "content": "..."}],   # optional
  "decisions_proposed": [{"topic": "...", "value": "...", "reasons": ["..."]}],
  "tasks_proposed": [{"title": "...", "depends_on_titles": ["..."], "effort": "S|M|L", "risk": "low|medium|high"}]
}

Not every field is used by every agent (e.g. Researcher rarely emits
`files`), but the shape is always the same so parsing code never
branches on "which model answered".
"""

from __future__ import annotations

import json
from pydantic import BaseModel, Field

from orchestrator.core.exceptions import MalformedResponseError


class ProposedFile(BaseModel):
    path: str
    content: str


class ProposedDecision(BaseModel):
    topic: str
    value: str
    reasons: list[str] = Field(default_factory=list)


class ProposedTask(BaseModel):
    """Used only by the Planner agent. Structured tasks are far more
    reliable to consume than parsing free text out of `answer` — see
    workflow/engine.py _stage_planning, which prefers this field and
    only falls back to text-parsing if the model ignored it."""

    title: str
    key: str = ""          # short snake_case identifier the model assigns
                           # itself (e.g. "setup_db"). Used for depends_on
                           # references to eliminate fuzzy title matching.
                           # Falls back to normalized title if absent.
    depends_on_titles: list[str] = Field(default_factory=list)
    effort: str = "M"     # S / M / L
    risk: str = "low"     # low / medium / high
    deferred: bool = False


class AgentResponse(BaseModel):
    answer: str
    confidence: int = Field(ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    solutions: list[str] = Field(default_factory=list)
    unknown_parts: list[str] = Field(default_factory=list)
    files: list[ProposedFile] = Field(default_factory=list)
    decisions_proposed: list[ProposedDecision] = Field(default_factory=list)
    tasks_proposed: list[ProposedTask] = Field(default_factory=list)

    raw_text: str = Field(default="", exclude=True)  # original text, for debugging/audit
    # Populated by BaseAgent.run() AFTER the call (never requested from
    # the model itself) so callers like workflow/engine.py can feed the
    # REAL Quality Score back to AIManager for the specific provider/
    # model that actually produced this response.
    provider_used: str = Field(default="", exclude=True)
    model_used: str = Field(default="", exclude=True)
    parse_status: str = Field(default="success", exclude=True)  # "success" | "repaired" | "parse_failed"

    @property
    def is_parse_failed(self) -> bool:
        return self.parse_status == "parse_failed"


CONTRACT_INSTRUCTIONS = """
You MUST answer with a single JSON object and nothing else (no markdown
fences, no commentary before or after). The JSON object must have
exactly these keys:

{
  "answer": "<your main answer as a string>",
  "confidence": <integer 0-100, your own honest confidence in this answer>,
  "reasons": ["<short reason>", "..."],
  "solutions": ["<specific actionable fix>", "..."],
  "unknown_parts": ["<anything you are not sure about>", "..."],
  "files": [{"path": "<relative path>", "content": "<full file content>"}],
  "decisions_proposed": [{"topic": "<short topic id>", "value": "<chosen value>", "reasons": ["..."]}],
  "tasks_proposed": [{"key": "<snake_case_id>", "title": "<short unique title>", "depends_on_titles": ["<key of another task>"], "effort": "S|M|L", "risk": "low|medium|high", "deferred": false}]
}

IMPORTANT for tasks_proposed: each task must have a short snake_case
"key" you invent (e.g. "setup_db", "implement_auth"). Use these keys
(not full titles) in depends_on_titles to reference other tasks —
this avoids title-matching errors. Keys must be unique across all tasks.

If a key doesn't apply, use an empty list or empty string — never omit
the key. Do not wrap the JSON in ```json fences.

CRITICAL — how to put source code inside "content" (or any string):
this is standard JSON, NOT Python. There is no triple-quote (\"\"\")
string syntax in JSON. Every string, including file contents, must be
a single-line JSON string with newlines written as the two characters
\\n and any double-quote inside the code escaped as \\". Do this:

  "content": "import os\\n\\ndef main():\\n    print(\\"hi\\")\\n"

Do NOT do this (invalid JSON, will be rejected):

  "content": \"\"\"
  import os

  def main():
      print("hi")
  \"\"\"
"""


def _attempt_json_repair(text: str) -> str:
    """Deprecated: kept only so any external/older code importing this
    name directly doesn't break. New code should use
    orchestrator.prompt.json_pipeline.automatic_repair, which is the
    same logic plus control-character escaping (important for
    files[].content carrying raw multi-line source code)."""
    from orchestrator.prompt.json_pipeline import automatic_repair
    return automatic_repair(text)


def parse_agent_response(raw_text: str) -> AgentResponse:
    """Deterministic-only parse: Extract -> Parse -> Automatic Repair ->
    Parse -> Schema Validation. Does NOT attempt AI-assisted repair —
    that requires a model call and is orchestrated by
    agents/base.py::BaseAgent.run(), which calls
    orchestrator.prompt.json_pipeline.run_deterministic_pipeline()
    directly and only falls back to an AI repair call if this raises.

    This function is kept as a simple, synchronous, no-model-call
    entry point for tests and any caller that doesn't need (or can't
    do) the AI-repair fallback stage."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline

    result = run_deterministic_pipeline(raw_text)
    if result.succeeded:
        assert result.response is not None
        return result.response

    last_error = result.attempts[-1].error if result.attempts else "unknown error"
    raise MalformedResponseError(
        f"Could not parse model response into AgentResponse contract "
        f"(pipeline: {' -> '.join(a.stage for a in result.attempts)}): {last_error}\n"
        f"Raw response (truncated): {raw_text[:500]}"
    )


def agent_response_json_schema() -> dict:
    """Return a compact Ollama structured-output schema containing only
    fields the model is expected to generate. Runtime-only metadata is
    deliberately excluded to reduce output confusion and token usage."""
    schema = AgentResponse.model_json_schema()
    properties = schema.get("properties", {})
    for name in ("raw_text", "provider_used", "model_used"):
        properties.pop(name, None)
    required = [name for name in schema.get("required", []) if name in properties]
    schema["properties"] = properties
    schema["required"] = required
    return schema
