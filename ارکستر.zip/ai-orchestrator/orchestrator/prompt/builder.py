"""
Prompt Builder + Prompt Reviewer, the pipeline the design doc singles
out as "probably the single most important part of the whole project":

    Planner/Workflow -> Prompt Builder -> Prompt Reviewer -> AI

Prompt Builder assembles: role instructions + compact memory context +
the specific task + the output contract. Prompt Reviewer is a cheap,
local sanity check (no need to call another AI just to check a
prompt's shape) that catches the most common failure: a prompt that's
grown too large, or is missing the task itself.
"""

from __future__ import annotations

from orchestrator.core.types import AgentRole
from orchestrator.memory.manager import MemoryManager
from orchestrator.prompt.models import PromptVersion
from orchestrator.prompt.output_contract import CONTRACT_INSTRUCTIONS
from orchestrator.prompt.templates import base_instructions_for

MAX_PROMPT_CHARS = 12_000  # ~3k tokens; keeps requests fast and cheap


class PromptBuilder:
    def __init__(self, memory: MemoryManager | None = None) -> None:
        self.memory = memory or MemoryManager()

    def build(self, project_id: str, role: AgentRole, task_description: str,
              task_id: str | None = None, extra_context: str = "") -> PromptVersion:
        system_instructions = base_instructions_for(role)
        context_block = self.memory.context_for_stage(project_id)
        if extra_context:
            context_block = f"{context_block}\n\n## Task-specific context\n{extra_context}"

        task_block = f"## Your task\n{task_description.strip()}"

        full_text = (
            f"{system_instructions}\n\n{context_block}\n\n{task_block}\n\n"
            f"## Required output format\n{CONTRACT_INSTRUCTIONS.strip()}"
        )

        prompt = PromptVersion(
            project_id=project_id, task_id=task_id, role=role,
            system_instructions=system_instructions, context_block=context_block,
            task_block=task_block, full_text=full_text,
        )
        return prompt


class PromptReviewer:
    """Deterministic, rule-based checks — deliberately NOT another AI
    call. Cheap and fast, catches the majority of real failures."""

    def review(self, prompt: PromptVersion) -> PromptVersion:
        notes: list[str] = []

        if len(prompt.full_text) > MAX_PROMPT_CHARS:
            notes.append(
                f"Prompt is {len(prompt.full_text)} chars, over the {MAX_PROMPT_CHARS} budget; "
                f"truncating context block."
            )
            overflow = len(prompt.full_text) - MAX_PROMPT_CHARS
            keep_from = max(0, len(prompt.context_block) - overflow)
            prompt.context_block = prompt.context_block[keep_from:]
            prompt.full_text = (
                f"{prompt.system_instructions}\n\n{prompt.context_block}\n\n"
                f"{prompt.task_block}\n\n## Required output format\n{CONTRACT_INSTRUCTIONS.strip()}"
            )

        if not prompt.task_block.strip() or len(prompt.task_block.strip()) < 20:
            notes.append("WARNING: task description looks too short/empty.")

        if "Required output format" not in prompt.full_text:
            notes.append("ERROR: output contract instructions missing — re-adding.")
            prompt.full_text += f"\n\n## Required output format\n{CONTRACT_INSTRUCTIONS.strip()}"

        prompt.reviewed = True
        prompt.review_notes = "; ".join(notes) if notes else "OK"
        return prompt
