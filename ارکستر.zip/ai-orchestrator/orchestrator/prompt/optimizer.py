"""
Advanced Prompt Optimizer — the design doc's Prompt Engineer Agent,
made real beyond a single generic rewrite call.

Three concrete improvements over the v0.1 PromptEngineerAgent.optimize()
(a single opaque LLM call with no model-specific knowledge):

  1. MODEL-SPECIFIC STYLE HINTS: different model families respond to
     different prompt shapes (terse + structured vs. discursive +
     reasoning-first). This module keeps a small, explicit style table
     per provider so the optimizer's instruction to the LLM is itself
     informed by which model will receive the result — not a generic
     "optimize this" with no target-specific guidance.
  2. LENGTH-AWARE COMPRESSION: computes a rough token budget from the
     target model's typical context comfort zone and explicitly asks
     the optimizer to compress toward that budget, rather than
     optimizing for clarity alone and hoping length works out.
  3. OUTCOME-INFORMED ITERATION: records (role, provider, prompt
     length bucket) -> average Quality Score in the same style as
     CapabilityEngine, so if a role/provider combination has been
     historically hurt by long prompts, the optimizer is told to
     compress harder for that specific combination going forward.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path

from orchestrator.core.config import get_config
from orchestrator.core.types import AgentRole

# Model-specific prompting style hints — deliberately short and
# factual, not marketing copy. Extend this table as more is learned
# about a given model's behaviour; it's a pure data table, no code
# changes needed elsewhere to update it.
# Model-specific prompting style hints — deliberately short and
# factual, not marketing copy. Keyed by MODEL name (not provider):
# this is a local-only build where every provider is "ollama_local",
# so the model itself is what actually varies in behaviour. Extend
# this table as more is learned about a given model; it's a pure data
# table, no code changes needed elsewhere to update it.
_STYLE_HINTS: dict[str, str] = {
    "deepseek-coder-v2": (
        "Code-specialized model. Responds best to a terse, structured "
        "prompt: explicit function signatures/interfaces first, then "
        "constraints, minimal scene-setting prose."
    ),
    "deepcoder": (
        "Code-specialized model. Prefers explicit numbered steps and "
        "the exact required output schema repeated right before the "
        "answer; avoid long preambles."
    ),
    "deepseek-coder": (
        "Code-specialized model, smaller than deepseek-coder-v2. Keep "
        "prompts especially concise; break multi-part tasks into "
        "clearly numbered sub-steps."
    ),
    "qwen2.5-coder": (
        "Code-specialized model. Responds well to explicit input/output "
        "examples when the task is non-trivial."
    ),
    "deepseek-r1:8b": (
        "Reasoning-focused model. Benefits from being explicitly asked "
        "to reason step by step before giving a final answer; don't "
        "rush it to the output format too early in the prompt."
    ),
    "gemma3:12b": (
        "General-purpose model. Responds well to clear role framing "
        "and a clearly labeled output format section."
    ),
    "codegemma": (
        "Code-specialized model. Prefers concrete, example-driven "
        "instructions over abstract requirement descriptions."
    ),
}
_DEFAULT_STYLE_HINT = "No specific style data yet for this model; use clear, concise instructions."

# Rough per-model "comfort zone" token budgets for a SINGLE task prompt
# (not the model's max context — a practical ceiling past which
# instruction-following quality tends to degrade for smaller local
# models specifically). Purely a heuristic default, editable here.
_TOKEN_BUDGETS: dict[str, int] = {
    "deepseek-coder-v2": 1600,
    "deepcoder": 1200,
    "deepseek-coder": 900,
    "qwen2.5-coder": 1200,
    "deepseek-r1:8b": 1400,
    "gemma3:12b": 1600,
    "codegemma": 1000,
}
_DEFAULT_TOKEN_BUDGET = 1200

_SCHEMA = """
CREATE TABLE IF NOT EXISTS prompt_outcome_stats (
    role TEXT NOT NULL,
    provider TEXT NOT NULL,
    length_bucket TEXT NOT NULL,
    samples INTEGER NOT NULL DEFAULT 0,
    score_sum REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (role, provider, length_bucket)
);
"""


def _length_bucket(char_count: int) -> str:
    if char_count < 1500:
        return "short"
    if char_count < 5000:
        return "medium"
    return "long"


@dataclass
class OptimizationGuidance:
    style_hint: str
    token_budget: int
    length_bucket_advice: str


class PromptOptimizationStats:
    """Tracks (role, provider, prompt-length-bucket) -> average Quality
    Score, so the optimizer can warn "long prompts have historically
    hurt this role/provider combination" instead of guessing blind."""

    def __init__(self, db_path: Path | None = None) -> None:
        cfg = get_config()
        self.db_path = db_path or (Path(cfg.data_dir) / "memory" / "prompt_stats.sqlite3")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def record(self, role: str, provider: str, prompt_char_count: int, quality_score: float) -> None:
        bucket = _length_bucket(prompt_char_count)
        row = self._conn.execute(
            "SELECT samples, score_sum FROM prompt_outcome_stats WHERE role=? AND provider=? AND length_bucket=?",
            (role, provider, bucket),
        ).fetchone()
        if row is None:
            self._conn.execute(
                "INSERT INTO prompt_outcome_stats VALUES (?,?,?,?,?)",
                (role, provider, bucket, 1, quality_score),
            )
        else:
            samples, score_sum = row
            self._conn.execute(
                "UPDATE prompt_outcome_stats SET samples=?, score_sum=? "
                "WHERE role=? AND provider=? AND length_bucket=?",
                (samples + 1, score_sum + quality_score, role, provider, bucket),
            )
        self._conn.commit()

    def advice_for(self, role: str, provider: str) -> str:
        rows = self._conn.execute(
            "SELECT length_bucket, samples, score_sum FROM prompt_outcome_stats "
            "WHERE role=? AND provider=?", (role, provider),
        ).fetchall()
        if not rows:
            return "No historical prompt-length data yet for this role/provider combination."

        averages = {bucket: (score_sum / samples) for bucket, samples, score_sum in rows if samples > 0}
        if len(averages) < 2:
            return "Not enough varied-length history yet to compare short vs. long prompts."

        best_bucket = max(averages, key=lambda b: averages[b])
        worst_bucket = min(averages, key=lambda b: averages[b])
        if best_bucket == worst_bucket:
            return "No meaningful difference observed across prompt lengths so far."
        return (
            f"Historically, '{best_bucket}' prompts scored better (avg {averages[best_bucket]:.0f}) "
            f"than '{worst_bucket}' prompts (avg {averages[worst_bucket]:.0f}) for this role/provider."
        )

    def close(self) -> None:
        self._conn.close()


class PromptOptimizer:
    """Pure guidance-building logic — no agent/model calls itself.
    PromptEngineerAgent (agents/specialists.py) consumes this to build
    a richer optimization instruction than a bare "improve this prompt"."""

    def __init__(self, stats: PromptOptimizationStats | None = None) -> None:
        self.stats = stats or PromptOptimizationStats()

    def guidance_for(self, target_role: AgentRole, target_model: str, target_provider: str = "ollama_local"
                      ) -> OptimizationGuidance:
        """Local-only build: style/budget lookups are keyed by MODEL
        name (see _STYLE_HINTS/_TOKEN_BUDGETS above), since provider is
        always "ollama_local" here and carries no distinguishing
        signal. `target_provider` is kept as a parameter (defaulting to
        "ollama_local") only so PromptOptimizationStats — which tracks
        outcomes per (role, provider) for backward-compatible schema
        reasons — still has a stable key to record/read against."""
        style_hint = _STYLE_HINTS.get(target_model, _DEFAULT_STYLE_HINT)
        token_budget = _TOKEN_BUDGETS.get(target_model, _DEFAULT_TOKEN_BUDGET)
        advice = self.stats.advice_for(target_role.value, target_provider)
        return OptimizationGuidance(style_hint=style_hint, token_budget=token_budget, length_bucket_advice=advice)

    def build_optimization_instruction(self, target_role: AgentRole, target_model: str, raw_task: str,
                                        target_provider: str = "ollama_local") -> str:
        guidance = self.guidance_for(target_role, target_model, target_provider)
        approx_current_tokens = len(raw_task) // 4
        return (
            f"Target role: {target_role.value}. Target local model: {target_model}.\n"
            f"Model-specific style guidance: {guidance.style_hint}\n"
            f"Target length budget: approximately {guidance.token_budget} tokens "
            f"(current draft is approximately {approx_current_tokens} tokens).\n"
            f"Historical prompt-length performance for this combination: {guidance.length_bucket_advice}\n\n"
            f"Raw task to optimize:\n{raw_task}"
        )

    def record_outcome(self, role: AgentRole, provider: str, prompt_char_count: int, quality_score: float) -> None:
        self.stats.record(role.value, provider, prompt_char_count, quality_score)
