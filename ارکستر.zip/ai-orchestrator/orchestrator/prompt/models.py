"""
PromptRequest — a fully-assembled, versioned prompt ready to send to a
connector. Versioning + storage matters because the design doc wants
prompts to be auditable ("why did this task get a bad answer? let's
look at exactly what prompt it received").
"""

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from orchestrator.core.types import AgentRole, new_id, utcnow


class PromptVersion(BaseModel):
    prompt_id: str = Field(default_factory=lambda: new_id("prm"))
    project_id: str
    task_id: str | None
    role: AgentRole
    version: int = 1
    system_instructions: str
    context_block: str
    task_block: str
    full_text: str
    created_at: datetime = Field(default_factory=utcnow)
    reviewed: bool = False
    review_notes: str = ""

    def approx_token_estimate(self) -> int:
        # Rough heuristic (chars/4), good enough for budget checks —
        # avoids pulling in a tokenizer dependency for a single-user tool.
        return len(self.full_text) // 4
