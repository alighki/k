"""
AI Orchestrator (local-only build)
===================================

A personal, single-user system that coordinates multiple LOCAL AI
models (via Ollama) to plan, design, code, review, test and ship
software projects better than any single model could alone.

This build has NO web/browser connectors and NO external API keys —
every model call goes to a locally-running Ollama instance. See
config/orchestrator.yaml for the exact role -> model routing table.

IMPORTANT ARCHITECTURAL PRINCIPLE (see docs/PHILOSOPHY.md):

    The System never thinks. It only coordinates.
    All analysis, all creativity, all code is produced by Agents,
    which are thin wrappers around AI models. The System's job is
    to be boring, predictable, auditable and hard to break.

This package is organized as:

    core/            shared types, config, exceptions, logging
    identity/        the Orchestrator's own persistent identity
    memory/          short/long/archive memory + decision memory
    knowledge_graph/ dependency graph between decisions/files/tasks
    prompt/          prompt building, optimization, versioning
    decision/        consensus, voting, conflict resolution, policy
    quality/         quality scoring for every artifact/step
    files/           file manager, version control, locks
    connectors/      AI Connector Layer (Ollama only)
    ai_manager/      capability + cost-aware routing across local models
    agents/          Planner, Architect, Researcher, Programmer, ...
    workflow/         Workflow Engine, Task Queue/Tree, Project State
    cli/             command line entry point
"""

__version__ = "0.2.0-local"
