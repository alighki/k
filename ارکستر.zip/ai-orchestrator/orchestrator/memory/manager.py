"""
MemoryManager — the high-level API agents/workflow actually use.
Wraps MemoryStore and adds the behaviours the design doc calls for:

  * compact_short_memory(): turn a pile of short-term notes into one
    dense summary before a stage ends, so prompts stay small.
  * archive_project(): compress a finished project's Long memory down
    to an Archive entry.
  * decision helpers with the "record reason, check before asking
    again" behaviour described in the doc's Decision Memory section.
"""

from __future__ import annotations

from orchestrator.core.types import MemoryLayer, utcnow
from orchestrator.memory.models import MemoryEntry, DecisionRecord
from orchestrator.memory.store import MemoryStore


class MemoryManager:
    def __init__(self, store: MemoryStore | None = None) -> None:
        self.store = store or MemoryStore()

    # ---- writing ---------------------------------------------------------

    def remember(self, project_id: str, key: str, value: str,
                 layer: MemoryLayer = MemoryLayer.SHORT, tags: list[str] | None = None) -> MemoryEntry:
        entry = MemoryEntry(project_id=project_id, layer=layer, key=key, value=value, tags=tags or [])
        self.store.add_entry(entry)
        return entry

    def promote_to_long(self, project_id: str, key: str, value: str, tags: list[str] | None = None) -> None:
        """Facts that must survive beyond the current stage (architecture
        choices, API contracts, established conventions) go here."""
        self.remember(project_id, key, value, layer=MemoryLayer.LONG, tags=tags)

    # ---- reading -----------------------------------------------------------

    def recall(self, project_id: str, key: str) -> str | None:
        entry = self.store.get_by_key(project_id, key)
        return entry.value if entry else None

    def context_for_stage(self, project_id: str, max_chars: int = 4000) -> str:
        """Builds the compact context block that Prompt Builder injects
        into every agent prompt: long-term facts + a short recent
        summary, NOT the entire project history (see design doc §2,
        'Prompt should never contain the whole project every time')."""
        long_entries = self.store.get_layer(project_id, MemoryLayer.LONG)
        short_entries = self.store.get_layer(project_id, MemoryLayer.SHORT)
        decisions = self.store.all_decisions(project_id)

        lines = ["# Project memory (compact)"]
        if decisions:
            lines.append("## Decisions so far")
            for d in decisions:
                if d.superseded_by is None:
                    lines.append(f"- {d.summary_line()}")
        if long_entries:
            lines.append("## Established facts")
            for e in long_entries[-20:]:
                lines.append(f"- {e.key}: {e.value}")
        if short_entries:
            lines.append("## Recent working notes")
            for e in short_entries[-10:]:
                lines.append(f"- {e.key}: {e.value}")

        text = "\n".join(lines)
        if len(text) > max_chars:
            text = text[-max_chars:]
        return text

    # ---- stage lifecycle -----------------------------------------------------

    def compact_short_memory(self, project_id: str, stage_summary: str) -> None:
        """Called by Workflow Engine when a stage completes: collapse
        all short-memory notes into a single Long-memory summary entry,
        then clear Short memory so the next stage starts clean."""
        self.promote_to_long(project_id, key=f"stage_summary.{utcnow().isoformat()}", value=stage_summary)
        self.store.clear_layer(project_id, MemoryLayer.SHORT)

    def archive_project(self, project_id: str, final_summary: str) -> None:
        self.remember(project_id, key="archive.summary", value=final_summary, layer=MemoryLayer.ARCHIVE)

    # ---- decisions -----------------------------------------------------------

    def existing_decision(self, project_id: str, topic: str) -> DecisionRecord | None:
        return self.store.get_decision_by_topic(project_id, topic)

    def record_decision(self, decision: DecisionRecord) -> None:
        """If a decision on this topic already exists, mark it superseded
        first — this is exactly the 'if an AI proposes changing an
        earlier decision, the system must retrieve the old one and its
        reason' behaviour from the design doc."""
        existing = self.existing_decision(decision.project_id, decision.topic)
        self.store.add_decision(decision)
        if existing:
            self.store.supersede_decision(existing.decision_id, decision.decision_id)

    def decision_history(self, project_id: str, topic: str) -> list[DecisionRecord]:
        return [d for d in self.store.all_decisions(project_id) if d.topic == topic]
