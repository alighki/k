"""
Memory data models. Three layers, exactly as specced:

  Short   — working context for the CURRENT stage/task only. Cleared
            or compressed once the stage completes. Keeps prompts small.
  Long    — durable facts/decisions for the life of ONE project.
  Archive — compressed summary of a COMPLETED project, kept forever
            so future projects can be compared against it.

Plus a separate DecisionMemory record type, because decisions need
extra fields (reason, alternatives considered, reversibility) that a
generic memory entry doesn't need — this mirrors the design doc's
explicit call-out that decisions must carry "why", not just "what".
"""

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from orchestrator.core.types import MemoryLayer, new_id, utcnow


class MemoryEntry(BaseModel):
    entry_id: str = Field(default_factory=lambda: new_id("mem"))
    project_id: str
    layer: MemoryLayer
    key: str                 # e.g. "stage.architecture.summary"
    value: str
    created_at: datetime = Field(default_factory=utcnow)
    tags: list[str] = Field(default_factory=list)


class DecisionRecord(BaseModel):
    decision_id: str = Field(default_factory=lambda: new_id("dec"))
    project_id: str
    topic: str                      # e.g. "backend_framework"
    chosen_value: str               # e.g. "FastAPI"
    alternatives: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)
    consensus_score: float | None = None   # 0..1, see decision/consensus.py
    status: str = "auto_approved"
    made_at: datetime = Field(default_factory=utcnow)
    superseded_by: str | None = None       # decision_id of the replacement, if any

    def summary_line(self) -> str:
        return f"{self.topic} = {self.chosen_value} (reasons: {'; '.join(self.reasons)})"
