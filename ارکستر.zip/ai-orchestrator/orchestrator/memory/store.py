"""
SQLite-backed storage for memory + decisions.

Why SQLite and not a vector DB / Redis / etc: this is a single-user,
single-machine tool (see design doc rule #1 — no multi-tenant
features). SQLite gives us durability, simple queries, and zero
operational overhead, which is exactly the "optimize for one user"
principle from the doc. If semantic search over memory is ever
needed, an embedding index can be bolted on later as an additional
module without touching this store's schema (see docstring at bottom).
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from orchestrator.core.config import get_config
from orchestrator.core.types import MemoryLayer
from orchestrator.memory.models import MemoryEntry, DecisionRecord

_SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_entries (
    entry_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    layer TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_memory_project ON memory_entries(project_id, layer);

CREATE TABLE IF NOT EXISTS decisions (
    decision_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    topic TEXT NOT NULL,
    chosen_value TEXT NOT NULL,
    alternatives TEXT NOT NULL DEFAULT '',
    reasons TEXT NOT NULL DEFAULT '',
    consensus_score REAL,
    status TEXT NOT NULL,
    made_at TEXT NOT NULL,
    superseded_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_decisions_project_topic ON decisions(project_id, topic);
"""


class MemoryStore:
    def __init__(self, db_path: Path | None = None) -> None:
        cfg = get_config()
        self.db_path = db_path or (Path(cfg.data_dir) / "memory" / "memory.sqlite3")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    # ---- generic memory -------------------------------------------------

    def add_entry(self, entry: MemoryEntry) -> None:
        # Tags are JSON-encoded rather than comma-joined: a tag/value
        # containing a literal comma would otherwise corrupt the
        # round-trip. Tags are currently internal-only (not LLM-
        # generated), but this keeps the encoding safe regardless.
        self._conn.execute(
            "INSERT INTO memory_entries VALUES (?,?,?,?,?,?,?)",
            (entry.entry_id, entry.project_id, entry.layer.value, entry.key,
             entry.value, entry.created_at.isoformat(), json.dumps(entry.tags)),
        )
        self._conn.commit()

    def get_layer(self, project_id: str, layer: MemoryLayer) -> list[MemoryEntry]:
        rows = self._conn.execute(
            "SELECT entry_id, project_id, layer, key, value, created_at, tags "
            "FROM memory_entries WHERE project_id=? AND layer=? ORDER BY created_at",
            (project_id, layer.value),
        ).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def get_by_key(self, project_id: str, key: str) -> MemoryEntry | None:
        row = self._conn.execute(
            "SELECT entry_id, project_id, layer, key, value, created_at, tags "
            "FROM memory_entries WHERE project_id=? AND key=? ORDER BY created_at DESC LIMIT 1",
            (project_id, key),
        ).fetchone()
        return self._row_to_entry(row) if row else None

    def clear_layer(self, project_id: str, layer: MemoryLayer) -> None:
        """Used when compacting Short memory at the end of a stage."""
        self._conn.execute(
            "DELETE FROM memory_entries WHERE project_id=? AND layer=?",
            (project_id, layer.value),
        )
        self._conn.commit()

    @staticmethod
    def _row_to_entry(row) -> MemoryEntry:
        from datetime import datetime
        entry_id, project_id, layer, key, value, created_at, tags = row
        try:
            parsed_tags = json.loads(tags) if tags else []
        except json.JSONDecodeError:
            # Backward compatibility with rows written by the old
            # comma-joined format before this fix.
            parsed_tags = [t for t in tags.split(",") if t]
        return MemoryEntry(
            entry_id=entry_id, project_id=project_id, layer=MemoryLayer(layer),
            key=key, value=value, created_at=datetime.fromisoformat(created_at),
            tags=parsed_tags,
        )

    # ---- decisions --------------------------------------------------------

    def add_decision(self, decision: DecisionRecord) -> None:
        # alternatives/reasons are JSON-encoded, not joined with a "||"
        # delimiter: reasons come from LLM-generated free text, which
        # could plausibly contain "||" as a literal substring (e.g. a
        # reason describing boolean-OR logic) and silently corrupt the
        # round-trip if string-joined.
        self._conn.execute(
            "INSERT INTO decisions VALUES (?,?,?,?,?,?,?,?,?,?)",
            (decision.decision_id, decision.project_id, decision.topic,
             decision.chosen_value, json.dumps(decision.alternatives),
             json.dumps(decision.reasons), decision.consensus_score,
             decision.status, decision.made_at.isoformat(), decision.superseded_by),
        )
        self._conn.commit()

    def get_decision_by_topic(self, project_id: str, topic: str) -> DecisionRecord | None:
        row = self._conn.execute(
            "SELECT decision_id, project_id, topic, chosen_value, alternatives, reasons, "
            "consensus_score, status, made_at, superseded_by FROM decisions "
            "WHERE project_id=? AND topic=? AND superseded_by IS NULL "
            "ORDER BY made_at DESC LIMIT 1",
            (project_id, topic),
        ).fetchone()
        return self._row_to_decision(row) if row else None

    def all_decisions(self, project_id: str) -> list[DecisionRecord]:
        rows = self._conn.execute(
            "SELECT decision_id, project_id, topic, chosen_value, alternatives, reasons, "
            "consensus_score, status, made_at, superseded_by FROM decisions "
            "WHERE project_id=? ORDER BY made_at",
            (project_id,),
        ).fetchall()
        return [self._row_to_decision(r) for r in rows]

    def supersede_decision(self, old_decision_id: str, new_decision_id: str) -> None:
        self._conn.execute(
            "UPDATE decisions SET superseded_by=? WHERE decision_id=?",
            (new_decision_id, old_decision_id),
        )
        self._conn.commit()

    @staticmethod
    def _row_to_decision(row) -> DecisionRecord:
        from datetime import datetime
        (decision_id, project_id, topic, chosen_value, alternatives, reasons,
         consensus_score, status, made_at, superseded_by) = row

        def _parse_list(raw: str) -> list[str]:
            if not raw:
                return []
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                # Backward compatibility with rows written by the old
                # "||"-joined format before this fix.
                return [p for p in raw.split("||") if p]

        return DecisionRecord(
            decision_id=decision_id, project_id=project_id, topic=topic,
            chosen_value=chosen_value,
            alternatives=_parse_list(alternatives),
            reasons=_parse_list(reasons),
            consensus_score=consensus_score, status=status,
            made_at=datetime.fromisoformat(made_at), superseded_by=superseded_by,
        )

    def close(self) -> None:
        self._conn.close()


# Extension point for future semantic search:
#   class EmbeddingIndex:
#       """Would sit beside MemoryStore, indexing entry.value on write
#       and exposing similarity_search(). Not needed for a single
#       project at a time, so deferred past v1.0 (see ROADMAP.md)."""
