"""
Connector Registry — fully local-only build. Turns a provider name
into a connector instance, with caching (the Ollama HTTP client is
cheap but pointless to recreate per call).

This build intentionally supports ONLY "ollama_local". There is no
Playwright/browser/web connector anywhere in this codebase — every
route in core/config.py points at Ollama, so there is nothing else to
register here. If you later want to add a web or API-key connector
back, this is the one place to register it.
"""

from __future__ import annotations

from orchestrator.connectors.base import BaseConnector
from orchestrator.connectors.ollama_connector import OllamaConnector

_cache: dict[str, BaseConnector] = {}


def get_connector(provider: str) -> BaseConnector:
    if provider in _cache:
        return _cache[provider]

    if provider == "ollama_local":
        connector: BaseConnector = OllamaConnector()
    else:
        raise ValueError(
            f"Unknown provider '{provider}'. This is a local-only build — "
            f"only 'ollama_local' is supported. Check config/orchestrator.yaml "
            f"for a stray non-local route."
        )

    _cache[provider] = connector
    return connector


async def close_all() -> None:
    for connector in _cache.values():
        close = getattr(connector, "close", None)
        if close:
            await close()
    _cache.clear()
