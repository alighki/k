"""
Ollama connector — local models (Qwen, Qwen-Coder, DeepSeek-R1,
DeepSeek-Coder, Llama, ...). Talks to Ollama's HTTP API directly;
no browser automation needed since Ollama exposes a normal REST API.

This connector is the one that will actually work out of the box in
most environments, since it has no login/session/anti-bot concerns —
which is why the design's Cost Optimization rule prefers local models
first (see core/config.py PolicySettings and workflow docs).
"""

from __future__ import annotations

import time

import httpx

from orchestrator.connectors.base import BaseConnector, ConnectorResult
from orchestrator.core.config import get_config
from orchestrator.core.exceptions import ConnectorError, ConnectorTimeoutError, ConnectorUnavailableError, MalformedResponseError
from orchestrator.core.logging_setup import get_logger

logger = get_logger(__name__)


class OllamaConnector(BaseConnector):
    provider_name = "ollama_local"

    def __init__(self, base_url: str | None = None) -> None:
        cfg = get_config()
        self.base_url = base_url or cfg.connectors.ollama_base_url

    async def send(self, prompt: str, *, model: str, timeout_seconds: int = 1200) -> ConnectorResult:
        started = time.monotonic()
        url = f"{self.base_url}/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            # Every agent is required to return the same JSON envelope.
            # Ollama's JSON mode materially reduces malformed/truncated
            # envelopes from small local models and keeps the deterministic
            # parser as the final authority.
            "format": "json",
        }
        cfg = get_config()
        if getattr(cfg.connectors, "max_output_tokens", 0):
            payload["options"] = {"num_predict": cfg.connectors.max_output_tokens, "temperature": 0.1}
        try:
            async with httpx.AsyncClient(timeout=timeout_seconds) as client:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
        except httpx.TimeoutException as exc:
            raise ConnectorTimeoutError(f"Ollama model '{model}' timed out after {timeout_seconds}s") from exc
        except httpx.ConnectError as exc:
            raise ConnectorUnavailableError(
                f"Could not reach Ollama at {self.base_url}. Is `ollama serve` running?"
            ) from exc
        except httpx.HTTPStatusError as exc:
            raise ConnectorUnavailableError(f"Ollama returned an error for model '{model}': {exc}") from exc
        except httpx.RequestError as exc:
            raise ConnectorUnavailableError(f"Ollama request failed for model '{model}': {exc}") from exc
        except ValueError as exc:
            raise MalformedResponseError(f"Ollama returned invalid JSON for model '{model}'") from exc

        response_text = data.get("response") if isinstance(data, dict) else None
        if not isinstance(response_text, str):
            raise MalformedResponseError(
                f"Ollama response for model '{model}' has no string 'response' field"
            )
        elapsed = time.monotonic() - started
        return ConnectorResult(
            raw_text=response_text, provider=self.provider_name,
            model=model, latency_seconds=elapsed,
        )

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.base_url}/api/tags")
                return resp.status_code == 200
        except httpx.HTTPError:
            return False

    async def list_installed_models(self) -> list[str]:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.base_url}/api/tags")
                resp.raise_for_status()
                return [m["name"] for m in resp.json().get("models", [])]
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            return []
