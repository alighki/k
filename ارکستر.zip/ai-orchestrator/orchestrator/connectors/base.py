"""
AI Connector Layer — base interface.

Local-only build: the only concrete implementation is OllamaConnector
(local model via Ollama). This interface exists so nothing above this
layer (agents, workflow) needs to know HOW a model is reached — that's
the whole point of the Connector abstraction from the design doc, and
it's what would let a web/API connector be added back later without
touching any other module.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ConnectorResult:
    raw_text: str
    provider: str
    model: str
    latency_seconds: float


class BaseConnector(ABC):
    provider_name: str

    @abstractmethod
    async def send(self, prompt: str, *, model: str, timeout_seconds: int = 1200) -> ConnectorResult:
        """Send `prompt` to the model and return its raw text response.
        Must raise ConnectorTimeoutError / ConnectorAuthError /
        ConnectorUnavailableError (see core/exceptions.py) on failure —
        callers rely on these specific types for retry/fallback logic."""
        raise NotImplementedError

    @abstractmethod
    async def health_check(self) -> bool:
        """Cheap check: is this connector reachable right now? Used by
        the AI Manager before routing a task, so a dead browser session
        or an unreachable Ollama daemon is caught before wasting a
        prompt-build cycle."""
        raise NotImplementedError
