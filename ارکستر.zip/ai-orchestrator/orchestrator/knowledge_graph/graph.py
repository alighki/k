"""
Knowledge Graph — tracks *relationships*, not just facts.

The design doc's own words: "it knows which decision affected which
file, which agent created or changed a file, what a task depends on,
and if a decision changes, what needs to be re-checked."

We implement this as a small, dependency-free directed graph stored
as edges in SQLite (reusing the same lightweight-storage philosophy as
memory/store.py — no need for a graph database at this scale: a single
project has hundreds, not millions, of nodes).

Node kinds: decision, file, task, agent_run, project.
Edge kinds: created, modified, depends_on, affected_by, produced.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from orchestrator.core.config import get_config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS kg_nodes (
    node_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    project_id TEXT NOT NULL,
    label TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS kg_edges (
    src TEXT NOT NULL,
    relation TEXT NOT NULL,
    dst TEXT NOT NULL,
    PRIMARY KEY (src, relation, dst)
);
CREATE INDEX IF NOT EXISTS idx_kg_edges_src ON kg_edges(src);
CREATE INDEX IF NOT EXISTS idx_kg_edges_dst ON kg_edges(dst);
"""


class KnowledgeGraph:
    def __init__(self, db_path: Path | None = None) -> None:
        cfg = get_config()
        self.db_path = db_path or (Path(cfg.data_dir) / "memory" / "knowledge_graph.sqlite3")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def add_node(self, node_id: str, kind: str, project_id: str, label: str) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO kg_nodes VALUES (?,?,?,?)",
            (node_id, kind, project_id, label),
        )
        self._conn.commit()

    def add_edge(self, src: str, relation: str, dst: str) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO kg_edges VALUES (?,?,?)", (src, relation, dst)
        )
        self._conn.commit()

    def _resolve_node_ids(self, node_id: str) -> list[str]:
        """Resolve a caller-supplied id to the actual namespaced node_id(s)
        it refers to. Callers (and older call sites) sometimes pass the raw
        label (e.g. 'task_1') instead of the namespaced id (e.g.
        'agent_run:task_1' / 'task:task_1'). If node_id is already a real
        node_id, use it as-is; otherwise fall back to matching by label,
        which may hit more than one node kind for the same label."""
        exists = self._conn.execute(
            "SELECT 1 FROM kg_nodes WHERE node_id=?", (node_id,)
        ).fetchone()
        if exists:
            return [node_id]
        rows = self._conn.execute(
            "SELECT node_id FROM kg_nodes WHERE label=?", (node_id,)
        ).fetchall()
        return [r[0] for r in rows] or [node_id]

    def neighbors(self, node_id: str, relation: str | None = None) -> list[str]:
        candidates = self._resolve_node_ids(node_id)
        placeholders = ",".join("?" for _ in candidates)
        if relation:
            rows = self._conn.execute(
                f"SELECT dst FROM kg_edges WHERE src IN ({placeholders}) AND relation=?",
                (*candidates, relation),
            ).fetchall()
        else:
            rows = self._conn.execute(
                f"SELECT dst FROM kg_edges WHERE src IN ({placeholders})", candidates
            ).fetchall()
        return [r[0] for r in rows]

    def what_depends_on(self, node_id: str) -> list[str]:
        """Reverse lookup: everything that points AT this node via
        'depends_on' or 'affected_by' — i.e. 'if this changes, what
        needs re-checking?' (design doc's core Knowledge Graph use case)."""
        rows = self._conn.execute(
            "SELECT src FROM kg_edges WHERE dst=? AND relation IN ('depends_on','affected_by')",
            (node_id,),
        ).fetchall()
        return [r[0] for r in rows]

    def impact_of_change(self, node_id: str) -> set[str]:
        """Transitive closure of everything that should be reviewed if
        `node_id` changes. Simple BFS — graphs here are small."""
        seen: set[str] = set()
        frontier = [node_id]
        while frontier:
            current = frontier.pop()
            for dependent in self.what_depends_on(current):
                if dependent not in seen:
                    seen.add(dependent)
                    frontier.append(dependent)
        return seen

    def record_task_file(self, task_id: str, project_id: str, file_path: str, agent_run_id: str | None = None) -> None:
        """Record both semantic relationships: task produced file, and the
        concrete agent run (when supplied) produced the same file."""
        task_node = f"task:{task_id}"
        file_node = f"file:{file_path}"
        self.add_node(task_node, "task", project_id, task_id)
        self.add_node(file_node, "file", project_id, file_path)
        self.add_edge(task_node, "produced", file_node)
        if agent_run_id:
            run_node = f"agent_run:{agent_run_id}"
            self.add_node(run_node, "agent_run", project_id, agent_run_id)
            self.add_edge(run_node, "produced", file_node)

    def record_file_creation(self, project_id: str, file_path: str, agent_run_id: str) -> None:
        """Backward-compatible wrapper; agent_run IDs are explicitly namespaced."""
        self.record_task_file(agent_run_id, project_id, file_path, agent_run_id=agent_run_id)

    def record_decision_effect(self, project_id: str, decision_id: str, file_path: str) -> None:
        decision_node = f"decision:{decision_id}"
        file_node = f"file:{file_path}"
        self.add_node(decision_node, "decision", project_id, decision_id)
        self.add_node(file_node, "file", project_id, file_path)
        self.add_edge(file_node, "depends_on", decision_node)

    def close(self) -> None:
        self._conn.close()
