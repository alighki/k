"""
Multi-Reviewer Consensus — the design doc, verbatim: "instead of one
Reviewer, have three. If two agree, accept."

This module runs the same review question past N independently-routed
Reviewer agents (see core/config.py routes: reviewer / reviewer_secondary
/ reviewer_tertiary — deliberately different models so they don't just
agree with themselves) IN PARALLEL, has each one emit an accept/reject
verdict via the structured Output Contract, and combines them by
majority vote.

This is a NEW capability, not present in the earlier single-Reviewer
version of _stage_review — kept as its own module so the workflow
engine can toggle it on/off via PolicySettings.use_multi_reviewer
without the review stage's control flow needing an if/else fork
scattered through it.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from orchestrator.agents.specialists import ReviewerAgent
from orchestrator.core.config import get_config
from orchestrator.core.logging_setup import get_logger
from orchestrator.memory.manager import MemoryManager
from orchestrator.prompt.output_contract import AgentResponse
from orchestrator.workflow.parallel import ParallelExecutor

logger = get_logger(__name__)

# Which config.routes keys act as independent reviewers. All must exist
# in OrchestratorConfig.routes (see core/config.py). If a route is
# missing/misconfigured for a given deployment, that reviewer's slot
# is skipped rather than crashing the whole review (see run() below).
REVIEWER_ROUTE_KEYS = ["reviewer", "reviewer_secondary", "reviewer_tertiary"]


@dataclass
class ReviewerVerdict:
    route_key: str
    accepted: bool | None       # None = reviewer unavailable (issue 101); not a reject
    numeric_score: float | None # None = no score available
    response: AgentResponse | None
    error: str | None = None


@dataclass
class MultiReviewerResult:
    verdicts: list[ReviewerVerdict] = field(default_factory=list)
    accept_count: int = 0
    total_count: int = 0
    agreement_ratio: float = 0.0
    passed: bool = False
    combined_reasoning: str = ""

    def summary_line(self) -> str:
        return (
            f"Multi-reviewer: {self.accept_count}/{self.total_count} accepted "
            f"({int(self.agreement_ratio * 100)}% agreement) -> "
            f"{'PASS' if self.passed else 'FAIL'}"
        )


class MultiReviewerConsensus:
    def __init__(self, memory: MemoryManager | None = None, parallel: ParallelExecutor | None = None) -> None:
        self.memory = memory or MemoryManager()
        self.parallel = parallel or ParallelExecutor()
        self.config = get_config()

    @staticmethod
    def _extract_score(response: AgentResponse) -> float:
        """Prefers the structured `decisions_proposed` verdict (topic=
        "review_score") the updated Reviewer prompt template asks for;
        falls back to regex-scanning `answer` for a number, then to
        `confidence`, for models that ignore the structured field."""
        for proposed in response.decisions_proposed:
            if proposed.topic == "review_score":
                try:
                    return min(100.0, max(0.0, float(proposed.value)))
                except ValueError:
                    pass

        return float(response.confidence)

    async def review(self, project_id: str, task_description: str, task_id: str) -> MultiReviewerResult:
        """Runs every configured reviewer route in parallel. A reviewer
        is scored "accept" if its self-reported confidence indicates it
        did not flag rejection-level problems — we ask each reviewer to
        report a numeric score (0-100) via the same convention the
        single-Reviewer path already used (first number in `answer`),
        and treat >=60 (QualityBand.WEAK_PASS floor) as an accept vote."""
        route_keys = [
            key for key in REVIEWER_ROUTE_KEYS
            if key in self.config.routes
        ]
        if not route_keys:
            route_keys = ["reviewer"]  # always-present fallback

        async def run_one(route_key: str) -> ReviewerVerdict:
            agent = ReviewerAgent(memory=self.memory, route_key_override=(
                None if route_key == "reviewer" else route_key
            ))
            try:
                response = await agent.run(project_id, task_description=task_description, task_id=task_id)
            except Exception as exc:  # noqa: BLE001
                # Issue 101: unavailable reviewer is NOT a reject vote (accepted=None)
                logger.warning("Reviewer route '%s' unavailable: %s", route_key, exc)
                return ReviewerVerdict(route_key=route_key, accepted=None, numeric_score=None,
                                        response=None, error=str(exc))

            numeric_score = self._extract_score(response)
            accepted = numeric_score >= self.config.quality_thresholds.weak_pass
            return ReviewerVerdict(route_key=route_key, accepted=accepted, numeric_score=numeric_score,
                                    response=response)

        coro_fns = [(lambda k=k: run_one(k)) for k in route_keys]
        results = await self.parallel.run_all(coro_fns)

        verdicts = [outcome for success, outcome in results if success]
        # ParallelExecutor already catches exceptions inside run_one, so
        # `success` should always be True here; this guards belt-and-braces
        # against a future change that removes that inner try/except.
        for success, outcome in results:
            if not success:
                logger.error("Unexpected uncaught exception in reviewer run: %s", outcome)

        # Issue 101: count only valid votes (accepted is not None)
        valid_verdicts = [v for v in verdicts if v.accepted is not None]
        unavailable_count = len(verdicts) - len(valid_verdicts)
        accept_count = sum(1 for v in valid_verdicts if v.accepted)
        reject_count = sum(1 for v in valid_verdicts if not v.accepted)
        total_count = len(verdicts)
        valid_count = len(valid_verdicts)
        agreement_ratio = (accept_count / valid_count) if valid_count else 0.0

        # Issue 103: average score computed independently from majority verdict
        scored = [v.numeric_score for v in valid_verdicts if v.numeric_score is not None]
        average_score = sum(scored) / len(scored) if scored else None

        # Issue 16/102: 2-of-3 with absolute counts; unavailable ≠ reject
        policy = self.config.policy
        required_accepts = getattr(policy, "reviewer_required_accepts", 2)
        minimum_panel = getattr(policy, "reviewer_minimum_panel", 3)

        if valid_count < minimum_panel:
            logger.warning(
                "Multi-reviewer panel has only %d valid votes (required %d); "
                "unavailable: %d — consensus unavailable, treating as FAIL.",
                valid_count, minimum_panel, unavailable_count,
            )
            passed = False
        else:
            passed = accept_count >= required_accepts

        combined_reasoning = "\n".join(
            f"[{v.route_key}] {'ACCEPT' if v.accepted else 'REJECT'} "
            f"(score={v.numeric_score:.0f}): "
            f"{(v.response.answer[:300] if v.response else v.error or 'no response')}"
            for v in verdicts
        )

        result = MultiReviewerResult(
            verdicts=verdicts, accept_count=accept_count, total_count=total_count,
            agreement_ratio=round(agreement_ratio, 2), passed=passed,
            combined_reasoning=combined_reasoning,
        )
        logger.info(result.summary_line())
        return result
