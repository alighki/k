"""
test_runner.py — Quality gate: dependency install → syntax/import check → pytest.

Public API (matches engine.py and __init__.py expectations):
  - FailureKind      : Enum of failure types
  - TestRunResult    : Result dataclass
  - TestRunner       : Class with .run() / .run_targeted()
  - run_full_test()  : convenience function
  - run_targeted_test(): convenience function

Key design decisions (fixes applied):
  1. pip install failure is FATAL — returns DEPENDENCY_INSTALL_ERROR immediately.
  2. requirements.txt is parsed with packaging.requirements (real parser), not regex.
  3. Each project gets its own venv so packages don't bleed into the orchestrator env.
  4. Workspace with zero Python files when Python output was expected → FAIL not PASS.
  5. ModuleNotFoundError vs ImportError vs dependency failure are classified separately
     so the debug loop routes to the right repair strategy.
  6. Import check is done via py_compile (syntax) + controlled subprocess import check,
     never bare `import module` which can trigger side effects.
"""
from __future__ import annotations

import logging
import os
import re
import subprocess
import sys
import tempfile
import venv
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Failure Kind Enum
# ---------------------------------------------------------------------------
class FailureKind(str, Enum):
    NONE = "None"
    DEPENDENCY_INSTALL_ERROR = "DependencyInstallError"
    SYNTAX_ERROR = "SyntaxError"
    MODULE_NOT_FOUND = "ModuleNotFoundError"
    IMPORT_ERROR = "ImportError"
    TEST_FAILURE = "TestFailure"
    TEST_TIMEOUT = "TestTimeout"
    STRUCTURAL_FAILURE = "StructuralFailure"    # e.g. expected Python files missing
    UNKNOWN = "Unknown"


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------
@dataclass
class TestRunResult:
    """
    Result of a test-runner quality gate.

    Issues 56-67: added import_ok, tests_ok, exit_code, failing_tests,
    failing_files, test_command, stage for machine-readable routing.
    Issue 58: NO_TESTS distinct from RUNNER_FAILED.
    Issue 59: NOT_EXECUTED explicit.
    """
    passed: bool = True
    summary: str = ""
    failure_kind: FailureKind = FailureKind.NONE
    failure_reason: str = ""
    stderr: str = ""
    # Issue 56/57: independent stage results
    syntax_ok: bool | None = None       # None = not yet checked
    import_ok: bool | None = None       # None = not yet checked
    tests_ok: bool | None = None        # None = not executed / no tests
    pytest: bool | None = None          # backward compat alias for tests_ok
    details: str = ""
    is_dependency_failure: bool = False
    # Issue 60/65/67: machine-readable fields
    stage: str = ""                     # which gate produced this result
    test_command: str = ""              # exact command run (issue 65)
    exit_code: int | None = None        # subprocess exit code (issue 67)
    # Issue 62/63/64: structured failure location
    failing_tests: list[str] = None     # type: ignore[assignment]
    failing_files: list[str] = None     # type: ignore[assignment]
    failing_line: int | None = None

    def __post_init__(self):
        if self.failing_tests is None:
            self.failing_tests = []
        if self.failing_files is None:
            self.failing_files = []
        if not self.summary:
            self.summary = (
                "All quality checks passed."
                if self.passed
                else f"Failed ({self.failure_kind.value}): {self.failure_reason}"
            )
        if not self.details:
            self.details = self.stderr or self.summary
        # Derive syntax_ok from failure_kind if not explicitly set
        if self.syntax_ok is None:
            self.syntax_ok = self.failure_kind not in (
                FailureKind.SYNTAX_ERROR,
                FailureKind.MODULE_NOT_FOUND,
                FailureKind.IMPORT_ERROR,
                FailureKind.DEPENDENCY_INSTALL_ERROR,
            ) if self.failure_kind != FailureKind.NONE else self.passed
        # Sync pytest alias
        if self.pytest is None and self.tests_ok is not None:
            self.pytest = self.tests_ok
        elif self.tests_ok is None and self.pytest is not None:
            self.tests_ok = self.pytest
        self.is_dependency_failure = (
            self.failure_kind == FailureKind.DEPENDENCY_INSTALL_ERROR
        )

    @property
    def syntax_error(self) -> bool:
        return self.syntax_ok is False

    def __str__(self) -> str:
        return (
            f"TestRunResult(passed={self.passed}, "
            f"failure_kind={self.failure_kind.value!r}, "
            f"failure_reason={self.failure_reason!r}, "
            f"failing_files={self.failing_files!r})"
        )


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------
class TestRunner:
    def __init__(
        self,
        workspace: str | Path | None = None,
        timeout_seconds: int | None = None,
    ) -> None:
        self.workspace = Path(workspace) if workspace is not None else None
        # timeout_seconds governs the import check and each subprocess call.
        # Pytest gets 5x this value as its budget (tests can be slow).
        self._import_timeout: int = timeout_seconds if timeout_seconds is not None else 30
        self._pytest_timeout: int = max(60, (timeout_seconds or 60) * 5)

    def _resolve(self, workspace: str | Path | None) -> Path:
        ws = workspace if workspace is not None else self.workspace
        if ws is None:
            raise ValueError(
                "TestRunner: workspace must be supplied either at construction "
                "or as an argument to run() / run_targeted()."
            )
        return Path(ws)

    def run(
        self,
        workspace: str | Path | None = None,
    ) -> tuple[TestRunResult, TestRunResult | None]:
        _local.runner = self
        try:
            return run_full_test(self._resolve(workspace))
        finally:
            _local.runner = None

    def run_targeted(
        self,
        arg1: str | Path | list[str | Path],
        arg2: list[str | Path] | str | Path | None = None,
        workspace: str | Path | None = None,
        task_files: list[str | Path] | None = None,
    ) -> tuple[TestRunResult, None]:
        ws: Path | None = None
        files: list[Path] = []

        if isinstance(arg1, (str, Path)) and not isinstance(arg2, (str, Path)) and arg2 is not None:
            ws = Path(arg1)
            files = [Path(f) for f in arg2]
        elif isinstance(arg1, list):
            files = [Path(f) for f in arg1]
            if isinstance(arg2, (str, Path)):
                ws = Path(arg2)
        elif workspace is not None:
            ws = Path(workspace)
            if task_files:
                files = [Path(f) for f in task_files]
        elif self.workspace is not None:
            ws = self.workspace
            if isinstance(arg1, list):
                files = [Path(f) for f in arg1]

        target_ws = self._resolve(ws)
        return run_targeted_test(target_ws, files)

    def run_for_task(
        self,
        task_files: list[str | Path],
        workspace: str | Path | None = None,
    ) -> tuple[TestRunResult, None]:
        return self.run_targeted(self._resolve(workspace), task_files)


# ---------------------------------------------------------------------------
# Dependency parsing — uses packaging library if available, else safe fallback
# ---------------------------------------------------------------------------
def _parse_requirements(req_path: Path) -> list[str]:
    """
    Parse requirements.txt into a list of valid, normalized pip requirement strings.
    Each line is individually validated. Lines with multiple comma-separated
    packages are split and each is validated separately.
    Returns only valid requirement strings (invalid ones are logged and dropped).
    """
    _STDLIB = {
        "os", "sys", "json", "re", "math", "time", "datetime", "pathlib",
        "typing", "collections", "itertools", "functools", "io", "copy",
        "hashlib", "uuid", "logging", "threading", "multiprocessing",
        "subprocess", "shutil", "tempfile", "glob", "fnmatch", "struct",
        "socket", "http", "urllib", "email", "html", "xml", "csv",
        "sqlite3", "pickle", "shelve", "gzip", "zipfile", "tarfile",
        "base64", "binascii", "hmac", "secrets", "random", "statistics",
        "decimal", "fractions", "enum", "dataclasses", "abc", "contextlib",
        "warnings", "traceback", "inspect", "ast", "dis", "gc",
        "platform", "signal", "errno", "ctypes",
    }
    _NON_PIP = {
        "tailwindcss", "nodejs", "node", "npm", "yarn", "webpack",
        "babel", "eslint", "prettier", "jest", "mocha",
    }
    # A valid pip specifier name — letters, digits, hyphens, underscores, dots
    _VALID_PKG_NAME = re.compile(r'^[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?$')

    valid: list[str] = []
    invalid_count = 0

    try:
        raw_text = req_path.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        logger.warning("Could not read requirements.txt: %s", exc)
        return []

    for raw_line in raw_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue

        # Split on commas — LLMs sometimes write "flask>=2.3, fastapi>=0.110"
        candidates = [c.strip() for c in line.split(",") if c.strip()]

        for candidate in candidates:
            # Strip inline comments
            candidate = candidate.split("#")[0].strip()
            if not candidate:
                continue

            # Extract package name (before version specifier)
            pkg_name = re.split(r'[\[>=<!;@\s]', candidate)[0].strip().lower()

            if not pkg_name:
                logger.warning("Skipping empty requirement entry from line: %r", raw_line)
                invalid_count += 1
                continue

            if not _VALID_PKG_NAME.match(pkg_name):
                logger.warning("Skipping malformed package name %r (from line: %r)", pkg_name, raw_line)
                invalid_count += 1
                continue

            if pkg_name in _STDLIB:
                logger.warning("Skipping stdlib module %r in requirements.txt", pkg_name)
                continue

            if pkg_name in _NON_PIP:
                logger.warning("Skipping non-pip package %r in requirements.txt", pkg_name)
                continue

            valid.append(candidate)

    if invalid_count > 0:
        logger.warning(
            "requirements.txt contained %d invalid/malformed entries that were skipped.",
            invalid_count,
        )

    return valid


# ---------------------------------------------------------------------------
# Per-project venv management
# ---------------------------------------------------------------------------
def _get_venv_python(workspace: Path) -> str:
    """
    Create (or reuse) a per-project venv inside workspace/.orchestrator/venv.
    Returns the path to the venv's Python executable.
    """
    venv_dir = workspace / ".orchestrator" / "venv"
    if sys.platform == "win32":
        venv_python = venv_dir / "Scripts" / "python.exe"
    else:
        venv_python = venv_dir / "bin" / "python"

    if not venv_python.exists():
        logger.debug("Creating project venv at %s", venv_dir)
        try:
            venv.create(str(venv_dir), with_pip=True, clear=False)
        except Exception as exc:
            logger.warning("Could not create project venv: %s; falling back to sys.executable", exc)
            return sys.executable

    return str(venv_python)


# ---------------------------------------------------------------------------
# Dependency installation — FATAL on failure
# ---------------------------------------------------------------------------
def _pip_install_workspace(workspace: Path, venv_python: str) -> TestRunResult | None:
    """
    Install requirements.txt into the project venv.

    Returns None on success (or when there are no requirements).
    Returns a FAILED TestRunResult (with failure_kind=DEPENDENCY_INSTALL_ERROR)
    on pip failure — callers MUST propagate this as fatal.
    """
    req = workspace / "requirements.txt"
    pyproject = workspace / "pyproject.toml"

    # Prefer pyproject.toml (source of truth)
    if pyproject.exists() and not req.exists():
        result = subprocess.run(
            [venv_python, "-m", "pip", "install", "-q", "-e", str(workspace)],
            cwd=workspace,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            msg = result.stderr or result.stdout
            logger.error("pip install -e . (pyproject) FAILED: %s", msg[:600])
            return TestRunResult(
                passed=False,
                summary=f"Dependency installation failed (pyproject.toml): {msg[:300]}",
                failure_kind=FailureKind.DEPENDENCY_INSTALL_ERROR,
                failure_reason="pip install -e . failed",
                stderr=msg,
                is_dependency_failure=True,
            )
        logger.debug("pip install -e . (pyproject) succeeded.")
        return None

    if not req.exists():
        return None

    valid_reqs = _parse_requirements(req)
    if not valid_reqs:
        logger.debug("requirements.txt had no valid entries after parsing.")
        return None

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as tmp:
        tmp.write("\n".join(valid_reqs) + "\n")
        tmp_name = tmp.name

    try:
        result = subprocess.run(
            [venv_python, "-m", "pip", "install", "-q", "-r", tmp_name],
            cwd=workspace,
            capture_output=True,
            text=True,
        )
    except Exception as exc:
        logger.error("Could not run pip install: %s", exc)
        return TestRunResult(
            passed=False,
            summary=f"pip install subprocess failed: {exc}",
            failure_kind=FailureKind.DEPENDENCY_INSTALL_ERROR,
            failure_reason=f"pip subprocess error: {exc}",
            stderr=str(exc),
            is_dependency_failure=True,
        )
    finally:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass

    if result.returncode != 0:
        msg = result.stderr or result.stdout
        logger.error(
            "pip install -r requirements.txt FAILED (FATAL). "
            "This is a dependency environment failure, not a code failure.\n%s",
            msg[:800],
        )
        return TestRunResult(
            passed=False,
            summary=f"Dependency installation failed. This must be fixed before code can be tested.\n{msg[:400]}",
            failure_kind=FailureKind.DEPENDENCY_INSTALL_ERROR,
            failure_reason="pip install -r requirements.txt failed",
            stderr=msg,
            is_dependency_failure=True,
        )

    logger.debug("pip install succeeded (%d packages).", len(valid_reqs))
    return None


# ---------------------------------------------------------------------------
# Conftest
# ---------------------------------------------------------------------------
def _ensure_conftest(workspace: Path) -> None:
    conftest = workspace / "conftest.py"
    if conftest.exists():
        return
    conftest_code = (
        '"""conftest.py — auto-generated by orchestrator test_runner.\n'
        'Adds the project root to sys.path.\n'
        '"""\n'
        "import sys, os\n"
        "sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\n"
    )
    try:
        conftest.write_text(conftest_code, encoding="utf-8")
        logger.debug("Created conftest.py in %s", workspace)
    except Exception as exc:
        logger.warning("Could not write conftest.py: %s", exc)


# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------
def _collect_python_files(
    workspace: Path, task_files: list[Path] | None = None
) -> list[Path]:
    if task_files:
        return [f for f in task_files if f.suffix == ".py" and f.exists()]
    return [
        p for p in workspace.rglob("*.py")
        if ".git" not in p.parts
        and "__pycache__" not in p.parts
        and ".orchestrator" not in p.parts
    ]


def _workspace_has_python_intent(workspace: Path) -> bool:
    """
    Heuristic: does this workspace look like it was supposed to produce Python?
    True if pyproject.toml, requirements.txt, or setup.py exist.
    """
    return any(
        (workspace / f).exists()
        for f in ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg")
    )


# ---------------------------------------------------------------------------
# Syntax + import check (using venv python, safe subprocess only)
# ---------------------------------------------------------------------------
def _syntax_and_import_check(
    py_files: list[Path], workspace: Path, venv_python: str,
    import_timeout: int = 30,
) -> tuple[bool, FailureKind, str, str]:
    """Returns (ok, failure_kind, failure_reason, stderr)."""
    env = os.environ.copy()
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(workspace) + (os.pathsep + existing_pp if existing_pp else "")

    for py_file in py_files:
        # 1. Syntax check via py_compile (no side effects)
        result = subprocess.run(
            [venv_python, "-m", "py_compile", str(py_file)],
            capture_output=True, text=True, env=env,
        )
        if result.returncode != 0:
            err = result.stderr or result.stdout
            logger.debug("SyntaxError in %s: %s", py_file, err[:600])
            return False, FailureKind.SYNTAX_ERROR, f"SyntaxError in {py_file.name}", err

        # 2. Import check via temp-file subprocess (PROBLEM 24: no side-effect bare import)
        import tempfile as _tmpfile
        try:
            rel = py_file.relative_to(workspace)
            module_str = str(rel).replace(os.sep, ".").removesuffix(".py")
            # Write to a temp file to avoid quoting bugs and 'self' NameError
            # that occurred with python -c "...f-string with single-quotes..."
            import_script = (
                "import sys, importlib\n"
                "sys.path.insert(0, '.')\n"
                f"importlib.import_module({module_str!r})\n"
            )
            with _tmpfile.NamedTemporaryFile(
                mode="w", suffix=".py", delete=False, encoding="utf-8", dir=None
            ) as _tf:
                _tf.write(import_script)
                _tf_name = _tf.name
            try:
                result2 = subprocess.run(
                    [venv_python, _tf_name],
                    capture_output=True, text=True, cwd=workspace, env=env,
                    timeout=import_timeout,
                )
            finally:
                try:
                    os.unlink(_tf_name)
                except OSError:
                    pass
            if result2.returncode != 0:
                err2 = result2.stderr or result2.stdout
                # Classify: dependency missing vs local module missing
                if "ModuleNotFoundError" in err2 or "No module named" in err2:
                    missing_match = re.search(r"No module named '([^']+)'", err2)
                    if missing_match:
                        missing_mod = missing_match.group(1).split(".")[0]
                        if _is_third_party_dependency(missing_mod, workspace):
                            logger.debug(
                                "ModuleNotFoundError for third-party package %r in %s — "
                                "dependency install likely failed.",
                                missing_mod, py_file,
                            )
                            return (
                                False,
                                FailureKind.DEPENDENCY_INSTALL_ERROR,
                                f"Missing third-party package '{missing_mod}' — dependency not installed",
                                err2,
                            )
                    logger.debug("ModuleNotFoundError in %s: %s", py_file, err2[:600])
                    return False, FailureKind.MODULE_NOT_FOUND, f"ModuleNotFoundError in {py_file.name}", err2
                logger.debug("ImportError in %s: %s", py_file, err2[:600])
                return False, FailureKind.IMPORT_ERROR, f"ImportError in {py_file.name}", err2
        except subprocess.TimeoutExpired:
            logger.warning("Import check timed out for %s — possible side effect at import time", py_file)
        except Exception as exc:
            # Log and continue — one file's import check error should not
            # block the entire project. The file already passed py_compile,
            # so syntax is OK. A runtime import error will surface in pytest.
            logger.debug("Import check error for %s: %s", py_file, exc)

    return True, FailureKind.NONE, "", ""


def _is_third_party_dependency(module_name: str, workspace: Path) -> bool:
    """
    Returns True if module_name appears to be a declared third-party dependency
    (i.e., it is listed in requirements.txt or pyproject.toml), meaning a
    ModuleNotFoundError is a dependency environment problem, not a code problem.
    """
    req = workspace / "requirements.txt"
    pyproject = workspace / "pyproject.toml"

    name_lower = module_name.lower().replace("-", "_")

    if req.exists():
        try:
            text = req.read_text(encoding="utf-8", errors="ignore").lower()
            if name_lower in text or module_name.lower() in text:
                return True
        except Exception:
            pass

    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="ignore").lower()
            if name_lower in text or module_name.lower() in text:
                return True
        except Exception:
            pass

    # Common third-party packages not always in requirements
    _KNOWN_THIRD_PARTY = {
        "flask", "fastapi", "django", "sqlalchemy", "pydantic", "uvicorn",
        "starlette", "requests", "httpx", "aiohttp", "celery", "redis",
        "pymongo", "psycopg2", "alembic", "pytest", "click", "typer",
        "pandas", "numpy", "scipy", "sklearn", "tensorflow", "torch",
        "PIL", "pillow", "boto3", "paramiko", "cryptography", "jwt",
    }
    return name_lower in {p.lower() for p in _KNOWN_THIRD_PARTY}


# ---------------------------------------------------------------------------
# Pytest runner (uses venv python)
# ---------------------------------------------------------------------------
def _run_pytest(
    workspace: Path, venv_python: str, pytest_timeout: int = 300
) -> tuple[bool | None, str, FailureKind]:
    """Returns (passed, output, failure_kind).
    passed=None means no tests found (not a failure).
    failure_kind=TEST_TIMEOUT is set on timeout — distinct from TEST_FAILURE.
    """
    # Ensure pytest is available in the venv
    check = subprocess.run(
        [venv_python, "-m", "pytest", "--version"],
        capture_output=True, text=True,
    )
    if check.returncode != 0:
        subprocess.run(
            [venv_python, "-m", "pip", "install", "-q", "pytest"],
            capture_output=True, text=True,
        )

    try:
        cmd = [venv_python, "-m", "pytest", "--tb=short", "-q", str(workspace)]
        result = subprocess.run(
            cmd, capture_output=True, text=True, cwd=workspace,
            timeout=pytest_timeout,
        )
        output = result.stdout + result.stderr
        if (
            "no tests ran" in output
            or "collected 0 items" in output
            or "No module named pytest" in output
            or "ModuleNotFoundError: No module named 'pytest'" in output
        ):
            return None, "no tests", FailureKind.NONE, result.returncode, " ".join(cmd)
        ok = result.returncode == 0
        return ok, output, FailureKind.NONE if ok else FailureKind.TEST_FAILURE, result.returncode, " ".join(cmd)
    except subprocess.TimeoutExpired:
        msg = f"pytest timed out after {pytest_timeout}s — possible infinite loop in tests."
        logger.warning(msg)
        return False, msg, FailureKind.TEST_TIMEOUT, -1, ""
    except Exception as exc:
        return None, str(exc), FailureKind.NONE, None, ""


# ---------------------------------------------------------------------------
# Internal helper: access caller TestRunner instance for timeout settings
# ---------------------------------------------------------------------------
import threading as _threading
_local = _threading.local()

def _caller_runner():
    return getattr(_local, "runner", None)


# ---------------------------------------------------------------------------
# Stack trace parser (issues 61-64)
# ---------------------------------------------------------------------------
def _parse_pytest_output(output: str) -> tuple[list[str], list[str], int | None]:
    """Extract (failing_tests, failing_files, first_line_number) from pytest stdout."""
    import re
    failing_tests: list[str] = []
    failing_files: list[str] = []
    first_line: int | None = None

    # FAILED tests/test_foo.py::TestClass::test_method
    for m in re.finditer(r'^FAILED\s+([^\s]+)', output, re.MULTILINE):
        test_id = m.group(1)
        failing_tests.append(test_id)
        # Extract file part before ::
        file_part = test_id.split("::")[0]
        if file_part not in failing_files:
            failing_files.append(file_part)

    # File "foo.py", line N
    for m in re.finditer(r'File "([^"]+\.py)", line (\d+)', output):
        path = m.group(1).lstrip("./")
        line = int(m.group(2))
        if path not in failing_files:
            failing_files.append(path)
        if first_line is None:
            first_line = line

    # ERROR collecting tests/test_foo.py
    for m in re.finditer(r'^ERROR collecting\s+([^\s]+)', output, re.MULTILINE):
        f = m.group(1)
        if f not in failing_files:
            failing_files.append(f)

    return failing_tests, failing_files, first_line


# Issue 70: environment fingerprint for install cache
def _requirements_fingerprint(workspace: Path) -> str:
    """Hash the requirements manifest to detect changes (issue 70)."""
    import hashlib
    parts = []
    for name in ("requirements.txt", "pyproject.toml", "setup.py"):
        p = workspace / name
        if p.exists():
            parts.append(p.read_bytes())
    return hashlib.sha256(b"".join(parts)).hexdigest()[:16] if parts else ""


def _env_is_fresh(workspace: Path, venv_python: str) -> bool:
    """Issue 70: True if installed packages match current requirements."""
    stamp_file = workspace / ".orchestrator" / "env_fingerprint"
    current = _requirements_fingerprint(workspace)
    if not current:
        return True  # no manifest = nothing to install = always fresh
    try:
        stored = stamp_file.read_text(encoding="utf-8").strip()
        return stored == current
    except OSError:
        return False


def _mark_env_fresh(workspace: Path) -> None:
    stamp_file = workspace / ".orchestrator" / "env_fingerprint"
    stamp_file.parent.mkdir(parents=True, exist_ok=True)
    stamp_file.write_text(_requirements_fingerprint(workspace), encoding="utf-8")


# ---------------------------------------------------------------------------
# Public convenience functions
# ---------------------------------------------------------------------------
def run_full_test(workspace: str | Path) -> tuple[TestRunResult, TestRunResult | None]:
    """
    Full quality gate: install deps → conftest → syntax/import → pytest.

    IMPORTANT: pip failure is FATAL and returns immediately without running
    any code checks. A dependency environment failure is NOT a code failure
    and must be routed to dependency repair, not code debug.
    """
    workspace = Path(workspace)
    venv_python = _get_venv_python(workspace)

    # ── STEP 1: Install dependencies (FATAL on failure) ──────────────────
    # Issue 70: skip re-install if requirements haven't changed
    if not _env_is_fresh(workspace, venv_python):
        dep_failure = _pip_install_workspace(workspace, venv_python)
        if dep_failure is not None:
            logger.error(
                "FATAL: Dependency installation failed for %s.", workspace,
            )
            return dep_failure, None
        _mark_env_fresh(workspace)
    else:
        dep_failure = None
    if dep_failure is not None:
        logger.error(
            "FATAL: Dependency installation failed for %s. "
            "Aborting quality gate — code cannot be tested until "
            "dependencies are correctly installed.",
            workspace,
        )
        return dep_failure, None

    _ensure_conftest(workspace)

    # ── STEP 2: Collect Python files ─────────────────────────────────────
    py_files = _collect_python_files(workspace)
    if not py_files:
        # If the project declares Python intent (pyproject, requirements),
        # zero .py files is a failure, not a pass.
        if _workspace_has_python_intent(workspace):
            logger.warning(
                "No Python files found in %s, but project has Python intent (requirements/pyproject). "
                "Treating as failure — coding likely did not produce expected files.",
                workspace,
            )
            return TestRunResult(
                passed=False,
                summary="No Python files produced despite Python project intent.",
                failure_kind=FailureKind.UNKNOWN,
                failure_reason="Expected Python files not found in workspace",
                stderr="",
            ), None
        logger.debug("No Python files found in %s and no Python intent — skipping.", workspace)
        return TestRunResult(
            passed=True,
            summary="No Python files found (non-Python project).",
            failure_kind=FailureKind.NONE,
        ), None

    # ── STEP 3: Syntax + import check ────────────────────────────────────
    runner_obj = _caller_runner()
    _import_timeout = getattr(runner_obj, "_import_timeout", 30) if runner_obj else 30
    syntax_ok, failure_kind, failure_reason, stderr = _syntax_and_import_check(
        py_files, workspace, venv_python, import_timeout=_import_timeout
    )
    if not syntax_ok:
        logger.warning("Syntax/import check failed (%s).", failure_kind.value)
        return TestRunResult(
            passed=False,
            summary=f"Syntax/Import check failed ({failure_kind.value}): {failure_reason}",
            failure_kind=failure_kind,
            failure_reason=failure_reason,
            stderr=stderr,
            syntax_ok=False,
            is_dependency_failure=(failure_kind == FailureKind.DEPENDENCY_INSTALL_ERROR),
        ), None

    syntax_res = TestRunResult(
        passed=True,
        summary="All syntax and import checks passed.",
        failure_kind=FailureKind.NONE,
    )

    # ── STEP 4: pytest ───────────────────────────────────────────────────
    runner_obj = _caller_runner()
    pt = getattr(runner_obj, "_pytest_timeout", 300) if runner_obj else 300
    pytest_passed, pytest_details, pytest_fk, pytest_exit, pytest_cmd = _run_pytest(workspace, venv_python, pt)
    if pytest_passed is None:
        return syntax_res, None

    if not pytest_passed:
        failing_tests, failing_files, fail_line = _parse_pytest_output(pytest_details)
        return syntax_res, TestRunResult(
            passed=False,
            summary=f"pytest failed ({pytest_fk.value}):\n{pytest_details[:400]}",
            failure_kind=pytest_fk,
            failure_reason=pytest_fk.value,
            stderr=pytest_details,
            syntax_ok=True,
            tests_ok=False,
            pytest=False,
            stage="pytest",
            test_command=pytest_cmd,
            exit_code=pytest_exit,
            failing_tests=failing_tests,
            failing_files=failing_files,
            failing_line=fail_line,
        )

    return syntax_res, TestRunResult(
        passed=True,
        summary="pytest passed.",
        failure_kind=FailureKind.NONE,
        syntax_ok=True,
        import_ok=True,
        tests_ok=True,
        pytest=True,
        stage="pytest",
        test_command=pytest_cmd,
        exit_code=pytest_exit,
        details=pytest_details,
    )


def run_targeted_test(
    workspace: str | Path,
    task_files: list[str | Path],
) -> tuple[TestRunResult, None]:
    """
    Targeted gate — only checks files changed by one task.
    DEPENDENCY_INSTALL_ERROR is propagated as fatal here too.
    """
    workspace = Path(workspace)
    venv_python = _get_venv_python(workspace)

    dep_failure = _pip_install_workspace(workspace, venv_python)
    if dep_failure is not None:
        return dep_failure, None

    _ensure_conftest(workspace)

    paths = [Path(f) for f in task_files]
    py_files = _collect_python_files(workspace, paths)
    if not py_files:
        # For targeted checks, zero Python files means either no .py task
        # (acceptable for non-Python tasks) or the files weren't produced.
        # We trust the engine to verify file production separately.
        return TestRunResult(
            passed=True,
            summary="No Python files to check for this task.",
            failure_kind=FailureKind.NONE,
        ), None

    runner_obj = _caller_runner()
    _import_timeout = getattr(runner_obj, "_import_timeout", 30) if runner_obj else 30
    syntax_ok, failure_kind, failure_reason, stderr = _syntax_and_import_check(
        py_files, workspace, venv_python, import_timeout=_import_timeout
    )
    if not syntax_ok:
        logger.warning(
            "Targeted gate: syntax/import failed (%s).", failure_kind.value
        )
        return TestRunResult(
            passed=False,
            summary=f"Targeted check failed ({failure_kind.value}): {failure_reason}",
            failure_kind=failure_kind,
            failure_reason=failure_reason,
            stderr=stderr,
            syntax_ok=False,
            is_dependency_failure=(failure_kind == FailureKind.DEPENDENCY_INSTALL_ERROR),
        ), None

    return TestRunResult(
        passed=True,
        summary="Targeted syntax and import checks passed.",
        failure_kind=FailureKind.NONE,
    ), None
