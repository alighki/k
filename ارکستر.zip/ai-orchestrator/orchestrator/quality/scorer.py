"""
QualityScorer — combines a deterministic structural check with agent
opinions (Reviewer, test results, consistency-with-decisions) into one
explainable score per the design doc's weighting scheme.

Structural checks are intentionally rule-based (no AI call) for the
same reason PromptReviewer is rule-based: fast, free, and catches the
most common failures (syntax errors, missing files, empty content)
without waiting on a model.
"""

from __future__ import annotations

import ast

from orchestrator.quality.models import QualityComponent, QualityScore


class QualityScorer:
    def __init__(self, thresholds=None) -> None:
        from orchestrator.core.config import get_config
        self.thresholds = thresholds or get_config().quality_thresholds

    # ---- structural checks -------------------------------------------------

    def _structural_check_code(self, file_path: str, content: str) -> QualityComponent:
        issues = []
        score = 100.0

        if not content.strip():
            return QualityComponent(name="structural", weight=0.4, score=0.0,
                                     explanation="File is empty.")

        if file_path.endswith(".py"):
            try:
                ast.parse(content)
            except SyntaxError as exc:
                issues.append(f"SyntaxError: {exc}")
                score -= 100

        if "TODO: implement" in content or "raise NotImplementedError" in content:
            issues.append("Contains unimplemented placeholders.")
            score -= 20

        if len(content.splitlines()) < 2:
            issues.append("Suspiciously short for a source file.")
            score -= 10

        score = max(0.0, score)
        explanation = "No structural issues found." if not issues else "; ".join(issues)
        return QualityComponent(name="structural", weight=0.4, score=score, explanation=explanation)

    def _structural_check_generic(self, content: str) -> QualityComponent:
        score = 100.0
        issues = []
        if not content.strip():
            score = 0.0
            issues.append("Content is empty.")
        elif len(content.strip()) < 20:
            score -= 30
            issues.append("Content looks too short to be complete.")
        return QualityComponent(name="structural", weight=0.4, score=max(0.0, score),
                                 explanation="; ".join(issues) or "OK")

    # ---- scoring entry points -----------------------------------------------

    def score_file(self, project_id: str, file_path: str, content: str,
                    reviewer_score: float | None = None,
                    test_passed: bool | None = None,
                    consistency_score: float | None = None) -> QualityScore:
        reviewer_score = self._clamp(reviewer_score)
        consistency_score = self._clamp(consistency_score)
        components = [self._structural_check_code(file_path, content)]
        components.append(QualityComponent(
            name="reviewer", weight=0.3, score=reviewer_score if reviewer_score is not None else 70.0,
            explanation="Reviewer opinion." if reviewer_score is not None else "No reviewer opinion yet; neutral default.",
        ))
        components.append(QualityComponent(
            name="test", weight=0.2,
            score=100.0 if test_passed is True else (0.0 if test_passed is False else 20.0),
            explanation="Automated test result." if test_passed is not None else "No test run yet; neutral default.",
        ))
        components.append(QualityComponent(
            name="consistency", weight=0.1,
            score=consistency_score if consistency_score is not None else 70.0,
            explanation="Consistency with prior decisions." if consistency_score is not None else "Not checked; neutral default.",
        ))
        return QualityScore.from_components(project_id, "file", file_path, components)

    def score_generic_artifact(self, project_id: str, artifact_kind: str, artifact_ref: str,
                                content: str, reviewer_score: float | None = None) -> QualityScore:
        reviewer_score = self._clamp(reviewer_score)
        components = [
            self._structural_check_generic(content),
            QualityComponent(
                name="reviewer", weight=0.6,
                score=reviewer_score if reviewer_score is not None else 70.0,
                explanation="Reviewer/Evaluator opinion." if reviewer_score is not None else "Neutral default.",
            ),
        ]
        return QualityScore.from_components(project_id, artifact_kind, artifact_ref, components)

    @staticmethod
    def _clamp(value: float | None) -> float | None:
        if value is None:
            return None
        return max(0.0, min(100.0, value))

    def passes(self, score: QualityScore) -> bool:
        return score.final_score >= self.thresholds.weak_pass
