"""
QualityScorer — deterministic scoring of artifacts.

Design changes in this revision
────────────────────────────────
• PROBLEM 13: `reviewer_score` must come from review findings, never from
  agent confidence. If no review score is provided for a code file, the
  reviewer component is BLOCKED (score=0, not 70 default).
• PROBLEM 14: LLM judgment (reviewer_score) is capped at 40% weight;
  deterministic signals (structural, test) carry 60%. LLM cannot unilaterally
  push an artifact to ACCEPTED quality.
• PROBLEM 15: For software artifacts, test_passed=None → score=0 (BLOCKED),
  not a neutral default. An untested artifact cannot pass on review alone.
• PROBLEM 12: FORCED_ACCEPTED tasks are reported distinctly — callers can
  check quality_score.forced to distinguish from genuine acceptance.
"""

from __future__ import annotations

import ast

from orchestrator.quality.models import QualityComponent, QualityScore


_BLOCKED_SCORE = 0.0   # "we don't know" → treat as failing, not neutral


class QualityScorer:
    def __init__(self, thresholds=None) -> None:
        from orchestrator.core.config import get_config
        self.thresholds = thresholds or get_config().quality_thresholds

    # ── structural checks ────────────────────────────────────────────────────

    def _structural_check_code(self, file_path: str, content: str) -> QualityComponent:
        issues = []
        score = 100.0

        if not content.strip():
            return QualityComponent(
                name="structural", weight=0.35, score=0.0,
                explanation="File is empty.",
            )

        if file_path.endswith(".py"):
            try:
                ast.parse(content)
            except SyntaxError as exc:
                issues.append(f"SyntaxError: {exc}")
                score -= 100

        if "TODO: implement" in content or "raise NotImplementedError" in content:
            issues.append("Contains unimplemented placeholders.")
            score -= 20

        if len(content.splitlines()) < 2:
            issues.append("Suspiciously short for a source file.")
            score -= 10

        score = max(0.0, score)
        explanation = "No structural issues found." if not issues else "; ".join(issues)
        return QualityComponent(name="structural", weight=0.35, score=score, explanation=explanation)

    def _structural_check_generic(self, content: str) -> QualityComponent:
        score = 100.0
        issues = []
        if not content.strip():
            score = 0.0
            issues.append("Content is empty.")
        elif len(content.strip()) < 20:
            score -= 30
            issues.append("Content looks too short to be complete.")
        return QualityComponent(
            name="structural", weight=0.35, score=max(0.0, score),
            explanation="; ".join(issues) or "OK",
        )

    # ── scoring entry points ─────────────────────────────────────────────────

    def score_file(
        self,
        project_id: str,
        file_path: str,
        content: str,
        reviewer_score: float | None = None,
        test_passed: bool | None = None,
        consistency_score: float | None = None,
    ) -> QualityScore:
        """Score a source file.

        reviewer_score
            Must come from review findings, NOT from agent confidence.
            If None: reviewer component is BLOCKED (score=0) — PROBLEM 13.

        test_passed
            None means "not tested yet" — for software files this blocks
            the score at 0 for the test component — PROBLEM 15.
        """
        reviewer_score = self._clamp(reviewer_score)
        consistency_score = self._clamp(consistency_score)

        # Reviewer: capped at 40% weight; if absent → BLOCKED (PROBLEM 13/14)
        if reviewer_score is not None:
            reviewer_component = QualityComponent(
                name="reviewer", weight=0.40,
                score=reviewer_score,
                explanation="Reviewer findings-based score.",
            )
        else:
            reviewer_component = QualityComponent(
                name="reviewer", weight=0.40,
                score=_BLOCKED_SCORE,
                explanation="BLOCKED — no reviewer score provided; review must complete before acceptance.",
            )

        # Test: None → BLOCKED for Python files; pass/fail for tested files (PROBLEM 15)
        is_python = file_path.endswith(".py")
        if test_passed is True:
            test_score = 100.0
            test_explanation = "Tests passed."
        elif test_passed is False:
            test_score = 0.0
            test_explanation = "Tests failed."
        else:
            # Not yet tested
            test_score = _BLOCKED_SCORE if is_python else 50.0
            test_explanation = (
                "BLOCKED — Python file not yet tested; test must pass before acceptance."
                if is_python
                else "No test result available (non-Python file); neutral."
            )

        components = [
            self._structural_check_code(file_path, content),
            reviewer_component,
            QualityComponent(
                name="test", weight=0.15,
                score=test_score,
                explanation=test_explanation,
            ),
            QualityComponent(
                name="consistency", weight=0.10,
                score=consistency_score if consistency_score is not None else 70.0,
                explanation=(
                    "Consistency with prior decisions."
                    if consistency_score is not None
                    else "Not checked; neutral default."
                ),
            ),
        ]
        return QualityScore.from_components(project_id, "file", file_path, components)

    def score_generic_artifact(
        self,
        project_id: str,
        artifact_kind: str,
        artifact_ref: str,
        content: str,
        reviewer_score: float | None = None,
    ) -> QualityScore:
        """Score a non-code artifact (plan, research, architecture doc, etc.).

        For generic artifacts, no test component exists so reviewer carries
        more weight. However, reviewer_score=None still blocks the score
        rather than defaulting to 70 (PROBLEM 13).
        """
        reviewer_score = self._clamp(reviewer_score)

        if reviewer_score is not None:
            reviewer_component = QualityComponent(
                name="reviewer", weight=0.60,
                score=reviewer_score,
                explanation="Reviewer findings-based score.",
            )
        else:
            reviewer_component = QualityComponent(
                name="reviewer", weight=0.60,
                score=_BLOCKED_SCORE,
                explanation="BLOCKED — no reviewer score; defaulting to fail-safe.",
            )

        components = [
            self._structural_check_generic(content),
            reviewer_component,
        ]
        return QualityScore.from_components(project_id, artifact_kind, artifact_ref, components)

    @staticmethod
    def _clamp(value: float | None) -> float | None:
        if value is None:
            return None
        return max(0.0, min(100.0, value))

    def passes(self, score: QualityScore) -> bool:
        return score.final_score >= self.thresholds.weak_pass
