"""
Quality Score models — every artifact (a file, a decision, a task
output, a review, a debug fix) gets a scored, explained verdict before
the workflow is allowed to move on, exactly as specced:

    Final Score = 40% structural check + 30% reviewer opinion
                + 20% test result + 10% consistency with prior decisions

The weights are configurable per artifact kind (see quality/scorer.py)
because "structural check" means something different for code vs. a
decision vs. a document.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from orchestrator.core.types import QualityBand, new_id, utcnow
from datetime import datetime


class QualityComponent(BaseModel):
    name: str
    weight: float          # 0..1, all components for one score should sum to ~1.0
    score: float            # 0..100
    explanation: str


class QualityScore(BaseModel):
    score_id: str = Field(default_factory=lambda: new_id("qs"))
    project_id: str
    artifact_kind: str      # "file" | "decision" | "task" | "review" | "debug_fix"
    artifact_ref: str       # e.g. file path, decision_id, task_id
    components: list[QualityComponent]
    final_score: float
    band: QualityBand
    recommended_solution: str = ""
    created_at: datetime = Field(default_factory=utcnow)

    @classmethod
    def from_components(cls, project_id: str, artifact_kind: str, artifact_ref: str,
                         components: list[QualityComponent],
                         recommended_solution: str = "") -> "QualityScore":
        final = sum(c.weight * c.score for c in components)
        return cls(
            project_id=project_id, artifact_kind=artifact_kind, artifact_ref=artifact_ref,
            components=components, final_score=round(final, 1),
            band=QualityBand.from_score(final),
            recommended_solution=recommended_solution,
        )

    def report_line(self) -> str:
        return (
            f"[{self.artifact_kind}] {self.artifact_ref} -> {self.final_score}/100 "
            f"({self.band.value})"
        )
