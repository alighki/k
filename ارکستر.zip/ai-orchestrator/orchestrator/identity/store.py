"""
Persists the Identity to disk as JSON and enforces the rule that
identity changes are append-only and always explained.

Naming: the design doc says "the system should choose its own name,
not randomly — the best option among candidates." We implement that
literally: `propose_names()` generates a short list of candidate
names using deterministic, transparent criteria (short, pronounceable,
not already used, thematically related to "orchestration"), and the
system's own Judge agent (see agents/judge.py) can later be asked to
pick one. Until an agent-backed pick happens, `bootstrap()` picks the
first candidate so the system is usable standalone.
"""

from __future__ import annotations

from pathlib import Path

from orchestrator.core.config import get_config
from orchestrator.core.logging_setup import get_logger
from orchestrator.core.types import utcnow
from orchestrator.identity.models import Identity, IdentityChange

logger = get_logger(__name__)

_NAME_CANDIDATES = [
    "Maestro", "Conclave", "Foreman", "Concord", "Ensemble",
    "Marshal", "Loom", "Cadence", "Quorum", "Relay",
]


class IdentityStore:
    def __init__(self, path: Path | None = None) -> None:
        cfg = get_config()
        self.path = path or (Path(cfg.data_dir) / "identity" / "identity.json")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._identity: Identity | None = None

    def load(self) -> Identity:
        if self._identity is not None:
            return self._identity
        if self.path.exists():
            self._identity = Identity.model_validate_json(self.path.read_text(encoding="utf-8"))
        else:
            self._identity = Identity()
            self._save()
        return self._identity

    def _save(self) -> None:
        assert self._identity is not None
        tmp_path = self.path.with_suffix(".json.tmp")
        tmp_path.write_text(self._identity.model_dump_json(indent=2), encoding="utf-8")
        tmp_path.replace(self.path)

    def propose_names(self, used_names: list[str] | None = None) -> list[str]:
        used = set(used_names or [])
        return [n for n in _NAME_CANDIDATES if n not in used]

    def bootstrap(self, chosen_name: str | None = None) -> Identity:
        """First-run initialization. If no name is supplied, picks the
        first available candidate deterministically (not randomly)."""
        identity = self.load()
        if identity.is_initialized():
            return identity

        name = chosen_name or self.propose_names()[0]
        identity.name = name
        identity.call_sign = name.lower()
        identity.working_style = {
            "code_style": "unspecified",   # learned over time, see learn_preference()
            "verbosity": "concise",
        }
        self._identity = identity
        self._save()
        self.record_change(
            field="name",
            old_value=None,
            new_value=name,
            reason="First-run bootstrap: selected first available candidate name.",
        )
        logger.info("Identity bootstrapped: %s (%s)", identity.name, identity.instance_id)
        return identity

    def record_change(self, field: str, old_value: str | None, new_value: str,
                       reason: str, approved_by_user: bool = False, effect: str = "") -> IdentityChange:
        """Append-only identity changelog. Nothing is ever deleted —
        this mirrors the design doc's 'every change must be versioned,
        nothing should be removed' rule."""
        identity = self.load()
        change = IdentityChange(
            field=field, old_value=old_value, new_value=new_value,
            reason=reason, approved_by_user=approved_by_user, effect=effect,
        )
        identity.changelog.append(change)
        self._save()
        return change

    def learn_preference(self, key: str, value: str, reason: str) -> None:
        """Called by agents after observing a repeated user choice
        (e.g. always picks FastAPI, always names files snake_case).
        This is per-instance learning only — no cross-user sharing."""
        identity = self.load()
        old = identity.preferences.get(key)
        if old == value:
            return
        identity.preferences[key] = value
        self._save()
        self.record_change(field=f"preferences.{key}", old_value=old, new_value=value, reason=reason)

    def add_project(self, project_id: str) -> None:
        identity = self.load()
        if project_id not in identity.project_history:
            identity.project_history.append(project_id)
            self._save()

    def suggest_identity_updates(self) -> list[str]:
        """After many projects, suggest (but never silently apply)
        identity refinements. Real logic would inspect memory/decision
        history; this is the extension point agents/judge.py hooks into."""
        identity = self.load()
        suggestions = []
        if len(identity.project_history) >= 10 and "code_style" not in identity.preferences:
            suggestions.append(
                "10+ projects completed but no code_style preference recorded yet — "
                "consider running preference inference over past decisions."
            )
        return suggestions
