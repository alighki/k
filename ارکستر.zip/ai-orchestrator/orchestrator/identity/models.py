"""
Identity System — every Orchestrator instance builds its own persistent
identity on first run (see docs/PHILOSOPHY.md §Identity).

Important framing, taken directly from the design doc: this identity
is *not* consciousness or feelings. It is a versioned settings/profile
record — closer to "package.json + CHANGELOG" than to a persona. We
model it that way deliberately: every field is inspectable data, every
change is logged with a reason, and nothing is ever silently deleted.
"""

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from orchestrator.core.types import new_id, utcnow


class IdentityChange(BaseModel):
    """One entry in the identity's permanent changelog. Nothing is
    ever removed from this list — see IdentityStore.propose_change."""

    change_id: str = Field(default_factory=lambda: new_id("chg"))
    timestamp: datetime = Field(default_factory=utcnow)
    field: str
    old_value: str | None
    new_value: str
    reason: str
    effect: str = ""            # observed effect, filled in later if known
    approved_by_user: bool = False


class Identity(BaseModel):
    """The Orchestrator's persistent self-description."""

    instance_id: str = Field(default_factory=lambda: new_id("orc"))
    shared_codebase_id: str = "ai-orchestrator-core"  # same across all instances
    name: str | None = None
    call_sign: str | None = None
    version: str = "0.1.0"
    created_at: datetime = Field(default_factory=utcnow)

    working_style: dict[str, str] = Field(default_factory=dict)
    preferences: dict[str, str] = Field(default_factory=dict)
    installed_models: list[str] = Field(default_factory=list)
    installed_tools: list[str] = Field(default_factory=list)
    project_history: list[str] = Field(default_factory=list)  # project ids
    settings: dict[str, str] = Field(default_factory=dict)

    changelog: list[IdentityChange] = Field(default_factory=list)

    def is_initialized(self) -> bool:
        return self.name is not None
