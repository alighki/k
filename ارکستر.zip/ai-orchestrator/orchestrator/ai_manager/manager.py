"""
AI Manager — the design doc's central routing brain, made real.

core/config.py's static `routes` table is still the SOURCE of allowed
candidates per role (primary + fallback provider/model) — that part
doesn't change, since a completely open-ended "try any model for any
role" would need its own capability discovery layer far beyond this
project's scope. What THIS module adds is genuine dynamic selection
ON TOP of that static table:

  1. Builds the candidate list for a role from config.routes (primary +
     fallback), plus optionally MORE candidates the caller supplies
     (e.g. all reviewer_* routes for Multi-Reviewer Consensus).
  2. Ranks them via CapabilityEngine (real track record) blended with
     CostOptimizer (latency/risk-adjusted).
  3. Returns a ranked route list; the FIRST is what BaseAgent should
     try, with the rest as an ordered fallback chain — not just one
     hardcoded fallback like the original config.
  4. Records outcomes back into CapabilityEngine so future routing
     reflects reality, not just the initial static config.

This intentionally stays a pure decision-making module — no network
calls itself, no agent-calling — so it's cheap to unit test and the
Workflow Engine remains the only place that actually calls agents.
"""

from __future__ import annotations

from dataclasses import dataclass

from orchestrator.ai_manager.capability_engine import CapabilityEngine, CapabilityScore
from orchestrator.ai_manager.cost_optimizer import CostOptimizer
from orchestrator.core.config import get_config
from orchestrator.core.logging_setup import get_logger

logger = get_logger(__name__)


@dataclass
class RankedRoute:
    provider: str
    model: str
    capability_score: float
    adjusted_score: float
    samples: int


class AIManager:
    def __init__(self, capability_engine: CapabilityEngine | None = None,
                 cost_optimizer: CostOptimizer | None = None) -> None:
        self.capability = capability_engine or CapabilityEngine()
        self.cost = cost_optimizer or CostOptimizer()
        self.config = get_config()

    def candidates_for_role(self, role: str, extra_candidates: list[tuple[str, str]] | None = None
                             ) -> list[tuple[str, str]]:
        """Primary + fallback from config.routes, plus any extra
        candidates the caller supplies (e.g. Multi-Reviewer's three
        reviewer_* routes), deduplicated while preserving order."""
        route = self.config.routes.get(role)
        seen: set[tuple[str, str]] = set()
        ordered: list[tuple[str, str]] = []

        def add(provider: str | None, model: str | None) -> None:
            if not provider or not model:
                return
            key = (provider, model)
            if key not in seen:
                seen.add(key)
                ordered.append(key)

        if route:
            add(route.provider, route.model)
            add(route.fallback_provider, route.fallback_model)
        for provider, model in (extra_candidates or []):
            add(provider, model)

        return ordered

    def select_route(self, role: str, extra_candidates: list[tuple[str, str]] | None = None
                      ) -> list[RankedRoute]:
        """Returns candidates ranked best-first, blending real
        capability track record with cost/latency/risk. The Workflow
        Engine / BaseAgent should try index 0 first, falling through
        the list on connector failure — this generalizes the old
        single-fallback behaviour into a full ranked chain."""
        candidates = self.candidates_for_role(role, extra_candidates)
        if not candidates:
            logger.warning("No candidates configured for role '%s'.", role)
            return []

        capability_ranked = self.capability.rank_candidates(role, candidates)
        ranked: list[RankedRoute] = []
        for cap_score in capability_ranked:
            adjusted = self.cost.adjust_score(cap_score.provider, cap_score.average_score, model=cap_score.model)
            ranked.append(RankedRoute(
                provider=cap_score.provider, model=cap_score.model,
                capability_score=cap_score.average_score, adjusted_score=adjusted,
                samples=cap_score.samples,
            ))

        ranked.sort(key=lambda r: r.adjusted_score, reverse=True)
        return ranked

    def record_outcome(self, role: str, provider: str, model: str,
                        quality_score: float, latency_seconds: float = 0.0) -> None:
        self.capability.record_outcome(role, provider, model, quality_score, latency_seconds)
