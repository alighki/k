"""
Cost Optimization — LOCAL-ONLY build.

Every provider in this build is "ollama_local" with zero marginal
cost per call, so the classic "prefer free over paid" dimension from
the design doc collapses to a no-op here — there is no paid provider
to avoid. What still matters for a local-only setup is MODEL SIZE:
larger local models are slower and use more VRAM/RAM, so "cost" in
this build means "how much local compute time/memory a candidate
model will burn", estimated from the model name itself since we have
no real benchmark data (self-reported, not measured — see
relative_latency docstring below).
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class ModelCostProfile:
    model: str
    relative_latency: float   # 1.0 = baseline (~7-8B class); larger = slower
    relative_risk: float      # 0.0-1.0, rough proxy for OOM/timeout risk on modest hardware


def _estimate_profile(model: str) -> ModelCostProfile:
    """Heuristic only: parses a "Nb" parameter-count suffix out of the
    model tag (e.g. "qwen2.5:14b" -> 14) and scales latency/risk
    relative to a 7B baseline. Models without a parseable size (e.g.
    "deepcoder", "codegemma" with no explicit tag) get a neutral
    mid-range estimate rather than being penalized for an unknown size.
    This is deliberately NOT measured data — there is no benchmarking
    harness in this build. Treat it as a rough tiebreaker only."""
    match = re.search(r"(\d+(?:\.\d+)?)b", model.lower())
    if not match:
        return ModelCostProfile(model=model, relative_latency=1.2, relative_risk=0.2)

    size_b = float(match.group(1))
    baseline = 7.0
    relative_latency = max(0.6, size_b / baseline)
    relative_risk = min(0.6, 0.1 + (size_b / 100.0))
    return ModelCostProfile(model=model, relative_latency=relative_latency, relative_risk=relative_risk)


class CostOptimizer:
    """Blends a CapabilityScore with a rough local-compute cost profile
    into one preference score — used by AIManager.select_route() to
    break ties between similarly-capable local models in favor of the
    faster/lighter one when the capability gap is small."""

    def __init__(self, risk_aversion: float = 0.3) -> None:
        # Lower default risk_aversion than a mixed local/web build would
        # use, since local-only risk is just "slow", not "might fail to
        # connect at all" — a much smaller downside.
        self.risk_aversion = max(0.0, min(1.0, risk_aversion))

    def profile_for(self, model: str) -> ModelCostProfile:
        return _estimate_profile(model)

    def adjust_score(self, provider: str, capability_score: float, model: str = "") -> float:
        """Returns an adjusted score: capability minus a small penalty
        for estimated latency, so a marginally-better-but-much-larger
        model doesn't automatically beat a faster, similarly-capable
        smaller one. `provider` is accepted for API compatibility with
        the previous multi-provider build but is unused here — every
        provider in this build is "ollama_local"."""
        if not model:
            return capability_score
        profile = self.profile_for(model)
        latency_penalty = (profile.relative_latency - 1.0) * 3.0
        risk_penalty = profile.relative_risk * 10.0 * self.risk_aversion
        return capability_score - latency_penalty - risk_penalty

    def fastest_first(self, models: list[str]) -> list[str]:
        return sorted(models, key=lambda m: self.profile_for(m).relative_latency)
