"""
Capability Engine — design doc: "each Agent should only be chosen for
tasks it's actually strong at."

Unlike core/config.py's static `routes` table (one fixed provider per
role), this module tracks a PER-(role, provider, model) capability
score that starts from a manually-seeded prior and is updated from
real outcomes (Quality Scores recorded during actual runs) — this is
what makes AI Manager routing "real" instead of just a fixed lookup
table: the more a provider is used for a role, the more its score
reflects its actual track record for that role.

Scores are stored in the same SQLite-file-per-concern family as
memory/knowledge graph — no new infra, consistent with the "optimize
for one user" principle.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path

from orchestrator.core.config import get_config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS capability_scores (
    role TEXT NOT NULL,
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    samples INTEGER NOT NULL DEFAULT 0,
    score_sum REAL NOT NULL DEFAULT 0,
    avg_latency_seconds REAL NOT NULL DEFAULT 0,
    confidence_sum REAL NOT NULL DEFAULT 0,
    confidence_samples INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (role, provider, model)
);
"""

# Manually-seeded priors (0-100) reflecting realistic starting
# assumptions per (role, model), used until real outcome data exists.
# Deliberately modest, not marketing claims — they only matter for the
# first few tasks of a role before real samples build up, after which
# actual Quality Scores dominate (see record_outcome() below).
#
# Keyed by MODEL (not just provider) since this is a local-only build:
# every route is "ollama_local", so provider alone can't distinguish
# a code-specialized model (deepseek-coder-v2, deepcoder) from a
# general-purpose one (gemma3, qwen2.5) — the model name is what
# actually carries the signal here.
_DEFAULT_PRIORS: dict[tuple[str, str], float] = {
    ("programmer", "deepseek-coder-v2"): 78.0,
    ("programmer", "deepcoder"): 74.0,
    ("programmer", "deepseek-coder"): 70.0,
    ("programmer", "qwen2.5-coder"): 72.0,
    ("debugger", "deepseek-coder-v2"): 76.0,
    ("debugger", "deepcoder"): 72.0,
    ("debugger", "deepseek-coder"): 68.0,
    ("chief_architect", "qwen2.5-coder"): 75.0,   # more reliable strict-JSON output than R1-style models
    ("chief_architect", "deepseek-r1:8b"): 74.0,   # reasoning-focused model; strong reasoning, less reliable JSON formatting
    ("researcher", "gemma3:12b"): 65.0,
    ("reviewer", "deepseek-r1:8b"): 72.0,
    ("reviewer", "codegemma"): 62.0,
    ("reviewer", "gemma3:12b"): 60.0,
    ("judge", "deepseek-r1:8b"): 73.0,
    ("programmer", "deepseek-coder:6.7b"): 78.0,
    ("programmer", "qwen2.5-coder:7b"): 74.0,
    ("debugger", "deepseek-coder:6.7b"): 76.0,
    ("debugger", "qwen2.5-coder:7b"): 72.0,
    ("chief_architect", "deepseek-r1:14b"): 76.0,
    ("researcher", "qwen3:14b"): 68.0,
    ("reviewer", "deepseek-r1:14b"): 73.0,
    ("reviewer", "qwen3:14b"): 68.0,
    ("judge", "deepseek-r1:14b"): 75.0,
}
_DEFAULT_PRIOR_FALLBACK = 60.0  # anything not listed above


@dataclass
class CapabilityScore:
    role: str
    provider: str
    model: str
    samples: int
    average_score: float
    average_latency_seconds: float


class CapabilityEngine:
    def __init__(self, db_path: Path | None = None) -> None:
        import threading
        cfg = get_config()
        self.db_path = db_path or (Path(cfg.data_dir) / "memory" / "capability.sqlite3")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        # Use check_same_thread=False + explicit lock so parallel agents
        # can safely share one connection without "database is locked" errors.
        # WAL mode allows concurrent reads; the write lock serializes writes.
        self._write_lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=10000")
        self._conn.executescript(_SCHEMA)
        existing = {row[1] for row in self._conn.execute("PRAGMA table_info(capability_scores)").fetchall()}
        if "confidence_sum" not in existing:
            self._conn.execute("ALTER TABLE capability_scores ADD COLUMN confidence_sum REAL NOT NULL DEFAULT 0")
        if "confidence_samples" not in existing:
            self._conn.execute("ALTER TABLE capability_scores ADD COLUMN confidence_samples INTEGER NOT NULL DEFAULT 0")
        self._conn.commit()

    def record_outcome(self, role: str, provider: str, model: str,
                        quality_score: float, latency_seconds: float = 0.0) -> None:
        """Called after a task's Quality Score is known — feeds the
        real track record back into future routing decisions, which is
        what separates this from a static table.
        Write lock ensures parallel agents don't race on SQLite writes."""
        with self._write_lock:
            row = self._conn.execute(
                "SELECT samples, score_sum, avg_latency_seconds FROM capability_scores "
                "WHERE role=? AND provider=? AND model=?",
                (role, provider, model),
            ).fetchone()

            if row is None:
                self._conn.execute(
                    "INSERT INTO capability_scores (role, provider, model, samples, score_sum, avg_latency_seconds) "
                    "VALUES (?,?,?,?,?,?)",
                    (role, provider, model, 1, quality_score, latency_seconds),
                )
            else:
                samples, score_sum, avg_latency = row
                new_samples = samples + 1
                new_avg_latency = ((avg_latency * samples) + latency_seconds) / new_samples
                self._conn.execute(
                    "UPDATE capability_scores SET samples=?, score_sum=?, avg_latency_seconds=? "
                    "WHERE role=? AND provider=? AND model=?",
                    (new_samples, score_sum + quality_score, new_avg_latency, role, provider, model),
                )
            self._conn.commit()


    def record_confidence(self, role: str, provider: str, model: str, confidence_score: float) -> None:
        """Track self-reported confidence separately from actual quality."""
        with self._write_lock:
            row = self._conn.execute(
                "SELECT confidence_sum, confidence_samples FROM capability_scores "
                "WHERE role=? AND provider=? AND model=?",
                (role, provider, model),
            ).fetchone()
            if row is None:
                self._conn.execute(
                    "INSERT INTO capability_scores (role, provider, model, confidence_sum, confidence_samples) "
                    "VALUES (?,?,?,?,?)",
                    (role, provider, model, confidence_score, 1),
                )
            else:
                self._conn.execute(
                    "UPDATE capability_scores SET confidence_sum=?, confidence_samples=? "
                    "WHERE role=? AND provider=? AND model=?",
                    (row[0] + confidence_score, row[1] + 1, role, provider, model),
                )
            self._conn.commit()

    def score_for(self, role: str, provider: str, model: str) -> CapabilityScore:
        row = self._conn.execute(
            "SELECT samples, score_sum, avg_latency_seconds FROM capability_scores "
            "WHERE role=? AND provider=? AND model=?",
            (role, provider, model),
        ).fetchone()

        if row is None or row[0] == 0:
            prior = _DEFAULT_PRIORS.get((role, model), _DEFAULT_PRIOR_FALLBACK)
            return CapabilityScore(role=role, provider=provider, model=model,
                                    samples=0, average_score=prior, average_latency_seconds=0.0)

        samples, score_sum, avg_latency = row
        return CapabilityScore(role=role, provider=provider, model=model,
                                samples=samples, average_score=score_sum / samples,
                                average_latency_seconds=avg_latency)

    def rank_candidates(self, role: str, candidates: list[tuple[str, str]]) -> list[CapabilityScore]:
        """`candidates` is a list of (provider, model) pairs. Returns
        them ranked best-first by average_score, blending in a small
        penalty for samples=0 (unproven) so a well-established provider
        isn't displaced by an untested one purely on prior alone unless
        the prior gap is large."""
        scored = [self.score_for(role, provider, model) for provider, model in candidates]

        def sort_key(s: CapabilityScore) -> float:
            confidence_penalty = 0.0 if s.samples > 0 else 5.0
            return s.average_score - confidence_penalty

        return sorted(scored, key=sort_key, reverse=True)

    def close(self) -> None:
        self._conn.close()
