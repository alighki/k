"""
Consensus Engine — when multiple agents/models propose different
values for the same decision topic (e.g. one says FastAPI, another
says Django), compute an agreement score and a winner.

Simple, explainable voting — no ML classifier, no embeddings-based
similarity for v1. Exact-match voting after light normalization is
transparent and auditable, which matters more here than sophistication.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass


@dataclass
class ConsensusResult:
    winner: str
    consensus_score: float          # fraction of votes the winner received, 0..1
    vote_counts: dict[str, int]
    is_clear_majority: bool


def _normalize(value: str) -> str:
    return value.strip().lower()


def compute_consensus(votes: list[str]) -> ConsensusResult:
    if not votes:
        raise ValueError("compute_consensus called with no votes")

    normalized = [_normalize(v) for v in votes]
    counts = Counter(normalized)
    winner_normalized, winner_count = counts.most_common(1)[0]
    consensus_score = winner_count / len(votes)

    # Recover an original-cased representative for the winning value.
    winner_original = next(v for v in votes if _normalize(v) == winner_normalized)

    return ConsensusResult(
        winner=winner_original,
        consensus_score=round(consensus_score, 2),
        vote_counts=dict(counts),
        is_clear_majority=winner_count > len(votes) / 2,
    )
