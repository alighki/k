"""
Autonomous Decision Policy — the design doc's rule, verbatim:

    "As long as a decision has no irreversible or sensitive effect,
    the system has no right to ask the user. It must make the best
    decision itself." Only ask the user for: deleting data, spending
    money, accessing accounts/credentials, security matters, and
    purely aesthetic/taste calls (e.g. brand color).

This module is the single gate every workflow step must pass through
before it's allowed to act autonomously vs. pause for user input.
"""

from __future__ import annotations

from enum import Enum

from orchestrator.core.config import PolicySettings, get_config


class SensitiveActionKind(str, Enum):
    DELETE_DATA = "delete_data"
    SPEND_MONEY = "spend_money"
    ACCESS_CREDENTIALS = "access_credentials"
    SECURITY_SENSITIVE_CHANGE = "security_sensitive_change"
    PURELY_AESTHETIC_CHOICE = "purely_aesthetic_choice"
    IRREVERSIBLE_EXTERNAL_ACTION = "irreversible_external_action"


class PolicyEngine:
    def __init__(self, settings: PolicySettings | None = None) -> None:
        self.settings = settings or get_config().policy

    def requires_user_confirmation(self, action_kind: SensitiveActionKind | str) -> bool:
        value = action_kind.value if isinstance(action_kind, SensitiveActionKind) else action_kind
        return value in self.settings.requires_user_confirmation

    def can_auto_decide(self, consensus_score: float) -> bool:
        return consensus_score >= self.settings.min_consensus_to_auto_decide

    def can_proceed_on_confidence(self, confidence_0_to_100: int) -> bool:
        return (confidence_0_to_100 / 100.0) >= self.settings.min_confidence_to_proceed

    def review_rounds_exhausted(self, rounds_so_far: int) -> bool:
        limit = self.settings.max_review_rounds
        if limit is None:
            return False
        return rounds_so_far >= limit

    def debug_loops_exhausted(self, loops_so_far: int) -> bool:
        limit = self.settings.max_debug_loops
        if limit is None:
            return False
        return loops_so_far >= limit
