"""
DecisionEngine — ties consensus + policy + memory together into the
single call site the workflow uses whenever a choice must be made
between candidate values (framework, library, approach, ...).

Flow:
    1. Check memory: has this topic already been decided? If so and
       nothing new contradicts it, reuse it (avoids re-litigating).
    2. Otherwise, compute consensus across candidate votes.
    3. If consensus is high enough (policy.min_consensus_to_auto_decide)
       -> auto-approve and record with full reasoning.
    4. If consensus is low AND the topic is policy-sensitive -> pause
       for the user (DecisionStatus.PENDING_USER).
    5. If consensus is low but NOT sensitive -> escalate to the Judge
       agent (agents/judge.py) for a tie-break, then auto-approve.
"""

from __future__ import annotations

from orchestrator.core.types import DecisionStatus
from orchestrator.decision.consensus import compute_consensus
from orchestrator.decision.policy import PolicyEngine, SensitiveActionKind
from orchestrator.memory.manager import MemoryManager
from orchestrator.memory.models import DecisionRecord


class DecisionEngine:
    def __init__(self, memory: MemoryManager | None = None, policy: PolicyEngine | None = None) -> None:
        self.memory = memory or MemoryManager()
        self.policy = policy or PolicyEngine()

    def decide(
        self,
        project_id: str,
        topic: str,
        candidate_votes: list[str],
        reasons_by_candidate: dict[str, list[str]] | None = None,
        sensitive_kind: SensitiveActionKind | None = None,
        judge_tiebreak: str | None = None,
    ) -> DecisionRecord:
        """`judge_tiebreak`, if provided, is the Judge agent's pick when
        consensus was too low to auto-decide — passed in by the caller
        (workflow) after invoking agents.judge, keeping this module
        agent-call-free and easily unit-testable."""

        existing = self.memory.existing_decision(project_id, topic)
        if existing and existing.chosen_value in candidate_votes:
            # Nothing contradicts the standing decision strongly enough
            # to reconsider — reuse it instead of re-deciding every time.
            return existing

        if not candidate_votes:
            # Defensive guard: compute_consensus() requires at least one
            # vote. A caller passing an empty list is a bug upstream, but
            # crashing the whole workflow over a missing proposal is worse
            # than recording a low-confidence placeholder decision.
            record = DecisionRecord(
                project_id=project_id, topic=topic, chosen_value="",
                reasons=["No candidate values were provided for this decision; flagged for review."],
                status=DecisionStatus.PENDING_USER.value,
            )
            self.memory.record_decision(record)
            return record

        if sensitive_kind and self.policy.requires_user_confirmation(sensitive_kind):
            record = DecisionRecord(
                project_id=project_id, topic=topic,
                chosen_value=candidate_votes[0] if candidate_votes else "",
                alternatives=candidate_votes, reasons=["Sensitive action — awaiting user approval."],
                status=DecisionStatus.PENDING_USER.value,
            )
            self.memory.record_decision(record)
            return record

        consensus = compute_consensus(candidate_votes)

        if self.policy.can_auto_decide(consensus.consensus_score):
            reasons = list(reasons_by_candidate.get(consensus.winner, []) if reasons_by_candidate else [])
            reasons.append(f"Consensus {int(consensus.consensus_score * 100)}% across {len(candidate_votes)} proposals.")
            record = DecisionRecord(
                project_id=project_id, topic=topic, chosen_value=consensus.winner,
                alternatives=[v for v in set(candidate_votes) if v != consensus.winner],
                reasons=reasons, consensus_score=consensus.consensus_score,
                status=DecisionStatus.AUTO_APPROVED.value,
            )
            self.memory.record_decision(record)
            return record

        # Low consensus, not sensitive -> defer to Judge tie-break.
        chosen = judge_tiebreak or consensus.winner
        reasons = [
            f"Low consensus ({int(consensus.consensus_score * 100)}%); resolved via Judge tie-break."
            if judge_tiebreak else
            f"Low consensus ({int(consensus.consensus_score * 100)}%); no judge input supplied, "
            f"defaulted to plurality winner."
        ]
        record = DecisionRecord(
            project_id=project_id, topic=topic, chosen_value=chosen,
            alternatives=[v for v in set(candidate_votes) if v != chosen],
            reasons=reasons, consensus_score=consensus.consensus_score,
            status=DecisionStatus.AUTO_APPROVED.value,
        )
        self.memory.record_decision(record)
        return record

    def approve_pending(self, project_id: str, topic: str, approved_value: str) -> DecisionRecord:
        """User approval arrives out-of-band (CLI prompt) for a
        PENDING_USER decision; this finalizes it."""
        record = DecisionRecord(
            project_id=project_id, topic=topic, chosen_value=approved_value,
            reasons=["User-approved sensitive decision."],
            status=DecisionStatus.USER_APPROVED.value,
        )
        self.memory.record_decision(record)
        return record
