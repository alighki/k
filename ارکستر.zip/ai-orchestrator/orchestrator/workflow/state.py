"""
Project State Manager — every project always has exactly one current
stage (ProjectStage enum) and a serialized Task Tree; this module is
the source of truth for "where is this project right now", persisted
as JSON so a crashed/killed process can resume exactly where it left
off (Checkpoint Recovery from the design doc).
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel, Field

from orchestrator.core.config import get_config
from orchestrator.core.exceptions import CheckpointCorruptError
from orchestrator.core.types import ProjectStage, new_id, utcnow
from orchestrator.workflow.task_tree import Task, TaskTree


class ProjectState(BaseModel):
    project_id: str = Field(default_factory=lambda: new_id("proj"))
    name: str
    original_idea: str
    stage: ProjectStage = ProjectStage.RECEIVED
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)
    tasks: list[Task] = Field(default_factory=list)
    review_rounds_used: int = 0
    debug_loops_used: int = 0
    stage_history: list[str] = Field(default_factory=list)
    debug_baseline_checkpoint: str = ""
    debug_candidate_label: str = ""
    architecture_second_opinion_used: bool = False
    stage_error: str = ""


class ProjectStateManager:
    def __init__(self, projects_dir: Path | None = None) -> None:
        cfg = get_config()
        self.projects_dir = projects_dir or (Path(cfg.data_dir) / "projects")
        self.projects_dir.mkdir(parents=True, exist_ok=True)

    def _state_path(self, project_id: str) -> Path:
        return self.projects_dir / project_id / "state.json"

    def create(self, name: str, original_idea: str) -> ProjectState:
        state = ProjectState(name=name, original_idea=original_idea)
        self.save(state)
        return state

    def save(self, state: ProjectState) -> None:
        """Writes atomically (temp file + rename) so a crash mid-write
        can never leave state.json truncated/corrupt — Checkpoint
        Recovery depends on this file always being either the old
        complete version or the new complete version, never a partial
        write. `encoding="utf-8"` is explicit (not relying on the
        platform default) because on Windows the default is often
        cp1252, which cannot encode non-Latin characters — and project
        ideas/names typed by the user can be in any language."""
        state.updated_at = utcnow()
        path = self._state_path(state.project_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = path.with_suffix(".json.tmp")
        tmp_path.write_text(state.model_dump_json(indent=2), encoding="utf-8")
        tmp_path.replace(path)

    def load(self, project_id: str) -> ProjectState:
        path = self._state_path(project_id)
        if not path.exists():
            raise CheckpointCorruptError(f"No saved state for project '{project_id}' at {path}")
        try:
            return ProjectState.model_validate_json(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise CheckpointCorruptError(f"Could not parse state for project '{project_id}': {exc}") from exc

    def advance_stage(self, state: ProjectState, new_stage: ProjectStage) -> ProjectState:
        state.stage_history.append(f"{state.stage.value} -> {new_stage.value} @ {utcnow().isoformat()}")
        state.stage = new_stage
        self.save(state)
        return state

    def project_root(self, project_id: str) -> Path:
        return self.projects_dir / project_id / "workspace"

    def list_projects(self) -> list[str]:
        return [p.name for p in self.projects_dir.iterdir() if p.is_dir()]

    def task_tree_of(self, state: ProjectState) -> TaskTree:
        return TaskTree(state.tasks)

    def sync_task_tree(self, state: ProjectState, tree: TaskTree) -> ProjectState:
        state.tasks = list(tree.tasks.values())
        self.save(state)
        return state
