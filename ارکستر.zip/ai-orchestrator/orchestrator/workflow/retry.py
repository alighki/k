"""
Retry Manager — beyond BaseAgent's per-call tenacity retry (network
blips), this handles the workflow-level retry policy: "if a stage's
quality score is too low, either re-run the same agent, ask a
different agent, or send the stage back for correction" — decisions
that need workflow context (which agent, which stage) that a single
agent call doesn't have.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class RetryAction(str, Enum):
    RETRY_SAME_AGENT = "retry_same_agent"
    TRY_FALLBACK_AGENT = "try_fallback_agent"
    SEND_BACK_FOR_CORRECTION = "send_back_for_correction"
    GIVE_UP_AND_FLAG = "give_up_and_flag"


@dataclass
class RetryDecision:
    action: RetryAction
    reason: str


class RetryManager:
    def __init__(self, max_attempts: int | None = 3) -> None:
        # Guard against a None max_attempts (e.g. policy.max_review_rounds
        # left null in config) reaching `attempts_so_far >= self.max_attempts`
        # below, which would raise TypeError the first time this class is
        # actually used — it's currently constructed in workflow/engine.py
        # but not yet called anywhere in the pipeline.
        self.max_attempts = max_attempts if max_attempts is not None else 3

    def decide(self, attempts_so_far: int, quality_score: float, weak_pass_threshold: float,
               has_fallback_agent: bool) -> RetryDecision:
        if attempts_so_far >= self.max_attempts:
            return RetryDecision(RetryAction.GIVE_UP_AND_FLAG,
                                  f"Exhausted {self.max_attempts} attempts without passing quality gate.")

        if quality_score < weak_pass_threshold / 2:
            # Very poor result — same agent is unlikely to do much
            # better on a bare retry; prefer a different agent if one exists.
            if has_fallback_agent:
                return RetryDecision(RetryAction.TRY_FALLBACK_AGENT,
                                      f"Score {quality_score} very low; switching agent.")
            return RetryDecision(RetryAction.SEND_BACK_FOR_CORRECTION,
                                  f"Score {quality_score} very low and no fallback agent configured.")

        if quality_score < weak_pass_threshold:
            return RetryDecision(RetryAction.RETRY_SAME_AGENT,
                                  f"Score {quality_score} below pass threshold {weak_pass_threshold}; retrying.")

        # Should not normally be called when quality_score already passes,
        # but default to no-op guidance just in case.
        return RetryDecision(RetryAction.RETRY_SAME_AGENT, "Score passes threshold; retry not actually needed.")
