"""
Task Tree — the project broken into small, dependency-tracked units.

Changes in this revision
────────────────────────
Issues 1,3,4,5 — State semantics:
  • REJECTED is now transient (candidate_status); terminal failure uses FAILED.
  • TaskStatus.FAILED is the true terminal; REJECTED = "needs another attempt".
  • dependency_blockers uses only ACCEPTED (not NEEDS_REVIEW) — issues 4.
  • Hard/Soft dependency types — issue 5 (HARD cascades, SOFT does not block).
  • coding_cycle_done(), review_cycle_done(), project_acceptance_ready() — issue 3.
Issues 38,39,40 — Graph validation:
  • _check_no_cycles raises DependencyCycleError; validate() enforces it.
  • Self-dependency caught in validate().
Issue 51 — deferred_reason field on Task.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

from orchestrator.core.exceptions import DependencyCycleError
from orchestrator.core.types import TaskStatus, new_id, utcnow


class TaskDependency(BaseModel):
    """A single dependency edge with optional type."""
    task_id: str
    dep_type: Literal["hard", "soft"] = "hard"
    # hard: downstream task cannot start until this is ACCEPTED
    # soft: ordering hint only — does not block; used for optimization


class Task(BaseModel):
    task_id: str = Field(default_factory=lambda: new_id("task"))
    project_id: str
    title: str
    description: str
    depends_on: list[str] = Field(default_factory=list)         # task_ids (hard by default)
    dependency_edges: list[TaskDependency] = Field(default_factory=list)  # typed edges (issue 5)
    effort: str = "M"
    risk: str = "low"
    status: TaskStatus = TaskStatus.PENDING
    owner_agent_role: str | None = None
    deferred: bool = False
    deferred_reason: str = ""           # issue 51: why this task was deferred
    requirement_impact: str = ""        # issue 51: which requirements are affected
    created_at: datetime = Field(default_factory=utcnow)
    coding_retries: int = 0
    confidence_retries: int = 0
    debug_retries: int = 0
    last_debug_fingerprint: str = ""
    # Planning context preserved for Debug/Programmer (issue 47)
    planning_notes: str = ""
    # Requirement IDs this task covers (issue 53)
    requirement_ids: list[str] = Field(default_factory=list)


class TaskTree:
    """In-memory task graph for one project."""

    def __init__(self, tasks: list[Task] | None = None) -> None:
        self.tasks: dict[str, Task] = {t.task_id: t for t in (tasks or [])}

    def add(self, task: Task) -> None:
        # Issue 40: catch self-dependency before adding
        if task.task_id in task.depends_on:
            raise ValueError(f"Task '{task.task_id}' cannot depend on itself")
        self.tasks[task.task_id] = task
        self._check_no_cycles()

    def get(self, task_id: str) -> Task:
        return self.tasks[task_id]

    def _check_no_cycles(self) -> None:
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {tid: WHITE for tid in self.tasks}

        def visit(tid: str) -> None:
            color[tid] = GRAY
            for dep in self.tasks[tid].depends_on:
                if dep not in self.tasks:
                    continue
                if color[dep] == GRAY:
                    raise DependencyCycleError(f"Cycle detected: '{tid}' -> '{dep}'")
                if color[dep] == WHITE:
                    visit(dep)
            color[tid] = BLACK

        for tid in list(self.tasks):
            if color[tid] == WHITE:
                visit(tid)

    def validate(self) -> None:
        """Full graph integrity check — must pass before execution."""
        self._check_no_cycles()
        for task in self.tasks.values():
            title = task.title.strip().lower()
            if not title:
                raise ValueError(f"Task '{task.task_id}' has an empty title")
            if task.task_id in task.depends_on:
                raise ValueError(f"Task '{task.task_id}' cannot depend on itself")
            for dep in task.depends_on:
                if dep not in self.tasks:
                    raise ValueError(
                        f"Task '{task.title}' references missing dependency '{dep}'"
                    )

    def recover_stale_running(self) -> list[Task]:
        recovered: list[Task] = []
        for task in self.tasks.values():
            if task.status == TaskStatus.RUNNING:
                task.status = TaskStatus.PENDING
                recovered.append(task)
        return recovered

    def unsatisfied_dependencies(self, task: Task) -> list[str]:
        """Return dependencies not yet ACCEPTED (issue 4: NEEDS_REVIEW does not satisfy)."""
        return [
            dep for dep in task.depends_on
            if dep not in self.tasks
            or self.tasks[dep].status != TaskStatus.ACCEPTED
        ]

    def dependency_blockers(self, task: Task) -> list[str]:
        """Return task_ids that currently block this task from running.

        Issue 4: Only ACCEPTED satisfies a hard dependency.
        Issue 5: Soft dependencies never block.
        """
        # Build a set of soft-dependency task_ids (these never block)
        soft_deps = {edge.task_id for edge in task.dependency_edges if edge.dep_type == "soft"}
        _satisfied = frozenset({TaskStatus.ACCEPTED})
        blockers: list[str] = []
        for dep in task.depends_on:
            if dep in soft_deps:
                continue  # issue 5: soft deps don't block
            dependency = self.tasks.get(dep)
            if dependency is None:
                blockers.append(f"<missing:{dep}>")
                continue
            if dependency.status not in _satisfied:
                blockers.append(dep)
        return blockers

    def ready_tasks(self) -> list[Task]:
        ready: list[Task] = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING or task.deferred:
                continue
            if not self.dependency_blockers(task):
                ready.append(task)
        return ready

    def blocked_tasks(self) -> list[tuple[Task, list[str]]]:
        blocked: list[tuple[Task, list[str]]] = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING or task.deferred:
                continue
            blockers = self.dependency_blockers(task)
            if blockers:
                blocked.append((task, blockers))
        return blocked

    # ── Issue 3: Semantic completion checks ────────────────────────────────

    def coding_cycle_done(self) -> bool:
        """True when the coding scheduler has no more work: every task is
        in a terminal state from coding's perspective (NEEDS_REVIEW means
        coding completed; ACCEPTED/REJECTED/FAILED/DEFERRED are all terminal)."""
        terminal = {
            TaskStatus.ACCEPTED,
            TaskStatus.NEEDS_REVIEW,
            TaskStatus.DEFERRED,
            TaskStatus.REJECTED,
            TaskStatus.FAILED,
        }
        return all(t.status in terminal for t in self.tasks.values())

    def review_cycle_done(self) -> bool:
        """True when every non-deferred task has been through review
        (ACCEPTED or REJECTED/FAILED — not stuck in NEEDS_REVIEW)."""
        terminal = {
            TaskStatus.ACCEPTED,
            TaskStatus.REJECTED,
            TaskStatus.FAILED,
            TaskStatus.DEFERRED,
        }
        return all(t.status in terminal for t in self.tasks.values())

    def project_acceptance_ready(self) -> bool:
        """True only when every required (non-deferred) task is ACCEPTED.
        Issue 3: rejected/failed tasks cannot satisfy final acceptance.
        Issue 2: deferred tasks are excluded from required acceptance."""
        return all(
            t.status in {TaskStatus.ACCEPTED, TaskStatus.FORCED_ACCEPTED}
            or t.deferred or t.status == TaskStatus.DEFERRED
            for t in self.tasks.values()
        )

    def all_done(self) -> bool:
        """Alias for coding_cycle_done() — used by coding scheduler."""
        return self.coding_cycle_done()

    def all_required_accepted(self) -> bool:
        """True only when every non-deferred task is fully accepted."""
        return self.project_acceptance_ready()

    def has_deferred(self) -> bool:
        return any(t.deferred or t.status == TaskStatus.DEFERRED for t in self.tasks.values())

    def completion_summary(self) -> dict:
        counts: dict[str, int] = {}
        for t in self.tasks.values():
            counts[t.status.value] = counts.get(t.status.value, 0) + 1
        return counts

    def independent_groups(self, task_ids: list[str]) -> list[list[str]]:
        return [task_ids] if task_ids else []
