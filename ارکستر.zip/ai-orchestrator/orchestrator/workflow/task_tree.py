"""
Task Tree — the project broken into small, dependency-tracked units,
per the design doc's Planning Engine section (phases, dependencies,
effort/risk estimates, deferred tasks).
"""

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from orchestrator.core.exceptions import DependencyCycleError
from orchestrator.core.types import TaskStatus, new_id, utcnow


class Task(BaseModel):
    task_id: str = Field(default_factory=lambda: new_id("task"))
    project_id: str
    title: str
    description: str
    depends_on: list[str] = Field(default_factory=list)
    effort: str = "M"          # S / M / L
    risk: str = "low"          # low / medium / high
    status: TaskStatus = TaskStatus.PENDING
    owner_agent_role: str | None = None
    deferred: bool = False
    created_at: datetime = Field(default_factory=utcnow)
    coding_retries: int = 0      # times retried for stub / invalid-path / empty-files
                                   # (validation failures); capped at _MAX_CODING_RETRIES
    confidence_retries: int = 0  # times retried for confidence=0 / parse failures only;
                                   # separate cap (_MAX_CONFIDENCE_RETRIES) so confidence
                                   # retries don't burn the validation retry budget
    debug_retries: int = 0
    last_debug_fingerprint: str = ""


class TaskTree:
    """In-memory task graph for one project. Persistence is handled by
    workflow/state.py (ProjectStateManager), which serializes this."""

    def __init__(self, tasks: list[Task] | None = None) -> None:
        self.tasks: dict[str, Task] = {t.task_id: t for t in (tasks or [])}

    def add(self, task: Task) -> None:
        self.tasks[task.task_id] = task
        self._check_no_cycles()

    def get(self, task_id: str) -> Task:
        return self.tasks[task_id]

    def _check_no_cycles(self) -> None:
        # Standard DFS cycle detection over depends_on edges.
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {tid: WHITE for tid in self.tasks}

        def visit(tid: str) -> None:
            color[tid] = GRAY
            for dep in self.tasks[tid].depends_on:
                if dep not in self.tasks:
                    # A dangling dependency (references a task that was
                    # never added, e.g. a Planner naming mismatch) is not
                    # a cycle. Skip it here rather than crashing add() —
                    # it still can never appear in ready_tasks() below
                    # since that loop separately checks
                    # `self.tasks[dep].status`, so the affected task
                    # simply stays blocked. validate() is the place that
                    # surfaces dangling deps as an explicit, catchable
                    # error before execution/completion.
                    continue
                if color[dep] == GRAY:
                    raise DependencyCycleError(f"Cycle detected involving task '{tid}' -> '{dep}'")
                if color[dep] == WHITE:
                    visit(dep)
            color[tid] = BLACK

        for tid in list(self.tasks):
            if color[tid] == WHITE:
                visit(tid)

    def validate(self) -> None:
        """Validate graph integrity before execution or completion."""
        self._check_no_cycles()
        for task in self.tasks.values():
            title = task.title.strip().lower()
            if not title:
                raise ValueError(f"Task '{task.task_id}' has an empty title")
            if task.task_id in task.depends_on:
                raise ValueError(f"Task '{task.task_id}' cannot depend on itself")
            for dep in task.depends_on:
                if dep not in self.tasks:
                    raise ValueError(
                        f"Task '{task.title}' references missing dependency '{dep}'"
                    )

    def recover_stale_running(self) -> list[Task]:
        """Reset RUNNING tasks left behind by an interrupted process.

        The workflow persists task state. If the process dies after marking a
        task RUNNING but before persisting its result, a later resume can see
        a graph with no runnable PENDING root even though nothing is actually
        executing. Treat RUNNING as a recoverable transient state at resume.
        """
        recovered: list[Task] = []
        for task in self.tasks.values():
            if task.status == TaskStatus.RUNNING:
                task.status = TaskStatus.PENDING
                recovered.append(task)
        return recovered

    def unsatisfied_dependencies(self, task: Task) -> list[str]:
        """Return dependencies that are not yet in a coding-satisfied state."""
        return [
            dep for dep in task.depends_on
            if dep not in self.tasks
            or self.tasks[dep].status not in (TaskStatus.ACCEPTED, TaskStatus.NEEDS_REVIEW)
        ]

    def dependency_blockers(self, task: Task) -> list[str]:
        """Return dependency references that currently prevent *task* from running.

        A blocker is a missing reference OR a dependency that is NOT in a
        "coding-satisfied" state (ACCEPTED or NEEDS_REVIEW). This includes:
          - REJECTED / FAILED   — terminal failure; downstream will never run
          - PENDING             — not yet coded
          - RUNNING             — currently being coded (parallel execution)
          - BLOCKED             — itself blocked by its own upstream failures
          - DEFERRED            — explicitly out-of-scope for this build

        ``NEEDS_REVIEW`` is intentionally NOT a blocker: Coding completes
        before Review begins, so a dep in NEEDS_REVIEW is safe to build on.

        BUG FIX: the previous implementation only checked REJECTED/FAILED,
        which left PENDING/RUNNING/BLOCKED deps invisible — tasks whose only
        dep was in one of those states appeared in neither ready_tasks() nor
        blocked_tasks(), creating a scheduling gap in the parallel executor.
        """
        _satisfied = frozenset({TaskStatus.ACCEPTED, TaskStatus.NEEDS_REVIEW})
        blockers: list[str] = []
        for dep in task.depends_on:
            dependency = self.tasks.get(dep)
            if dependency is None:
                blockers.append(f"<missing:{dep}>")
                continue
            if dependency.status not in _satisfied:
                blockers.append(dep)
        return blockers

    def ready_tasks(self) -> list[Task]:
        """Return pending, non-deferred tasks whose dependencies are satisfied.

        A task is ready when it is PENDING, not deferred, and has NO
        dependency_blockers (i.e. every dep is in ACCEPTED or NEEDS_REVIEW).

        BUG FIX: the previous version had a redundant second ``all()`` check
        after calling ``dependency_blockers()``. The inner ``all()`` was
        strictly stronger than the old dependency_blockers logic (which only
        caught REJECTED/FAILED). The net effect was that dependency_blockers
        was doing nothing useful in this method, while the all() remained the
        sole real filter. Removing the duplicated all() and fixing
        dependency_blockers to cover all non-satisfied statuses makes both
        ready_tasks() and blocked_tasks() consistent.
        """
        ready: list[Task] = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING or task.deferred:
                continue
            if not self.dependency_blockers(task):
                ready.append(task)
        return ready

    def blocked_tasks(self) -> list[tuple[Task, list[str]]]:
        """Return pending non-deferred tasks and their dependency blockers."""
        blocked: list[tuple[Task, list[str]]] = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING or task.deferred:
                continue
            blockers = self.dependency_blockers(task)
            if blockers:
                blocked.append((task, blockers))
        return blocked

    def all_done(self) -> bool:
        """Return whether no task remains executable in the current workflow.

        Coding marks successfully generated work as ``NEEDS_REVIEW`` because
        the Review stage intentionally runs after Coding.  Treating only
        ``ACCEPTED`` as terminal therefore makes the Coding scheduler spin or
        report a false deadlock after a perfectly successful coding wave.
        Rejected/failed tasks are terminal too; their downstream handling is
        performed by the Review/Debug stages rather than by Coding.
        """
        terminal = {
            TaskStatus.ACCEPTED,
            TaskStatus.NEEDS_REVIEW,
            TaskStatus.DEFERRED,
            TaskStatus.REJECTED,
            TaskStatus.FAILED,
        }
        return all(t.status in terminal for t in self.tasks.values())

    def independent_groups(self, task_ids: list[str]) -> list[list[str]]:
        """Given a set of ready task ids, group ones with no
        dependency relationship between each other — these can run in
        Parallel Executor. Naive grouping: since they're all "ready"
        (deps already satisfied), they're independent of EACH OTHER by
        definition unless one depends on another directly, which
        `ready_tasks()` already excludes. So the whole ready set is one
        parallel group; this method exists as an explicit extension
        point if finer-grained grouping is needed later."""
        return [task_ids] if task_ids else []