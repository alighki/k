"""
Parallel Executor — runs independent coroutines (e.g. several Research
tasks, or several ready Task Tree items) concurrently and collects
results, tolerating individual failures without losing the rest.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, TypeVar

T = TypeVar("T")


class ParallelExecutor:
    def __init__(self, max_concurrency: int = 4) -> None:
        self.semaphore = asyncio.Semaphore(max_concurrency)

    async def _run_one(self, coro_fn: Callable[[], Awaitable[T]]) -> tuple[bool, T | Exception]:
        async with self.semaphore:
            try:
                result = await coro_fn()
                return True, result
            except Exception as exc:  # noqa: BLE001 - collected, not swallowed
                return False, exc

    async def run_all(self, coro_fns: list[Callable[[], Awaitable[T]]]) -> list[tuple[bool, T | Exception]]:
        """Returns a list of (success, result_or_exception) in the same
        order as the input, so callers can match results back to their
        originating task/agent."""
        return await asyncio.gather(*(self._run_one(fn) for fn in coro_fns))
