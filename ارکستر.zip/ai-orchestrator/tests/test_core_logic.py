"""
Unit tests for the pieces of logic that have no network/browser/Ollama
dependency — these should run instantly and are the ones CI would run
on every commit. Run with: pytest tests/
"""

import json

import pytest

from orchestrator.core.exceptions import DependencyCycleError, FileLockConflictError
from orchestrator.decision.confidence import ConfidenceGate, ConfidenceVerdict
from orchestrator.decision.consensus import compute_consensus
from orchestrator.decision.policy import PolicyEngine, SensitiveActionKind
from orchestrator.prompt.output_contract import AgentResponse, parse_agent_response
from orchestrator.quality.scorer import QualityScorer
from orchestrator.quality.test_runner import TestRunner
from orchestrator.workflow.task_tree import Task, TaskTree


def test_consensus_clear_majority():
    result = compute_consensus(["FastAPI", "FastAPI", "FastAPI", "Django"])
    assert result.winner == "FastAPI"
    assert result.is_clear_majority
    assert result.consensus_score == 0.75


def test_consensus_case_insensitive():
    result = compute_consensus(["fastapi", "FastAPI", "FASTAPI"])
    assert result.consensus_score == 1.0


def test_consensus_tie():
    result = compute_consensus(["A", "B"])
    assert result.consensus_score == 0.5
    assert not result.is_clear_majority


def test_policy_sensitive_actions_require_confirmation():
    policy = PolicyEngine()
    assert policy.requires_user_confirmation(SensitiveActionKind.DELETE_DATA)
    assert policy.requires_user_confirmation("spend_money")
    assert not policy.requires_user_confirmation("choose_framework")


def test_output_contract_parses_clean_json():
    raw = '{"answer": "FastAPI", "confidence": 90, "reasons": ["fast"], ' \
          '"unknown_parts": [], "files": [], "decisions_proposed": []}'
    parsed = parse_agent_response(raw)
    assert parsed.answer == "FastAPI"
    assert parsed.confidence == 90


def test_output_contract_strips_markdown_fences():
    raw = '```json\n{"answer": "ok", "confidence": 80, "reasons": [], ' \
          '"unknown_parts": [], "files": [], "decisions_proposed": []}\n```'
    parsed = parse_agent_response(raw)
    assert parsed.answer == "ok"


def test_task_tree_detects_cycle():
    tree = TaskTree()
    t1 = Task(project_id="p1", task_id="t1", title="A", description="", depends_on=["t2"])
    t2 = Task(project_id="p1", task_id="t2", title="B", description="", depends_on=["t1"])
    tree.tasks = {"t1": t1, "t2": t2}
    with pytest.raises(DependencyCycleError):
        tree._check_no_cycles()


def test_deferred_tasks_do_not_deadlock_coding_stage():
    """Reproduces the exact production failure seen in proj_9c718676b036:
    the Planner marked several foundational tasks (Set up Flask, Design
    database schema, etc.) as deferred=True. TaskTree.ready_tasks() skips
    deferred tasks, so they never appeared in the ready list. But they
    still had status=PENDING, so the deadlock detector's 'unfinished'
    list included them -- and since they had no rejected dependencies,
    the cascade-rejection path also couldn't clear them. The deadlock
    detector erroneously fired, killing the whole project.

    The fix: _stage_coding immediately promotes deferred=True PENDING
    tasks to status=DEFERRED at the start of the coding loop, so they
    are invisible to both ready_tasks() AND the deadlock detector, and
    all_done() / the break-on-terminal logic both agree on what 'done'
    means."""
    from orchestrator.workflow.task_tree import Task, TaskTree, TaskStatus

    # Four deferred tasks that the Planner flagged as out-of-scope
    t1 = Task(project_id='p', title='Set up Flask project structure', description='d', deferred=True)
    t2 = Task(project_id='p', title='Design database schema', description='d', deferred=True)
    t3 = Task(project_id='p', title='Implement user authentication', description='d', deferred=True)
    t4 = Task(project_id='p', title='Create transaction recording', description='d', deferred=True)
    # Two in-scope tasks that both get rejected (e.g. confidence=0)
    t5 = Task(project_id='p', title='Design frontend user interface', description='d', deferred=False)
    t6 = Task(project_id='p', title='Implement category management', description='d',
              depends_on=[t5.task_id], deferred=False)

    tree = TaskTree()
    for t in [t1, t2, t3, t4, t5, t6]:
        tree.add(t)

    # Apply the coding-stage deferred promotion (the fix)
    for task in tree.tasks.values():
        if task.deferred and task.status == TaskStatus.PENDING:
            task.status = TaskStatus.DEFERRED

    # First ready batch: only t5 (t6 depends on t5; deferred tasks invisible)
    ready = tree.ready_tasks()
    assert [t.title for t in ready] == ['Design frontend user interface']

    # Simulate both in-scope tasks getting rejected
    t5.status = TaskStatus.REJECTED
    t6.status = TaskStatus.REJECTED

    # After rejections: nothing is ready
    assert tree.ready_tasks() == []

    # The deadlock detector's unfinished list must now be empty
    # (deferred tasks excluded, rejected tasks excluded)
    unfinished = [
        t for t in tree.tasks.values()
        if t.status not in (TaskStatus.ACCEPTED, TaskStatus.DEFERRED, TaskStatus.REJECTED)
        and not t.deferred
    ]
    assert unfinished == [], f"Expected empty unfinished, got: {[t.title for t in unfinished]}"
    # => coding loop hits the 'not unfinished -> break' path and advances
    # to TESTING instead of FAILED


def test_planner_resolves_dependency_by_key_without_fuzzy_matching():
    """The Planner now assigns a short snake_case 'key' to each task and
    uses that key (not the full title) in depends_on_titles. This
    eliminates fuzzy title matching entirely for models that follow the
    contract. Tests that exact key lookup works correctly."""
    from orchestrator.workflow.engine import WorkflowEngine
    from orchestrator.workflow.task_tree import Task, TaskTree

    tree = TaskTree()
    t_db   = Task(project_id='p', title='Design Database Schema', description='d')
    t_auth = Task(project_id='p', title='Implement User Authentication', description='d')
    t_test = Task(project_id='p', title='Write Unit Tests', description='d')
    for t in [t_db, t_auth, t_test]:
        tree.add(t)

    # key_to_id map as built by _stage_planning when key field is present
    key_to_id = {
        'setup_db':   t_db.task_id,
        'impl_auth':  t_auth.task_id,
        'write_tests': t_test.task_id,
    }
    normalized_to_ids = {
        WorkflowEngine._normalize_task_title(t.title): [t.task_id]
        for t in tree.tasks.values()
    }

    # Key lookup: dep ref is the key string, NOT the title
    for key, expected_id in key_to_id.items():
        resolved = key_to_id.get(key.strip())
        assert resolved == expected_id

    # Fuzzy fallback: dep ref is a partial title (old-style model output)
    resolved = WorkflowEngine._resolve_task_title_reference(
        'Database Schema', normalized_to_ids, tree
    )
    assert resolved == t_db.task_id  # superset match


def test_planner_resolves_dependency_referenced_without_leading_verb():
    """Reproduces a real production failure: the Planner created a task
    titled 'Implement Income/Expense Recording', then cited it
    elsewhere as a dependency using the shorter title
    'Income/Expense Recording' (missing the leading verb). The
    character-ratio fuzzy matcher scores this pair at ~0.85 -- below
    its 0.88/0.93 acceptance bar -- so the dependency edge was silently
    dropped. That meant the dependent task ('Write Unit Tests for Core
    Modules') had NO dependency on the foundational task left at all
    and got treated as immediately ready, while the foundational task
    itself was never actually blocking anything and should have run
    first. Confirms the resolver now accepts this as a unique
    token-subset match instead."""
    from orchestrator.workflow.engine import WorkflowEngine

    tree = TaskTree()
    foundational = Task(project_id="p1", title="Implement Income/Expense Recording", description="d")
    other = Task(project_id="p1", title="Design Database Schema", description="d")
    tree.add(foundational)
    tree.add(other)

    normalized_to_ids = {
        WorkflowEngine._normalize_task_title(foundational.title): [foundational.task_id],
        WorkflowEngine._normalize_task_title(other.title): [other.task_id],
    }

    resolved = WorkflowEngine._resolve_task_title_reference(
        "Income/Expense Recording", normalized_to_ids, tree
    )
    assert resolved == foundational.task_id


def test_planner_dependency_resolution_refuses_ambiguous_subset_match():
    """If two different tasks' titles both contain every word of the
    cited dependency, the token-subset match must NOT guess -- same
    'clearly unique or bust' rule as the existing fuzzy-match path."""
    from orchestrator.workflow.engine import WorkflowEngine

    tree = TaskTree()
    a = Task(project_id="p1", title="Implement Income Recording", description="d")
    b = Task(project_id="p1", title="Design Income Recording", description="d")
    tree.add(a)
    tree.add(b)

    normalized_to_ids = {
        WorkflowEngine._normalize_task_title(a.title): [a.task_id],
        WorkflowEngine._normalize_task_title(b.title): [b.task_id],
    }

    resolved = WorkflowEngine._resolve_task_title_reference(
        "Income Recording", normalized_to_ids, tree
    )
    assert resolved is None


def test_task_tree_ready_tasks_respects_dependencies():
    from orchestrator.core.types import TaskStatus
    tree = TaskTree()
    t1 = Task(project_id="p1", task_id="t1", title="A", description="")
    t2 = Task(project_id="p1", task_id="t2", title="B", description="", depends_on=["t1"])
    tree.add(t1)
    tree.add(t2)
    ready = tree.ready_tasks()
    assert [t.task_id for t in ready] == ["t1"]

    t1.status = TaskStatus.ACCEPTED
    ready = tree.ready_tasks()
    assert [t.task_id for t in ready] == ["t2"]


def test_quality_scorer_rejects_empty_file():
    scorer = QualityScorer()
    score = scorer.score_file("p1", "main.py", "")
    assert score.final_score < 60


def test_quality_scorer_flags_syntax_error():
    scorer = QualityScorer()
    score = scorer.score_file("p1", "main.py", "def broken(:\n    pass")
    assert score.final_score < 90


def test_quality_scorer_accepts_valid_code():
    scorer = QualityScorer()
    good_code = "def add(a, b):\n    return a + b\n\nprint(add(1, 2))\n"
    score = scorer.score_file("p1", "main.py", good_code, reviewer_score=90, test_passed=True, consistency_score=100)
    assert score.final_score >= 90


def test_confidence_gate_proceed():
    gate = ConfidenceGate()
    response = AgentResponse(answer="ok", confidence=90, raw_text="")
    assessment = gate.assess(response)
    assert assessment.verdict == ConfidenceVerdict.PROCEED


def test_confidence_gate_seeks_second_opinion():
    gate = ConfidenceGate()
    response = AgentResponse(answer="ok", confidence=60, raw_text="")
    assessment = gate.assess(response)
    assert assessment.verdict == ConfidenceVerdict.SEEK_SECOND_OPINION


def test_confidence_gate_blocks_very_low_confidence():
    gate = ConfidenceGate()
    response = AgentResponse(answer="ok", confidence=10, raw_text="")
    assessment = gate.assess(response)
    assert assessment.verdict == ConfidenceVerdict.BLOCK


def test_confidence_gate_decouples_parse_failed_from_agent_confidence():
    """Requirement 3: Confidence Gate must NEVER conflate parser errors with agent quality.
    A parse_failed response must return ConfidenceVerdict.PARSE_FAILED, not confidence=0 / BLOCK."""
    gate = ConfidenceGate()
    # Case 1: parser error with confidence=0
    response_fail = AgentResponse(answer="broken output", confidence=0, parse_status="parse_failed")
    assessment = gate.assess(response_fail)
    assert assessment.verdict == ConfidenceVerdict.PARSE_FAILED
    assert "Parser Error" in assessment.reason

    # Case 2: even if model had output a self-reported confidence like 95 before format crash,
    # parse_failed status takes absolute precedence and flags PARSE_FAILED
    response_high_conf_parse_fail = AgentResponse(answer="broken", confidence=95, parse_status="parse_failed")
    assessment_high = gate.assess(response_high_conf_parse_fail)
    assert assessment_high.verdict == ConfidenceVerdict.PARSE_FAILED


def test_pipeline_resilient_fences_and_conversational_prose():
    """Requirement 1: Parser handles ```text Here is the JSON: {...}, extra whitespace,
    and conversational filler text before or after."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    sample = """```text
Here is the JSON:
{
  "answer": "Resilient parsing succeeded",
  "confidence": 95,
  "reasons": ["Handles text fences and introductory prose cleanly"],
  "solutions": [],
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": []
}
```
Hope this helps!"""
    result = run_deterministic_pipeline(sample)
    assert result.succeeded, result.summary()
    assert result.response.answer == "Resilient parsing succeeded"
    assert result.response.confidence == 95
    assert result.response.parse_status in ("success", "repaired")


def test_pipeline_order_raw_extract_parse_validate_repair_parse_again_validate_again():
    """Requirement 2: Strict order Raw -> Extract -> Parse -> Schema Validate -> Repair -> Parse Again -> Schema Validate Again."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    # Broken JSON missing a comma between answer and confidence
    broken = """Here is the JSON:
{
  "answer": "Unrepaired first attempt"
  "confidence": 90,
  "reasons": [],
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": []
}"""
    result = run_deterministic_pipeline(broken)
    assert result.succeeded, result.summary()
    assert result.response.parse_status == "repaired"
    stages = [a.stage for a in result.attempts]
    assert "extract" in stages
    assert "parse" in stages
    assert "repair" in stages
    assert "parse_again" in stages
    assert "schema_validate_again" in stages


def test_task_tree_planner_structured_tasks_have_no_dangling_deps():
    tree = TaskTree()
    t1 = Task(project_id="p1", task_id="t1", title="setup", description="")
    t2 = Task(project_id="p1", task_id="t2", title="build", description="", depends_on=["t1", "ghost"])
    tree.add(t1)
    tree.add(t2)
    ready = tree.ready_tasks()
    assert [t.task_id for t in ready] == ["t1"]


def test_test_runner_flags_syntax_error(tmp_path):
    (tmp_path / "broken.py").write_text("def broken(:\n    pass\n")
    runner = TestRunner(timeout_seconds=10)
    syntax_result, pytest_result = runner.run(tmp_path)
    assert not syntax_result.passed


def test_test_runner_passes_valid_code(tmp_path):
    (tmp_path / "ok.py").write_text("def add(a, b):\n    return a + b\n")
    runner = TestRunner(timeout_seconds=10)
    syntax_result, pytest_result = runner.run(tmp_path)
    assert syntax_result.passed
    assert pytest_result is None  # no test_*.py files present


def test_test_runner_runs_real_pytest(tmp_path):
    (tmp_path / "test_sample.py").write_text(
        "def test_ok():\n    assert 1 + 1 == 2\n"
    )
    runner = TestRunner(timeout_seconds=15)
    syntax_result, pytest_result = runner.run(tmp_path)
    assert syntax_result.passed
    assert pytest_result is not None
    assert pytest_result.passed


def test_quality_scorer_clamps_out_of_range_reviewer_score():
    scorer = QualityScorer()
    score = scorer.score_generic_artifact("p1", "task", "t1", "some reasonably long content here", reviewer_score=250)
    for c in score.components:
        if c.name == "reviewer":
            assert c.score == 100.0


def test_retry_manager_uses_configured_max_attempts():
    from orchestrator.workflow.retry import RetryManager, RetryAction
    manager = RetryManager(max_attempts=5)
    decision = manager.decide(attempts_so_far=5, quality_score=40, weak_pass_threshold=60, has_fallback_agent=False)
    assert decision.action == RetryAction.GIVE_UP_AND_FLAG
    decision2 = manager.decide(attempts_so_far=4, quality_score=40, weak_pass_threshold=60, has_fallback_agent=False)
    assert decision2.action != RetryAction.GIVE_UP_AND_FLAG


def test_knowledge_graph_tracks_task_files(tmp_path):
    from orchestrator.knowledge_graph.graph import KnowledgeGraph
    kg = KnowledgeGraph(db_path=tmp_path / "kg.sqlite3")
    kg.record_file_creation("p1", "main.py", agent_run_id="task_1")
    kg.record_file_creation("p1", "utils.py", agent_run_id="task_1")
    kg.record_file_creation("p1", "other.py", agent_run_id="task_2")

    files = kg.neighbors("task_1", relation="produced")
    assert set(files) == {"file:main.py", "file:utils.py"}
    kg.close()


def test_decision_engine_handles_empty_votes_without_crashing():
    from orchestrator.decision.engine import DecisionEngine
    from orchestrator.memory.manager import MemoryManager
    from orchestrator.memory.store import MemoryStore
    import tempfile, os

    tmp_db = tempfile.mktemp(suffix=".sqlite3")
    try:
        memory = MemoryManager(MemoryStore(db_path=__import__("pathlib").Path(tmp_db)))
        engine = DecisionEngine(memory)
        record = engine.decide("p1", "backend_framework", [])
        assert record.status == "pending_user"
    finally:
        if os.path.exists(tmp_db):
            os.remove(tmp_db)


def test_project_state_atomic_save_leaves_no_tmp_file(tmp_path):
    from orchestrator.workflow.state import ProjectStateManager
    manager = ProjectStateManager(projects_dir=tmp_path)
    state = manager.create(name="test", original_idea="idea")
    reloaded = manager.load(state.project_id)
    assert reloaded.project_id == state.project_id
    tmp_files = list(tmp_path.rglob("*.tmp"))
    assert tmp_files == []


def test_identity_bootstrap_is_idempotent(tmp_path):
    from orchestrator.identity.store import IdentityStore
    store = IdentityStore(path=tmp_path / "identity.json")
    first = store.bootstrap()
    second = store.bootstrap()
    assert first.name == second.name
    assert first.instance_id == second.instance_id


def test_memory_store_preserves_special_characters_in_reasons(tmp_path):
    from orchestrator.memory.store import MemoryStore
    from orchestrator.memory.models import DecisionRecord

    store = MemoryStore(db_path=tmp_path / "mem.sqlite3")
    record = DecisionRecord(
        project_id="p1", topic="logic", chosen_value="X",
        reasons=["uses a||b syntax internally", "also, has a comma"],
        alternatives=["Y||Z", "W"],
    )
    store.add_decision(record)
    fetched = store.get_decision_by_topic("p1", "logic")
    assert fetched.reasons == ["uses a||b syntax internally", "also, has a comma"]
    assert fetched.alternatives == ["Y||Z", "W"]
    store.close()


def test_file_lock_manager_recovers_from_corrupt_file(tmp_path):
    from orchestrator.files.lock_manager import FileLockManager
    lock_path = tmp_path / "locks.json"
    lock_path.write_text("{not valid json")
    manager = FileLockManager(lock_path)
    # Should not raise, should treat corrupt file as empty lock table.
    manager.acquire("main.py", "task_1")
    assert manager.owner_of("main.py") == "task_1"


def test_reviewer_agent_routes_to_override_when_set():
    from orchestrator.agents.specialists import ReviewerAgent
    from orchestrator.core.config import get_config
    from unittest.mock import patch
    agent = ReviewerAgent(route_key_override="reviewer_secondary")
    # Bypass capability-score ranking so we test config routing only,
    # not the capability engine's live scoring table.
    with patch.object(agent.ai_manager, "select_route", return_value=[]):
        chain = agent._fallback_chain()
    # Assert against the actual configured route rather than a hardcoded
    # model name — this way the test stays green when config changes.
    cfg = get_config()
    route = cfg.routes.get("reviewer_secondary")
    assert route is not None, "reviewer_secondary route must be configured"
    assert chain[0] == (route.provider, route.model), (
        f"Expected ({route.provider!r}, {route.model!r}) got {chain[0]}"
    )


def test_reviewer_agent_uses_own_role_route_when_no_override():
    from orchestrator.agents.specialists import ReviewerAgent
    agent = ReviewerAgent()
    chain = agent._fallback_chain()
    # "reviewer" has no fallback configured in core/config.py, so
    # ollama_local/deepseek-r1:8b is the only candidate and must rank first.
    assert chain[0] == ("ollama_local", "deepseek-r1:8b")


def test_multi_reviewer_extract_score_prefers_structured_field():
    from orchestrator.quality.multi_reviewer import MultiReviewerConsensus
    from orchestrator.prompt.output_contract import AgentResponse, ProposedDecision

    response = AgentResponse(
        answer="This code has some issues but is mostly fine.",
        confidence=70,
        decisions_proposed=[ProposedDecision(topic="review_score", value="82")],
        raw_text="",
    )
    score = MultiReviewerConsensus._extract_score(response)
    assert score == 82.0


def test_multi_reviewer_extract_score_falls_back_to_confidence():
    from orchestrator.quality.multi_reviewer import MultiReviewerConsensus
    from orchestrator.prompt.output_contract import AgentResponse

    response = AgentResponse(answer="no numbers here at all", confidence=55, raw_text="")
    score = MultiReviewerConsensus._extract_score(response)
    assert score == 55.0


def test_simulation_verdict_enum_values():
    from orchestrator.workflow.simulation import SimulationVerdict
    assert SimulationVerdict("block") == SimulationVerdict.BLOCK
    assert SimulationVerdict("proceed") == SimulationVerdict.PROCEED
    assert SimulationVerdict("warn") == SimulationVerdict.WARN


def test_capability_engine_uses_prior_before_samples(tmp_path):
    from orchestrator.ai_manager.capability_engine import CapabilityEngine
    engine = CapabilityEngine(db_path=tmp_path / "cap.sqlite3")
    score = engine.score_for("programmer", "ollama_local", "deepseek-coder-v2")
    assert score.samples == 0
    assert score.average_score == 78.0  # seeded prior for this model


def test_capability_engine_updates_from_real_outcomes(tmp_path):
    from orchestrator.ai_manager.capability_engine import CapabilityEngine
    engine = CapabilityEngine(db_path=tmp_path / "cap.sqlite3")
    engine.record_outcome("programmer", "ollama_local", "qwen-coder", quality_score=90.0)
    engine.record_outcome("programmer", "ollama_local", "qwen-coder", quality_score=70.0)
    score = engine.score_for("programmer", "ollama_local", "qwen-coder")
    assert score.samples == 2
    assert score.average_score == 80.0


def test_capability_engine_ranks_candidates_best_first(tmp_path):
    from orchestrator.ai_manager.capability_engine import CapabilityEngine
    engine = CapabilityEngine(db_path=tmp_path / "cap.sqlite3")
    engine.record_outcome("programmer", "ollama_local", "model_a", quality_score=95.0)
    engine.record_outcome("programmer", "ollama_local", "model_b", quality_score=40.0)
    ranked = engine.rank_candidates("programmer", [("ollama_local", "model_b"), ("ollama_local", "model_a")])
    assert ranked[0].model == "model_a"


def test_cost_optimizer_penalizes_larger_models_when_capability_tied():
    from orchestrator.ai_manager.cost_optimizer import CostOptimizer
    optimizer = CostOptimizer()
    # No model given -> no penalty at all (capability score passed through).
    no_model_score = optimizer.adjust_score("ollama_local", 70.0)
    assert no_model_score == 70.0
    # A larger local model (12B) should be penalized relative to a
    # smaller one (8B) when their base capability score is the same.
    small_model_adjusted = optimizer.adjust_score("ollama_local", 70.0, model="deepseek-r1:8b")
    large_model_adjusted = optimizer.adjust_score("ollama_local", 70.0, model="gemma3:12b")
    assert small_model_adjusted > large_model_adjusted


def test_ai_manager_select_route_returns_ranked_chain(tmp_path):
    from orchestrator.ai_manager.manager import AIManager
    from orchestrator.ai_manager.capability_engine import CapabilityEngine
    from orchestrator.ai_manager.cost_optimizer import CostOptimizer

    engine = CapabilityEngine(db_path=tmp_path / "cap.sqlite3")
    manager = AIManager(capability_engine=engine, cost_optimizer=CostOptimizer())
    ranked = manager.select_route("programmer")
    assert len(ranked) >= 1
    assert all(hasattr(r, "provider") and hasattr(r, "model") for r in ranked)


def test_prompt_optimizer_gives_model_specific_style_hint():
    from orchestrator.prompt.optimizer import PromptOptimizer, PromptOptimizationStats
    from orchestrator.core.types import AgentRole
    optimizer = PromptOptimizer(stats=PromptOptimizationStats(db_path=None))
    guidance = optimizer.guidance_for(AgentRole.PROGRAMMER, "deepcoder")
    assert "numbered" in guidance.style_hint.lower() or "schema" in guidance.style_hint.lower()
    assert guidance.token_budget == 1200


def test_prompt_optimizer_stats_tracks_length_buckets(tmp_path):
    from orchestrator.prompt.optimizer import PromptOptimizationStats
    stats = PromptOptimizationStats(db_path=tmp_path / "prompt_stats.sqlite3")
    stats.record("programmer", "ollama_local", prompt_char_count=500, quality_score=90.0)
    stats.record("programmer", "ollama_local", prompt_char_count=6000, quality_score=50.0)
    advice = stats.advice_for("programmer", "ollama_local")
    assert "short" in advice.lower()
    stats.close()


def test_prompt_optimizer_build_instruction_includes_budget():
    from orchestrator.prompt.optimizer import PromptOptimizer, PromptOptimizationStats
    from orchestrator.core.types import AgentRole
    optimizer = PromptOptimizer(stats=PromptOptimizationStats(db_path=None))
    instruction = optimizer.build_optimization_instruction(AgentRole.PROGRAMMER, "deepseek-coder-v2", "write a function")
    assert "token" in instruction.lower()
    assert "deepseek-coder-v2" in instruction


def test_json_repair_fixes_missing_comma_between_fields():
    from orchestrator.prompt.output_contract import parse_agent_response
    # Reproduces the exact failure pattern from the real chief_architect
    # log: a long string value followed directly by the next key with
    # no comma between them.
    broken = '''```json
{
  "answer": "The optimal architecture is a simple Python script.",
  "confidence": 90,
  "reasons": [
    "Simple and maintainable"
  ]
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": []
}
```'''
    response = parse_agent_response(broken)
    assert response.confidence == 90
    assert "Python script" in response.answer


def test_json_repair_fixes_trailing_comma():
    from orchestrator.prompt.output_contract import parse_agent_response
    broken = '''{
  "answer": "ok",
  "confidence": 80,
  "reasons": ["a", "b",],
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": [],
}'''
    response = parse_agent_response(broken)
    assert response.answer == "ok"
    assert response.reasons == ["a", "b"]


def test_json_repair_does_not_break_already_valid_json():
    from orchestrator.prompt.output_contract import parse_agent_response
    valid = '{"answer": "fine", "confidence": 100, "reasons": [], "unknown_parts": [], "files": [], "decisions_proposed": [], "tasks_proposed": []}'
    response = parse_agent_response(valid)
    assert response.answer == "fine"
    assert response.confidence == 100


def test_task_tree_ready_tasks_unblocked_by_needs_review_not_just_accepted():
    """Regression test for a real deadlock found in an actual
    end-to-end run: a dependent task stayed PENDING forever because
    ready_tasks() only unblocked on ACCEPTED, but tasks only reach
    ACCEPTED in the separate Review stage that runs AFTER all of
    Coding completes — so within a single Coding pass, a parent task
    can only ever reach NEEDS_REVIEW, never ACCEPTED."""
    from orchestrator.core.types import TaskStatus
    tree = TaskTree()
    parent = Task(project_id="p1", task_id="t1", title="Create main.py", description="")
    child = Task(project_id="p1", task_id="t2", title="Add tests", description="", depends_on=["t1"])
    tree.add(parent)
    tree.add(child)

    # First wave: only the parent is ready (no deps).
    ready = tree.ready_tasks()
    assert [t.task_id for t in ready] == ["t1"]

    # PROBLEM 10: NEEDS_REVIEW does NOT satisfy a dependency.
    # The child must wait until the parent is fully ACCEPTED (post-review).
    parent.status = TaskStatus.NEEDS_REVIEW

    # Child is still blocked — review has not confirmed parent quality yet.
    ready = tree.ready_tasks()
    assert ready == [], f"Child must be blocked while parent is NEEDS_REVIEW, got: {ready}"

    # Only after ACCEPTED does child become ready.
    parent.status = TaskStatus.ACCEPTED
    ready2 = tree.ready_tasks()
    assert [t.task_id for t in ready2] == ["t2"]


# ---- json_pipeline.py: the explicit multi-stage parsing pipeline -----------

def test_pipeline_extract_strips_markdown_fence_and_prose():
    from orchestrator.prompt.json_pipeline import extract_json_candidate
    raw = 'Here is the JSON you requested:\n```json\n{"answer": "ok"}\n```\nHope that helps!'
    extracted = extract_json_candidate(raw)
    assert extracted == '{"answer": "ok"}'


def test_pipeline_escapes_raw_newlines_inside_string_values():
    """The #1 real-world failure mode for this project: files[].content
    carries actual multi-line source code, and a local model frequently
    forgets to escape the newlines as \\n, producing structurally
    broken JSON even though every field is semantically present."""
    from orchestrator.prompt.json_pipeline import automatic_repair
    broken = '''{
  "answer": "ok",
  "confidence": 90,
  "reasons": [],
  "unknown_parts": [],
  "files": [{"path": "main.py", "content": "def main():
    print('hello')

main()"}],
  "decisions_proposed": [],
  "tasks_proposed": []
}'''
    repaired = automatic_repair(broken)
    data = json.loads(repaired)
    assert data["files"][0]["content"] == "def main():\n    print('hello')\n\nmain()"


def test_pipeline_deterministic_success_on_clean_json():
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    clean = '{"answer": "fine", "confidence": 95, "reasons": [], "unknown_parts": [], "files": [], "decisions_proposed": [], "tasks_proposed": []}'
    result = run_deterministic_pipeline(clean)
    assert result.succeeded
    assert result.response.answer == "fine"
    assert not result.needs_ai_repair


def test_pipeline_real_world_missing_comma_bug_from_production_log():
    """Reproduces the EXACT structure of the chief_architect failure
    from the real log: a long multi-sentence `reasons` string list
    followed directly by the next key with no separating comma."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    broken = '''```json
{
  "answer": "The optimal architecture for this single-user greeting application is a simple Python script using JSON files for storage, with a minimalistic command-line interface or basic GUI for user interaction.",
  "confidence": 90,
  "reasons": [
    "JSON file storage is appropriate due to its simplicity and human-readability.",
    "A Python script provides a straightforward baseline"
  ]
  "unknown_parts": [],
  "files": [],
  "decisions_proposed": [],
  "tasks_proposed": []
}
```'''
    result = run_deterministic_pipeline(broken)
    assert result.succeeded, result.summary()
    assert result.response.confidence == 90


def test_pipeline_handles_stray_unescaped_quotes_from_embedded_code():
    """Reproduces a real production failure: a programmer task whose
    generated `content` embedded Python code with a literal dict/
    format-spec expression, e.g. f'...{summary["income"]:.2f}', where
    the model forgot to escape the quotes around "income". A naive
    in_string toggle sees the first of those quotes as closing the
    JSON string entirely, silently truncating the file content and
    producing "Expecting ',' delimiter" a few dozen characters later.
    The tricky part: TWO stray quotes appear back-to-back, and the
    second one is immediately followed by `]`, which looks exactly
    like a legitimate end of a string array."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    broken = '''{
  "answer": "done",
  "confidence": 95,
  "reasons": [],
  "unknown_parts": [],
  "files": [
    {
      "path": "ui.py",
      "content": "def show(summary):\\n    print(f'Total: {summary[\"income\"]:.2f}')\\n"
    }
  ],
  "decisions_proposed": [],
  "tasks_proposed": []
}'''
    result = run_deterministic_pipeline(broken)
    assert result.succeeded, result.summary()
    assert result.response.confidence == 95
    content = result.response.files[0].content
    assert 'summary["income"]' in content
    assert content.endswith("')\n")


def test_pipeline_fixes_invalid_python_style_escaped_quote():
    """Reproduces another real production failure: the model wrote a
    Python-style escaped single quote (\\') inside generated code, e.g.
    f'...{summary[\\'income\\']}'. \\' is valid in a Python string but is
    NOT a legal JSON escape sequence (JSON only allows \\" \\\\ \\/ \\b
    \\f \\n \\r \\t and \\uXXXX) -- json.loads rejected the whole
    response with "Invalid \\escape" the instant it hit one."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    broken = '''{
  "answer": "done",
  "confidence": 100,
  "reasons": [],
  "unknown_parts": [],
  "files": [
    {
      "path": "ui.py",
      "content": "x = summary[\\'income\\'] if \\'income\\' in summary else 0\\n"
    }
  ],
  "decisions_proposed": [],
  "tasks_proposed": []
}'''
    result = run_deterministic_pipeline(broken)
    assert result.succeeded, result.summary()
    content = result.response.files[0].content
    assert content == "x = summary['income'] if 'income' in summary else 0\n"


def test_pipeline_handles_stray_backslash_before_real_newline():
    """Reproduces a third real production failure: the model wrote a
    Python triple-quoted string using single quotes (''' ... ''', not
    the "\"\"\"" form the pipeline already normalizes) with a
    line-continuation backslash directly followed by a real newline,
    e.g. "sql = ''' CREATE TABLE ... ( \\<newline>    id ...". A plain
    "backslash means skip/keep the next char verbatim" escaper treats
    that stray backslash as the start of a valid escape and passes the
    raw newline straight through untouched, which is invalid JSON
    ("Invalid control character") a few fields later."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    broken = '{\n' \
        '  "answer": "done",\n' \
        '  "confidence": 90,\n' \
        '  "reasons": [],\n' \
        '  "unknown_parts": [],\n' \
        '  "files": [\n' \
        '    {\n' \
        '      "path": "db.py",\n' \
        '      "content": "sql = \'\'\' CREATE TABLE expenses ( \\\n' \
        '                    id integer PRIMARY KEY \\\n' \
        '                ); \'\'\'"\n' \
        '    }\n' \
        '  ],\n' \
        '  "decisions_proposed": [],\n' \
        '  "tasks_proposed": []\n' \
        '}'
    result = run_deterministic_pipeline(broken)
    assert result.succeeded, result.summary()
    content = result.response.files[0].content
    assert "CREATE TABLE expenses" in content
    assert "id integer PRIMARY KEY" in content


def test_pipeline_handles_truncated_json():
    """Simulates a response cut off mid-generation (e.g. hit a token
    limit) — the object never closes. Automatic repair should still
    produce a schema-valid (if incomplete) response rather than a hard
    failure, since `answer`/`confidence`/`reasons` are usually intact
    even when a later field got cut off."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    truncated = '{"answer": "partial thought that got cut", "confidence": 70, "reasons": ["one reason'
    result = run_deterministic_pipeline(truncated)
    # Truncation mid-string is a genuinely lossy failure — the pipeline
    # should at least not crash, and should report which stage failed.
    assert result.needs_ai_repair or result.succeeded


def test_pipeline_schema_validation_rejects_wrong_types():
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    wrong_type = '{"answer": "ok", "confidence": "not-a-number", "reasons": [], "unknown_parts": [], "files": [], "decisions_proposed": [], "tasks_proposed": []}'
    result = run_deterministic_pipeline(wrong_type)
    assert not result.succeeded
    assert result.needs_ai_repair


def test_pipeline_finish_after_ai_repair_success_path():
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline, finish_after_ai_repair
    # Use a JSON that automatic_repair cannot fix: an answer value that
    # is entirely non-JSON (no braces) — pipeline cannot extract a dict.
    broken = 'here is my answer without any json structure at all'
    first_pass = run_deterministic_pipeline(broken)
    assert not first_pass.succeeded, (
        f"Expected pipeline to fail on non-JSON input, "
        f"got parse_status={first_pass.parse_status!r}"
    )

    # Simulate the model's AI-repair response: a proper JSON response.
    ai_fixed = '{"answer": "ok", "confidence": 80, "reasons": [], "unknown_parts": [], "files": [], "decisions_proposed": [], "tasks_proposed": []}'
    final = finish_after_ai_repair(broken, ai_fixed, first_pass.attempts)
    assert final.succeeded
    assert final.response.confidence == 80
    # History from the first pass must be preserved, not discarded.
    assert len(final.attempts) > len(first_pass.attempts)


def test_pipeline_controlled_failure_never_raises_on_total_garbage():
    """Stage 6: if everything fails, the caller gets a clean failure
    signal (needs_ai_repair / not succeeded), never an unhandled
    exception bubbling out of the pipeline itself."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline
    garbage = "this is not json at all, just plain prose with no structure whatsoever."
    result = run_deterministic_pipeline(garbage)
    assert not result.succeeded
    assert result.response is None


def test_build_ai_repair_prompt_instructs_syntax_only_fix():
    from orchestrator.prompt.json_pipeline import build_ai_repair_prompt
    prompt = build_ai_repair_prompt('{"broken": "json"')
    assert "do not" in prompt.lower() or "not change the meaning" in prompt.lower() or "only" in prompt.lower()
    assert '{"broken": "json"' in prompt


# ---- Windows encoding regression tests (cp1252 crash bug) -------------------

def test_project_state_survives_non_latin_text(tmp_path):
    """Regression test for a real Windows bug: Path.write_text() without
    an explicit encoding uses the platform default (often cp1252 on
    Windows), which cannot encode Persian/Arabic/CJK/etc. text and
    crashes with UnicodeEncodeError. Every write_text/read_text call in
    this codebase must pass encoding="utf-8" explicitly."""
    from orchestrator.workflow.state import ProjectStateManager
    manager = ProjectStateManager(projects_dir=tmp_path)
    persian_idea = "یک برنامه Python بساز که نام کاربر را بگیرد"
    state = manager.create(name="test-persian", original_idea=persian_idea)
    reloaded = manager.load(state.project_id)
    assert reloaded.original_idea == persian_idea


def test_identity_store_survives_non_latin_text(tmp_path):
    from orchestrator.identity.store import IdentityStore
    store = IdentityStore(path=tmp_path / "identity.json")
    identity = store.bootstrap()
    store.learn_preference("سبک کد", "PEP8 با کامنت فارسی", reason="ترجیح کاربر")
    # Force a reload from disk to prove the write survived encoding-wise.
    store2 = IdentityStore(path=tmp_path / "identity.json")
    reloaded = store2.load()
    assert reloaded.preferences["سبک کد"] == "PEP8 با کامنت فارسی"


def test_file_lock_manager_survives_non_latin_paths(tmp_path):
    from orchestrator.files.lock_manager import FileLockManager
    manager = FileLockManager(tmp_path / "locks.json")
    manager.acquire("پوشه/فایل.py", "task_۱")
    assert manager.owner_of("پوشه/فایل.py") == "task_۱"


def test_no_write_text_or_read_text_call_omits_encoding():
    """Static check: every .write_text(/.read_text( call in the
    orchestrator package must include an explicit encoding= argument,
    so this bug class can never silently reappear in a new file."""
    import pathlib
    import re

    orchestrator_root = pathlib.Path(__file__).resolve().parent.parent / "orchestrator"
    offending = []
    pattern = re.compile(r'\.(write_text|read_text)\(')

    for py_file in orchestrator_root.rglob("*.py"):
        if "__pycache__" in py_file.parts:
            continue
        text = py_file.read_text(encoding="utf-8")
        for match in pattern.finditer(text):
            # Look at the rest of the line (and next line, for wrapped
            # calls) for an encoding= kwarg.
            start = match.start()
            snippet = text[start:start + 200]
            if "encoding=" not in snippet:
                line_no = text[:start].count("\n") + 1
                offending.append(f"{py_file.relative_to(orchestrator_root.parent)}:{line_no}")

    assert not offending, f"Found write_text/read_text calls missing explicit encoding=: {offending}"


def test_output_contract_has_structured_solutions_and_schema_callable():
    from orchestrator.prompt.output_contract import agent_response_json_schema, AgentResponse
    response = AgentResponse(answer="x", confidence=80, solutions=["fix y"], raw_text="")
    assert response.solutions == ["fix y"]
    schema = agent_response_json_schema()
    assert "solutions" in schema.get("properties", {})


def test_file_manager_rejects_path_traversal(tmp_path):
    from orchestrator.files.manager import FileManager
    manager = FileManager(tmp_path)
    with pytest.raises(ValueError):
        manager.write_file("../evil.py", "print(1)", task_id="t1")


def test_file_manager_sanitizes_invalid_windows_filename(tmp_path):
    from orchestrator.files.manager import FileManager
    manager = FileManager(tmp_path)
    path = manager.write_file("<script.py>", "print(1)", task_id="t1")
    assert path.exists()
    assert "<" not in path.name and ">" not in path.name


def test_quality_scorer_requires_explicit_test_result_for_high_score():
    scorer = QualityScorer()
    score = scorer.score_file("p1", "main.py", "def add(a,b):\n    return a+b\n", reviewer_score=100, test_passed=None, consistency_score=100)
    assert score.final_score < 90


def test_task_tree_missing_dependency_is_not_ready():
    tree = TaskTree()
    task = Task(project_id="p1", title="Run task", description="", depends_on=["missing-id"])
    tree.tasks = {task.task_id: task}
    assert tree.ready_tasks() == []
    blocked = tree.blocked_tasks()
    assert len(blocked) == 1
    assert blocked[0][0].task_id == task.task_id
    assert "<missing:missing-id>" in blocked[0][1]


def test_task_tree_failed_dependency_blocks_descendant():
    from orchestrator.core.types import TaskStatus
    tree = TaskTree()
    parent = Task(project_id="p1", task_id="parent", title="Parent", description="")
    child = Task(project_id="p1", task_id="child", title="Child", description="", depends_on=["parent"])
    parent.status = TaskStatus.REJECTED
    tree.tasks = {parent.task_id: parent, child.task_id: child}
    assert tree.ready_tasks() == []
    assert tree.blocked_tasks()[0][1] == ["parent"]


def test_task_tree_iterative_cascade_chain_can_be_detected():
    """Verify cascade blocking: when A is REJECTED, both B (direct dep) and C
    (indirect dep via B which is still PENDING) are immediately blocked.

    FIX NOTE: The previous implementation only blocked tasks whose deps were
    in REJECTED/FAILED — so C was invisible when A=REJECTED, B=PENDING because
    B was neither ready nor blocked (PENDING is not REJECTED/FAILED). The fixed
    dependency_blockers() treats any non-satisfied (not ACCEPTED/NEEDS_REVIEW)
    dep as a blocker, which correctly surfaces C as blocked even in the first
    round without requiring B to transition to REJECTED first.
    """
    from orchestrator.core.types import TaskStatus
    tree = TaskTree()
    a = Task(project_id="p1", task_id="a", title="A", description="")
    b = Task(project_id="p1", task_id="b", title="B", description="", depends_on=["a"])
    c = Task(project_id="p1", task_id="c", title="C", description="", depends_on=["b"])
    a.status = TaskStatus.REJECTED
    tree.tasks = {"a": a, "b": b, "c": c}

    # With A=REJECTED and B=PENDING: both B and C are now blocked in the
    # FIRST round (B because A is REJECTED; C because B is PENDING).
    first = tree.blocked_tasks()
    first_ids = {item[0].task_id for item in first}
    assert "b" in first_ids, f"B should be blocked when A is REJECTED; got {first_ids}"
    assert "c" in first_ids, f"C should be blocked when B is PENDING; got {first_ids}"

    # After explicitly marking B=REJECTED too, C's direct blocker is now B=REJECTED.
    b.status = TaskStatus.REJECTED
    second = tree.blocked_tasks()
    second_ids = {item[0].task_id for item in second}
    assert "c" in second_ids, f"C should remain blocked when B is REJECTED; got {second_ids}"
    assert "b" not in second_ids, f"B should not appear (it is REJECTED, not PENDING); got {second_ids}"


def test_simple_planner_guard_identifies_small_utility_request():
    from orchestrator.workflow.engine import WorkflowEngine
    assert WorkflowEngine._looks_like_simple_request("build a simple greeting tool in Python")
    assert not WorkflowEngine._looks_like_simple_request(
        "build a multi-tenant enterprise analytics platform with authentication and billing"
    )


# --- Regression tests for planner over-engineering and dependency propagation ---

def test_simple_request_minimal_tree_ignores_large_ui_preferences():
    from orchestrator.workflow.engine import WorkflowEngine

    idea = (
        "یک پروژه Python به نام greeting-tool بساز که نام کاربر را بگیرد و "
        "سلام را چاپ کند. همه فایل‌ها در یک پوشه واحد باشند و HOW_TO_RUN.md "
        "با دستور اجرای Windows ایجاد شود. فقط فایل‌های ضروری را بساز."
    )
    tree = WorkflowEngine._build_minimal_simple_task_tree("proj-test", idea)
    titles = {task.title.lower() for task in tree.tasks.values()}

    assert 2 <= len(tree.tasks) <= 3
    assert any("core" in title or "functionality" in title for title in titles)
    assert any("verify" in title for title in titles)
    assert any("documentation" in title for title in titles)
    forbidden = ("tkinter", "gui", "login", "authentication", "database", "sqlite", "profile")
    assert not any(any(word in title for word in forbidden) for title in titles)
    tree.validate()


def test_task_tree_propagates_failed_dependencies_as_blockers():
    from orchestrator.workflow.task_tree import Task, TaskTree
    from orchestrator.core.types import TaskStatus

    tree = TaskTree()
    root = Task(project_id="p", title="Root", description="root")
    child = Task(project_id="p", title="Child", description="child", depends_on=[root.task_id])
    tree.add(root)
    tree.add(child)
    root.status = TaskStatus.FAILED

    blockers = tree.dependency_blockers(child)
    assert root.task_id in blockers
    assert child not in tree.ready_tasks()


def test_task_tree_recovers_stale_running_tasks():
    from orchestrator.core.types import TaskStatus
    tree = TaskTree()
    running = Task(project_id="p1", title="Interrupted task", description="")
    running.status = TaskStatus.RUNNING
    tree.add(running)
    recovered = tree.recover_stale_running()
    assert recovered == [running]
    assert running.status == TaskStatus.PENDING
    assert tree.ready_tasks() == [running]


def test_task_tree_missing_dependency_is_explicitly_blocked():
    tree = TaskTree()
    task = Task(project_id="p1", title="Build", description="", depends_on=["ghost"])
    tree.add(task)
    assert tree.ready_tasks() == []
    blocked = tree.blocked_tasks()
    assert len(blocked) == 1
    assert "<missing:ghost>" in blocked[0][1]

def test_task_tree_all_done_accepts_coding_terminal_states():
    """NEEDS_REVIEW is terminal for Coding, while rejected/failed tasks are
    terminal for scheduling and are handled by later workflow stages."""
    from orchestrator.core.types import TaskStatus

    tree = TaskTree()
    review_task = Task(project_id="p1", title="Coded task", description="")
    rejected_task = Task(project_id="p1", title="Rejected task", description="")
    failed_task = Task(project_id="p1", title="Failed task", description="")
    review_task.status = TaskStatus.NEEDS_REVIEW
    rejected_task.status = TaskStatus.REJECTED
    failed_task.status = TaskStatus.FAILED
    for task in (review_task, rejected_task, failed_task):
        tree.add(task)

    assert tree.all_done() is True


def test_task_tree_needs_review_unblocks_and_finishes_coding_wave():
    """Regression for the exact production deadlock: a parent reaches
    NEEDS_REVIEW, the child becomes runnable, and once both are coded the
    Coding scheduler must consider the wave complete before Review starts."""
    from orchestrator.core.types import TaskStatus

    tree = TaskTree()
    parent = Task(project_id="p1", task_id="p1", title="Implement AST", description="")
    child = Task(project_id="p1", task_id="p2", title="Write tests", description="", depends_on=["p1"])
    tree.add(parent)
    tree.add(child)

    assert [t.task_id for t in tree.ready_tasks()] == ["p1"]
    # PROBLEM 10: NEEDS_REVIEW does NOT unblock the child.
    parent.status = TaskStatus.NEEDS_REVIEW
    assert tree.ready_tasks() == [], "Child must stay blocked while parent awaits review"

    # After ACCEPTED (review completed), child becomes ready.
    parent.status = TaskStatus.ACCEPTED
    assert [t.task_id for t in tree.ready_tasks()] == ["p2"]
    child.status = TaskStatus.NEEDS_REVIEW

    assert tree.all_done() is True
    assert tree.ready_tasks() == []


def test_stub_detector_flags_placeholder_bodies():
    from orchestrator.workflow.engine import _looks_like_stub

    assert _looks_like_stub("main.py", 'import os\n\ndef main():\n    print("hi")\n') is True
    assert _looks_like_stub("app.py", "def foo():\n    pass\n") is True
    assert _looks_like_stub("stub.py", "# TODO: implement this\n") is True
    assert _looks_like_stub("empty.py", "") is True
    assert _looks_like_stub("bar.py", "def bar():\n    ...\n") is True


def test_stub_detector_accepts_real_implementation():
    from orchestrator.workflow.engine import _looks_like_stub

    real_code = (
        "import sys\n"
        "from collections import Counter\n\n"
        "def count_words(path):\n"
        "    with open(path) as f:\n"
        "        return Counter(f.read().split())\n\n"
        "def main():\n"
        "    print(count_words(sys.argv[1]))\n"
    )
    assert _looks_like_stub("word_counter.py", real_code) is False


def test_stub_detector_does_not_flag_legitimate_short_files():
    """Regression test: brevity alone must never be treated as a stub signal.
    A short file can be a complete, correct implementation."""
    from orchestrator.workflow.engine import _looks_like_stub

    assert _looks_like_stub("utils.py", "def add(a, b):\n    return a + b\n") is False
    assert _looks_like_stub("config.py", 'DEBUG = True\nSECRET_KEY = "abc123"\n') is False
    assert _looks_like_stub("exceptions.py", "class NotFoundError(Exception):\n    pass\n") is False


def test_stub_detector_exempts_init_files():
    """__init__.py legitimately contains nothing but re-exports."""
    from orchestrator.workflow.engine import _looks_like_stub

    assert _looks_like_stub("__init__.py", "from .models import User, Board\n") is False
    assert _looks_like_stub("pkg/__init__.py", "from .models import User\n") is False


def test_stub_detector_exempts_abstract_methods():
    """A `pass` body on an @abstractmethod is intentional, not missing work,
    and must not cause the rest of a real, implemented file to be rejected."""
    from orchestrator.workflow.engine import _looks_like_stub

    abc_code = (
        "from abc import ABC, abstractmethod\n\n"
        "class Base(ABC):\n"
        "    @abstractmethod\n"
        "    def do_thing(self):\n"
        "        pass\n\n"
        "class Impl(Base):\n"
        "    def do_thing(self):\n"
        "        return 42\n"
    )
    assert _looks_like_stub("base.py", abc_code) is False


def test_stub_detector_ignores_non_code_files():
    from orchestrator.workflow.engine import _looks_like_stub

    assert _looks_like_stub("README.md", "hi") is False
    assert _looks_like_stub("requirements.txt", "pandas\n") is False


def test_requirements_filter_drops_stdlib_hallucinations():
    from orchestrator.files.manager import _strip_stdlib_from_requirements_txt

    raw = "flask\nsqlite3\npandas==2.1.0\njson\n# a comment\n\ncssutils==2.3.0\n"
    cleaned = _strip_stdlib_from_requirements_txt(raw)
    lines = [l.strip() for l in cleaned.splitlines() if l.strip()]
    assert "sqlite3" not in lines
    assert "json" not in lines
    assert "flask" in lines
    assert "pandas==2.1.0" in lines
    assert "cssutils==2.3.0" in lines  # not stdlib, kept even though unrelated


def test_test_runner_rejects_missing_undeclared_local_dependency(tmp_path):
    # Regression: an installed package with the same name must not mask
    # a missing file that the generated project expects to import.
    (tmp_path / "app.py").write_text("from models import Book\n")
    (tmp_path / "models.py").write_text("from database import Base\n")
    (tmp_path / "requirements.txt").write_text("Flask==3.0.0\npytest==8.0.0\n")

    from orchestrator.quality.test_runner import TestRunner
    runner = TestRunner(timeout_seconds=10)
    syntax_result, pytest_result = runner.run(tmp_path)

    assert not syntax_result.passed
    assert "database" in syntax_result.stderr
    assert pytest_result is None


def test_test_runner_allows_declared_external_dependency(tmp_path):
    (tmp_path / "app.py").write_text("import pydantic\n")
    (tmp_path / "requirements.txt").write_text("pydantic>=2.6\npytest>=8\n")

    from orchestrator.quality.test_runner import TestRunner
    runner = TestRunner(timeout_seconds=10)
    syntax_result, pytest_result = runner.run(tmp_path)

    # Static graph validation accepts the declared dependency. The final
    # dynamic import may depend on the orchestrator environment having it.
    assert syntax_result.passed