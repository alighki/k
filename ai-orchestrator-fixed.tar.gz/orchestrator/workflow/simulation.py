"""
Simulation-before-execution — the design doc's own words: "before even
one file changes, the system simulates the whole operation mentally.
Like chess: think first, then act."

For a personal-use, LLM-driven system, a literal execution-sandbox
simulation is out of scope (that's closer to what the real Testing
stage — quality/test_runner.py — already does AFTER code exists). What
this module implements instead is the cheaper, earlier-warning version
the design doc's spirit calls for: BEFORE a Programmer agent writes
any files for a task, ask an agent to reason through the likely
outcome/risks of the planned change against current project state, and
block or flag the task if it predicts a high-risk failure — the same
role a senior engineer's "wait, before you write this, have you
considered..." serves in code review, just moved earlier in the loop.

This is deliberately a lightweight pre-check, not a second Coding
stage: it costs one extra agent call per task, reuses the Reviewer
role/prompt style (critique, not creation), and its verdict is
advisory-with-teeth (BLOCK/WARN/PROCEED) rather than a full simulated
execution trace.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from orchestrator.agents.base import BaseAgent
from orchestrator.core.logging_setup import get_logger
from orchestrator.core.types import AgentRole
from orchestrator.memory.manager import MemoryManager

logger = get_logger(__name__)


class SimulationVerdict(str, Enum):
    PROCEED = "proceed"     # no significant predicted risk
    WARN = "warn"           # predicted risk, but not severe enough to block
    BLOCK = "block"         # predicted risk severe enough to skip execution


@dataclass
class SimulationResult:
    verdict: SimulationVerdict
    predicted_risks: list[str]
    reasoning: str


_SIMULATION_INSTRUCTIONS = """
You are performing a PRE-EXECUTION SIMULATION, not writing code. Given
a planned task and the current project context, reason through what
would likely happen if this task were implemented as described:

- What could break in EXISTING files/functionality because of this change?
- What assumptions is this task making that might not hold?
- Is there a missing dependency (a decision, a file, another task)
  this task silently assumes already exists?
- Is the task's scope actually small enough to implement safely in one step?

Do not write any code. Report predicted risks as a list. Then give an
overall verdict via `decisions_proposed` with topic="simulation_verdict"
and value one of: "proceed" (safe to implement as-is), "warn" (some
risk, but implement anyway with the risks noted for the Reviewer), or
"block" (risk is severe enough that implementing this as described
would likely fail or break something — recommend NOT proceeding without
first resolving a specific blocking issue, which you must name).
"""


class SimulationEngine:
    """Reuses the Reviewer role (critique posture, not creation) rather
    than defining a brand-new AgentRole/route — the design doc frames
    this as "think like a reviewer, before instead of after"."""

    def __init__(self, memory: MemoryManager | None = None) -> None:
        self.memory = memory or MemoryManager()

    async def simulate(self, project_id: str, task_title: str, task_description: str,
                        project_context: str = "") -> SimulationResult:
        agent = BaseAgent(memory=self.memory)
        agent.role = AgentRole.REVIEWER  # borrow the Reviewer's critique-oriented prompt

        full_task = (
            f"{_SIMULATION_INSTRUCTIONS}\n\n"
            f"## Planned task\nTitle: {task_title}\nDescription: {task_description}\n\n"
            f"## Relevant project context\n{project_context}"
        )
        response = await agent.run(project_id, task_description=full_task)

        verdict = SimulationVerdict.PROCEED
        has_verdict = False
        for proposed in response.decisions_proposed:
            if proposed.topic == "simulation_verdict":
                has_verdict = True
                try:
                    verdict = SimulationVerdict(proposed.value.strip().lower())
                except ValueError:
                    logger.warning("Simulation returned unrecognized verdict value '%s'; "
                                    "defaulting to WARN.", proposed.value)
                    verdict = SimulationVerdict.WARN
                break

        if not has_verdict:
            # Model ignored the structured field entirely — UNKNOWN is not
            # HIGH RISK by itself. Only concrete conflicts justify a BLOCK.
            # Missing information → WARN at most (Section 6 of mission).
            verdict = SimulationVerdict.WARN
            logger.debug("Simulation for task '%s' did not report a structured verdict; defaulting to WARN.", task_title)

        # Rule: UNKNOWN information alone must not escalate to BLOCK.
        # Only concrete conflicts (contradictions in context) justify BLOCK.
        # If the verdict is BLOCK but all risks are phrased as "unknown",
        # "we don't know", "unclear", or "missing", downgrade to WARN.
        if verdict == SimulationVerdict.BLOCK:
            unknown_keywords = {"unknown", "unclear", "missing", "don't know", "do not know",
                                  "whether", "if ", "not specified", "not sure", "uncertain"}
            all_risks = " ".join(response.unknown_parts + [response.answer]).lower()
            # Count how many risk signals are purely speculative vs concrete
            concrete_block = any(
                kw in all_risks
                for kw in ("conflict", "contradiction", "breaks ", "break ", "incompatible",
                            "will fail", "cannot work", "wrong", "incorrect")
            )
            speculative_only = any(kw in all_risks for kw in unknown_keywords) and not concrete_block
            if speculative_only:
                logger.info(
                    "Simulation BLOCK for task '%s' is based on uncertainty only (no concrete conflicts); "
                    "downgrading to WARN.", task_title
                )
                verdict = SimulationVerdict.WARN

        return SimulationResult(
            verdict=verdict,
            predicted_risks=response.unknown_parts,
            reasoning=response.answer,
        )
