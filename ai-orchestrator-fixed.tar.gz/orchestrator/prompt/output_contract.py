"""
Output Contract — every agent prompt demands the SAME structured
envelope back, regardless of which model answers.

Changes in this revision
────────────────────────
• ProposedTask now has a mandatory `description` field (PROBLEM 07 / 27).
• `depends_on_titles` renamed to `depends_on_keys`; name matches semantics
  (PROBLEM 08). The old name is kept as a Pydantic alias so existing YAML /
  JSON from older runs still loads without error.
• ProposedFile gains an `operation` field: "create" | "modify" | "delete"
  (PROBLEM 28 / 29). Empty content for a non-delete file is a contract error.
• CONTRACT_INSTRUCTIONS updated to match new field names / semantics.
"""

from __future__ import annotations

import json
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from orchestrator.core.exceptions import MalformedResponseError


class ProposedFile(BaseModel):
    path: str
    content: str
    operation: Literal["create", "modify", "delete"] = "create"

    @model_validator(mode="after")
    def content_required_for_non_delete(self) -> "ProposedFile":
        if self.operation != "delete" and not self.content.strip():
            raise ValueError(
                f"ProposedFile '{self.path}': content must be non-empty for "
                f"operation '{self.operation}'. Use operation='delete' for intentional removals."
            )
        return self


class ProposedDecision(BaseModel):
    topic: str
    value: str
    reasons: list[str] = Field(default_factory=list)


import re as _re

_SNAKE_CASE_RE = _re.compile(r'^[a-z][a-z0-9_]*$')


class ProposedTask(BaseModel):
    """Used only by the Planner agent.

    Issues 33-37: description required; depends_on_keys canonical; key must
    be lowercase snake_case; effort/risk Literal-validated; uniqueness enforced.
    Issue 53: requirement_ids for traceability.
    """

    title: str
    key: str = ""                   # issue 37: snake_case enforced in validator
    description: str = ""           # issue 33/34: required actionable implementation brief
    depends_on_keys: list[str] = Field(default_factory=list, alias="depends_on_titles")
    effort: Literal["S", "M", "L"] = "M"        # issue 49
    risk: Literal["low", "medium", "high"] = "low"  # issue 50
    deferred: bool = False
    deferred_reason: str = ""       # issue 51
    requirement_impact: str = ""    # issue 51
    requirement_ids: list[str] = Field(default_factory=list)  # issue 53

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def validate_fields(self) -> "ProposedTask":
        # Issue 33/34: description fallback to title if not supplied
        if not self.description.strip():
            self.description = self.title
        # Issue 37: normalize key to snake_case; derive from title if empty
        if not self.key.strip():
            self.key = _re.sub(r'[^a-z0-9]+', '_', self.title.lower()).strip('_') or "task"
        else:
            # Normalize: lowercase, replace spaces/hyphens with underscore
            normalized_key = _re.sub(r'[^a-z0-9_]', '_', self.key.lower()).strip('_')
            self.key = normalized_key or "task"
        return self


class ReviewerFinding(BaseModel):
    """Issues 88-91: structured reviewer finding with severity, file, line."""
    description: str
    severity: Literal["critical", "high", "medium", "low"] = "medium"
    file: str = ""          # canonical relative path (empty if not file-specific)
    line: int | None = None # line number when applicable


class AgentResponse(BaseModel):
    answer: str
    confidence: int = Field(ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    solutions: list[str] = Field(default_factory=list)
    unknown_parts: list[str] = Field(default_factory=list)
    files: list[ProposedFile] = Field(default_factory=list)
    decisions_proposed: list[ProposedDecision] = Field(default_factory=list)
    tasks_proposed: list[ProposedTask] = Field(default_factory=list)
    # Issues 88-91: structured review findings
    review_findings: list[ReviewerFinding] = Field(default_factory=list)
    missing_requirements: list[str] = Field(default_factory=list)

    # Runtime metadata — set by BaseAgent.run() after the call, never
    # requested from the model.
    raw_text: str = Field(default="", exclude=True)
    provider_used: str = Field(default="", exclude=True)
    model_used: str = Field(default="", exclude=True)
    parse_status: str = Field(default="success", exclude=True)

    @property
    def is_parse_failed(self) -> bool:
        return self.parse_status == "parse_failed"

    @property
    def has_critical_findings(self) -> bool:
        """True if any reviewer finding is critical severity."""
        return any(f.severity == "critical" for f in self.review_findings)


CONTRACT_INSTRUCTIONS = """
You MUST answer with a single JSON object and nothing else (no markdown
fences, no commentary before or after). The JSON object must have
exactly these keys:

{
  "answer": "<your main answer as a string>",
  "confidence": <integer 0-100, your own honest confidence in this answer>,
  "reasons": ["<short reason>", "..."],
  "solutions": ["<specific actionable fix>", "..."],
  "unknown_parts": ["<anything you are not sure about>", "..."],
  "files": [
    {
      "path": "<relative path>",
      "content": "<full file content>",
      "operation": "create|modify|delete"
    }
  ],
  "decisions_proposed": [{"topic": "<short topic id>", "value": "<chosen value>", "reasons": ["..."]}],
  "tasks_proposed": [
    {
      "key": "<snake_case_id>",
      "title": "<short unique title>",
      "description": "<full implementation brief — self-contained, actionable>",
      "depends_on_keys": ["<key of another task>"],
      "effort": "S|M|L",
      "risk": "low|medium|high",
      "deferred": false
    }
  ]
}

IMPORTANT for tasks_proposed:
• Each task MUST have a unique snake_case "key" (e.g. "setup_db", "impl_auth").
• Each task MUST have a "description" that fully explains what to implement —
  the Programmer will only see the description, not the title.
• Use "depends_on_keys" (not titles) to reference other tasks — exact key
  matching, no fuzzy lookup.

IMPORTANT for files:
• "operation" must be "create", "modify", or "delete".
• For "create" and "modify", "content" must be non-empty.
• For "delete", "content" may be empty string.

If a key doesn't apply, use an empty list or empty string — never omit
the key. Do not wrap the JSON in ```json fences.

CRITICAL — how to put source code inside "content":
This is standard JSON. Every string, including file contents, must be a
single-line JSON string with newlines written as \\n and any double-quote
inside the code escaped as \\". Example:

  "content": "import os\\n\\ndef main():\\n    print(\\"hi\\")\\n"
"""


# ---------------------------------------------------------------------------
# Role-specific response contracts
# ---------------------------------------------------------------------------

class ProgrammerResponse(BaseModel):
    """Contract for the Programmer role — files + summary + confidence."""
    files: list[ProposedFile] = Field(default_factory=list)
    summary: str = ""
    confidence: int = Field(default=80, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    unknown_parts: list[str] = Field(default_factory=list)


class ReviewerResponse(BaseModel):
    """Contract for the Reviewer role — verdict + findings + confidence."""
    verdict: Literal["PASS", "FAIL"] = "FAIL"
    findings: list[ReviewerFinding] = Field(default_factory=list)
    confidence: int = Field(default=80, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    review_score: float = Field(default=0.0, ge=0.0, le=100.0)


class DebuggerResponse(BaseModel):
    """Contract for the Debugger role — files + summary + confidence."""
    files: list[ProposedFile] = Field(default_factory=list)
    summary: str = ""
    confidence: int = Field(default=80, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    unknown_parts: list[str] = Field(default_factory=list)
    changed_files: list[str] = Field(default_factory=list)


class PromptEngineerResponse(BaseModel):
    """Contract for the Prompt Engineer role — improved prompt + rationale."""
    improved_prompt: str = ""
    rationale: str = ""
    confidence: int = Field(default=80, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)


class PlannerResponse(BaseModel):
    """Contract for the Planner role — tasks + decisions."""
    tasks_proposed: list[ProposedTask] = Field(default_factory=list)
    decisions_proposed: list[ProposedDecision] = Field(default_factory=list)
    answer: str = ""
    confidence: int = Field(default=80, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)


def _attempt_json_repair(text: str) -> str:
    """Deprecated shim — kept for external callers."""
    from orchestrator.prompt.json_pipeline import automatic_repair
    return automatic_repair(text)


def parse_agent_response(raw_text: str) -> AgentResponse:
    """Deterministic parse: Extract → Parse → Repair → Validate.
    Does NOT call a model. Raises MalformedResponseError on failure."""
    from orchestrator.prompt.json_pipeline import run_deterministic_pipeline

    result = run_deterministic_pipeline(raw_text)
    if result.succeeded:
        assert result.response is not None
        return result.response

    last_error = result.attempts[-1].error if result.attempts else "unknown error"
    raise MalformedResponseError(
        f"Could not parse model response into AgentResponse contract "
        f"(pipeline: {' -> '.join(a.stage for a in result.attempts)}): {last_error}\n"
        f"Raw response (truncated): {raw_text[:500]}"
    )


def agent_response_json_schema() -> dict:
    """Compact schema for Ollama structured output — excludes runtime-only fields."""
    schema = AgentResponse.model_json_schema()
    properties = schema.get("properties", {})
    for name in ("raw_text", "provider_used", "model_used"):
        properties.pop(name, None)
    required = [name for name in schema.get("required", []) if name in properties]
    schema["properties"] = properties
    schema["required"] = required
    return schema
